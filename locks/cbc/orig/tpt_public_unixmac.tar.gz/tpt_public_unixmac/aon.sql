set autotrace trace stat

