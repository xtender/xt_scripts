and rownum <= &1
.
prompt ....and rownum <= &1
/

