select count(*) from &1 where &2;

