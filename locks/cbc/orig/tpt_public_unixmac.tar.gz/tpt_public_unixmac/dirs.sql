col dirs_directory_path head DIRECTORY_PATH for a90

select owner, directory_name, directory_path dirs_directory_path from dba_directories;
