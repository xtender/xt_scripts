set echo on
