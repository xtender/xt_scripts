select * from v$mutex_sleep order by wait_time desc, sleeps desc;
