prompt SQL> oradebug setmypid
oradebug setmypid
