select 
    SNAME
  , MASTER
  , STATUS
--, SCHEMA_COMMENT
  , GNAME
  , FNAME
  , RPC_PROCESSING_DISABLED
  , OWNER
from
    dba_repgroup
/
