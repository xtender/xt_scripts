select * from dba_roles where upper(role) like upper('%&1%');
