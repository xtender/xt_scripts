set termout off
store set "&_tpt_tempdir/set_&_tpt_tempfile..sql" replace
set termout on
