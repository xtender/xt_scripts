@@segstat2 "%&1%" "%&2%"
