select * from &1
/
