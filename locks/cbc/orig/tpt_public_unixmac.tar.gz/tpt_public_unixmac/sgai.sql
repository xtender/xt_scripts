select * from v$sgainfo;
