select * from v$sessmetric where session_id in (&1);
