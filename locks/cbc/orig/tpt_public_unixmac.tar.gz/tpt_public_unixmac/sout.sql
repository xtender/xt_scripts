prompt set serverout on size 1000000 format wrapped
set serverout on size 1000000 format wrapped
