@@sprivs2 "%&1%"

