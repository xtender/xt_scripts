@@sample sql_hash_value,sql_child_number v$session sid=&1 1000
