select sum(&1) from &2;
