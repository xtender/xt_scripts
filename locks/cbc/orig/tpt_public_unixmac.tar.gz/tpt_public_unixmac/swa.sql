@@sw "select sid from v$session"
