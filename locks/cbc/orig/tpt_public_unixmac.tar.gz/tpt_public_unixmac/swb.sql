@@sw "select sid from v$session where type = 'BACKGROUND'"
