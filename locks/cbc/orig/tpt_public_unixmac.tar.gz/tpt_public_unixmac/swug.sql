@swg "select sid from v$session where type = 'USER'"
