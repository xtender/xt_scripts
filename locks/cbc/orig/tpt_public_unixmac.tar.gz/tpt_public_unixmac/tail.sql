--host tail -&1 &trcfile
host ssh oracle@solaris01 tail &trcfile

