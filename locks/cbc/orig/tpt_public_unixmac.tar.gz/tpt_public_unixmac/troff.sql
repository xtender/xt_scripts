prompt Setting linesize truncate off
set truncate off

