prompt Setting linesize truncate on
set truncate on
