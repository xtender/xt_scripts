select userenv('&1') from dual;
