prompt What's going on right now?!
@@snapper ash,ash1,ash2,ash3=sqlid 5 1 all
