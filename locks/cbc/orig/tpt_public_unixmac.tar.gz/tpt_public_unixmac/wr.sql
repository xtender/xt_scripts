where rownum <= &1
.
prompt ....where rownum <= &1
/

