Rem
Rem $Header: rdbms/admin/a1201000.sql /st_rdbms_12.1/5 2014/06/04 23:08:48 atomar Exp $
Rem
Rem a1201000.sql
Rem
Rem Copyright (c) 2012, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      a1201000.sql - additional ANONYMOUS BLOCK dictionary upgrade
Rem                     making use of PL/SQL packages installed by
Rem                     catproc.sql.
Rem
Rem    DESCRIPTION
Rem      Additional upgrade script to be run during the upgrade of an
Rem      12.1.0.1 database to 12.1.0.2 patch release.
Rem
Rem      This script is called from catupgrd.sql and a1102000.sql
Rem
Rem      Put any anonymous block related changes here.
Rem      Any dictionary create, alter, updates and deletes  
Rem      that must be performed before catalog.sql and catproc.sql go 
Rem      in c1201000.sql
Rem
Rem      The upgrade is performed in the following stages:
Rem        STAGE 1: upgrade from 12.1.0.1 to the current release
Rem        STAGE 2: invoke script for subsequent release
Rem
Rem    NOTES
Rem      * This script must be run using SQL*PLUS.
Rem      * You must be connected AS SYSDBA to run this script.
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem       atomar   06/02/14 - Backport atomar_bug-18872448 from main
Rem       atomar   05/22/14 - bug 18799102_bkp correct subshard,flag,THRESHOLD
Rem       apfwkr   05/15/14 - Backport pyam_bug-18424768 from main
Rem       apfwkr   04/30/14 - Backport devghosh_bug-17709018 from main
Rem       apfwkr   03/21/14 - Backport kyagoub_bug-18290927 from main
Rem       atomar   05/30/14 - bug 18872448 dqt default val
Rem       pyam     05/09/14 - populate pdb_sync$ on 12.1.0.1->x upgrade
Rem       devghosh 03/27/14 - bug17709018: grant for 11.2 queue
Rem       kyagoub  03/11/14 - bug-18290927: add force to sqltune drop_program
Rem       ddadashe 02/20/14 - drop datamining programs
Rem       praghuna 01/20/13 - lrg9150974:Populate PTO recovery info         
Rem       pyam     12/10/13 - 17709180: drop public synonym htmldb_system
Rem       amullick 12/05/13 - Bug17526562: revoke grant SELECT ON 
Rem                           CDB_SECUREFILE views from SELECT_CATALOG_ROLE
Rem       yiru     11/26/13 - Bug 17515547: revoke SELECT ON CDB_XS_xxx session
Rem                           and audit views from SELECT_CATALOG_ROLE
Rem       ssonawan 11/24/13 - Bug 17513956: revoke grant ON CDB_AUDIT_MGMT
Rem                           views from SELECT_CATALOG_ROLE
Rem       jheng    09/27/13 - Bug 17515047: revoke grant SELECT ON CDB_xx PA
Rem                           views from SELECT_CATALOG_ROLE
Rem       sragarwa 10/10/13 - Bug 17303407: Revoke delete on aud$ and
Rem                           fga_log$ from delete_catalog_role
Rem       rpang    09/04/13 - Add network ACLs to noexp$
Rem       lvbcheng 08/26/13 - 17356189: Drop HTMLDB_SYSTEM when present
Rem       rpang    08/06/13 - 7185425: upgrade SQL ID/hash for SQL translation
Rem                           profiles
Rem       mthiyaga 07/09/13 - Bug 16924879: drop QSMA related public synonyms
Rem       kyagoub  06/11/13 - bug16654392: upgrade auto_sql_tuning_prog
Rem       tchorma  06/06/13 - Bug16622082 - Logminer dict - mark Top-level
Rem                           varrays on upgrade
Rem       tchorma  05/14/13 - Bug16769846 Fix Logminer krvxoa ANYDATA handling
Rem       jerrede  03/28/13 - Add Support for CDB
Rem       sdball   03/06/13 - Move GDS upgrade code to c1201000.sql
Rem       jkati    02/28/13 - bug#16080525: audit DBMS_RLS for traditional
Rem                           audit
Rem       sdball   02/14/13 - Bugs 16269799,16269848: Upgrade changes for GDS
Rem    cdilling    10/16/12

Rem *************************************************************************
Rem BEGIN a1201000.sql
Rem *************************************************************************

Rem ==========================================================================
Rem Revoke DELETE on AUD$ and FGA_LOG$ from  DELETE_CATALOG_ROLE (Bug 17303407)
Rem ==========================================================================

DECLARE
   NOT_GRANTED_AUD EXCEPTION;
  PRAGMA EXCEPTION_INIT(NOT_GRANTED_AUD, -1927);
BEGIN
  --Revoke delete privileges on AUD$ from DELETE_CATALOG_ROLE
  EXECUTE IMMEDIATE 'REVOKE DELETE ON AUD$ FROM DELETE_CATALOG_ROLE';

  EXCEPTION 
    -- If privileges have been revoked/not granted, do not revoke
    WHEN NOT_GRANTED_AUD THEN
      NULL;
    -- Raise any other error
    WHEN OTHERS THEN
      RAISE;
END;
/


DECLARE
  NOT_GRANTED_FGA EXCEPTION;
  PRAGMA EXCEPTION_INIT(NOT_GRANTED_FGA, -1927);
BEGIN
  -- Revoke delete privileges on FGA_LOG$ from DELETE_CATALOG_ROLE
  EXECUTE IMMEDIATE 'REVOKE DELETE ON FGA_LOG$ FROM DELETE_CATALOG_ROLE';

  EXCEPTION
    --If privileges have been revoked/not granted, do not revoke
    WHEN NOT_GRANTED_FGA THEN
      NULL;
    -- Raise any other error
    WHEN OTHERS THEN
      RAISE;

END;
/

Rem =======================================================================
Rem End (Bug 17303407)
Rem =======================================================================

Rem ====================================================================
Rem Begin Changes for Traditional Audit
Rem ====================================================================

Rem
Rem Support for CDB Trap for ORA-65040: operation not allowed
Rem from within a pluggable database
Rem

BEGIN
 EXECUTE IMMEDIATE 'AUDIT EXECUTE ON DBMS_RLS BY ACCESS';
EXCEPTION
 WHEN OTHERS THEN IF (SQLCODE = -65040) THEN NULL; ELSE RAISE; END IF;
END;
/

Rem ====================================================================
Rem End Changes for Traditional Audit
Rem ====================================================================


Rem ====================================================================
Rem Begin Changes for SQL Tuning Advisor 
Rem ====================================================================
Rem 
Rem bug#16654392: drop the auto-sqltune program if already exists. 
Rem 

begin 
  -- drop program  
  dbms_scheduler.drop_program('AUTO_SQL_TUNING_PROG', TRUE);

exception
  when others then
    if (sqlcode = -27476)     -- program does not exist
    then
      null;                   -- ignore it
    else
      raise;                  -- non expected errors
    end if;
end; 
/

Rem ====================================================================
Rem End Changes for SQL Tuning Advisor
Rem ====================================================================

Rem ====================================================================
Rem Begin Changes for Data Mining Java API
Rem ====================================================================
Rem 
Rem bug#18096032: drop JDM  programs if already exist. 
Rem 

begin 
  -- drop program  
  dbms_scheduler.drop_program('sys.jdm_build_program');

exception
  when others then
    if (sqlcode = -27476)     -- program does not exist
    then
      null;                   -- ignore it
    else
      raise;                  -- non expected errors
    end if;
end; 
/

begin 
  -- drop program  
  dbms_scheduler.drop_program('sys.jdm_test_program');

exception
  when others then
    if (sqlcode = -27476)     -- program does not exist
    then
      null;                   -- ignore it
    else
      raise;                  -- non expected errors
    end if;
end; 
/

begin 
  -- drop program  
  dbms_scheduler.drop_program('sys.jdm_sql_apply_program');

exception
  when others then
    if (sqlcode = -27476)     -- program does not exist
    then
      null;                   -- ignore it
    else
      raise;                  -- non expected errors
    end if;
end; 
/

begin 
  -- drop program  
  dbms_scheduler.drop_program('sys.jdm_export_program');

exception
  when others then
    if (sqlcode = -27476)     -- program does not exist
    then
      null;                   -- ignore it
    else
      raise;                  -- non expected errors
    end if;
end; 
/

begin 
  -- drop program  
  dbms_scheduler.drop_program('sys.jdm_import_program');

exception
  when others then
    if (sqlcode = -27476)     -- program does not exist
    then
      null;                   -- ignore it
    else
      raise;                  -- non expected errors
    end if;
end; 
/

begin 
  -- drop program  
  dbms_scheduler.drop_program('sys.jdm_xform_program');

exception
  when others then
    if (sqlcode = -27476)     -- program does not exist
    then
      null;                   -- ignore it
    else
      raise;                  -- non expected errors
    end if;
end; 
/

begin 
  -- drop program  
  dbms_scheduler.drop_program('sys.jdm_predict_program');

exception
  when others then
    if (sqlcode = -27476)     -- program does not exist
    then
      null;                   -- ignore it
    else
      raise;                  -- non expected errors
    end if;
end; 
/

begin 
  -- drop program  
  dbms_scheduler.drop_program('sys.jdm_explain_program');

exception
  when others then
    if (sqlcode = -27476)     -- program does not exist
    then
      null;                   -- ignore it
    else
      raise;                  -- non expected errors
    end if;
end; 
/

begin 
  -- drop program  
  dbms_scheduler.drop_program('sys.jdm_profile_program');

exception
  when others then
    if (sqlcode = -27476)     -- program does not exist
    then
      null;                   -- ignore it
    else
      raise;                  -- non expected errors
    end if;
end; 
/

begin 
  -- drop program  
  dbms_scheduler.drop_program('sys.jdm_xform_seq_program');

exception
  when others then
    if (sqlcode = -27476)     -- program does not exist
    then
      null;                   -- ignore it
    else
      raise;                  -- non expected errors
    end if;
end; 
/

Rem ====================================================================
Rem End Changes for Data Mining Java API
Rem ====================================================================


Rem =======================================================================
Rem  Begin Changes for Logminer
Rem =======================================================================
 /* Bug 16769846
  * Complextypecols should have KRVX_OA_ANYDATA set whenever the table 
  * has a SYS.ANYDATA column or its PUBLIC.ANYDATA synonym.
  */
update system.logmnrc_gtlo tlo
  set tlo.complextypecols = tlo.complextypecols + 32
  where 0 = bitand (tlo.complextypecols, 32) /* KRVX_OA_ANYDATA */
        and                           /* Any opaques are present */
        8 = bitand (tlo.unsupportedcols, 8)  /* KRVX_OA_OPAQUES */
        and  /* There is a SYS.ANYDATA or PUBLIC.ANYDATA present */
        exists 
         (select 1 from  system.logmnrc_gtcs tcs
          where tcs.logmnr_uid = tlo.logmnr_uid AND
                tcs.obj# = tlo.BASEOBJ# AND
                tcs.objv# = tlo.BASEOBJV# AND
                tcs.type# = 58 /* OPAQUE */ AND
                tcs.XTYPENAME = 'ANYDATA' AND
                (tcs.XTYPESCHEMANAME = 'SYS' OR 
                 tcs.XTYPESCHEMANAME = 'PUBLIC'));
commit;

 /* Bug 16622082
  * Unsupportedcols should have the KRVX_OA_TOPLVLVARRAY bit set whenever
  * the table has a non-hidden named array type.
  */
update system.logmnrc_gtlo tlo
  set tlo.unsupportedcols = tlo.unsupportedcols + 8192
  where 0 = bitand (tlo.unsupportedcols, 8192) /* KRVX_OA_TOPLVLVARRAY */
        and                           /* Varray is present */
        128 = bitand (tlo.unsupportedcols, 128) /* KRVX_OA_NAR */
        and  /* There is a non-hidden varray present */
        exists 
         (select 1 from  system.logmnrc_gtcs tcs
          where tcs.logmnr_uid = tlo.logmnr_uid AND
                tcs.obj# = tlo.BASEOBJ# AND
                tcs.objv# = tlo.BASEOBJV# AND
                tcs.type# = 123 /* Named Array */ AND
                0 = bitand(tcs.property, 32));
commit;

Rem =======================================================================
Rem  End Changes for Logminer
Rem =======================================================================

Rem Begin Drop SQL Advisor Synonyms
Rem ===============================

Rem Drop all summary advisor related public synonyms created by QSMA.JAR,
Rem which is called from $ORACLE_HOME/rdbms/admin/initqsma.sql IN 10.2.

BEGIN
   FOR cur_rec IN (SELECT synonym_name
                     FROM dba_synonyms
                    WHERE synonym_name LIKE '%oracle/qsma/Qsma%' OR
                          synonym_name LIKE '%oracle/qsma/Char%' OR
                          synonym_name LIKE '%oracle/qsma/Parse%' OR
                          synonym_name LIKE '%oracle/qsma/Token%' OR
                          synonym_name LIKE '%_QsmaReport%' OR
                          synonym_name LIKE '%_QsmaSql%'
                   )
   LOOP
      BEGIN
         IF (cur_rec.synonym_name LIKE '%oracle/qsma/Qsma%' OR
             cur_rec.synonym_name LIKE '%oracle/qsma/Char%' OR
             cur_rec.synonym_name LIKE '%oracle/qsma/Parse%' OR
             cur_rec.synonym_name LIKE '%oracle/qsma/Token%' OR
             cur_rec.synonym_name LIKE '%_QsmaReport%' OR
             cur_rec.synonym_name LIKE '%_QsmaSql%')
           THEN
              EXECUTE IMMEDIATE 'DROP PUBLIC SYNONYM '
                            || DBMS_ASSERT.ENQUOTE_NAME(cur_rec.synonym_name, FALSE);
           END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
             DBMS_SYSTEM.ksdwrt(DBMS_SYSTEM.trace_file,'FAILED: DROP '
                                  || '"'
                                  || cur_rec.synonym_name
                                  || '"');
      END;
   END LOOP;
END;
/

Rem ===============================
Rem End Drop SQL Advisor Synonyms
Rem ===============================

Rem =========================================================================
Rem BEGIN SQL Translation Framework Changes
Rem =========================================================================

Rem Upgrade SQL ID and SQL hash to 12.1.0.2
update sqltxl_sql$
   set sqlid   = dbms_sql_translator.sql_id(sqltext),
       sqlhash = dbms_sql_translator.sql_hash(sqltext);
commit;

Rem =========================================================================
Rem END SQL Translation Framework Changes
Rem =========================================================================

Rem =========================================================================
Rem BEGIN Package Removal
Rem =========================================================================

drop package sys.htmldb_system;
drop public synonym htmldb_system;

Rem =========================================================================
Rem END Package Removal
Rem =========================================================================

Rem *************************************************************************
Rem Network ACL changes for 12.1.0.2
Rem *************************************************************************

Rem Insert network ACLs to Datapump noexp$
insert into noexp$ (owner, name, obj_type)
  (select xa.owner, xa.name, 110 from dba_xs_acls xa
    where xa.security_class_owner = 'SYS'
      and xa.security_class       = 'NETWORK_SC'
      and not exists (select * from noexp$ ne
                       where ne.owner    = xa.owner
                         and ne.name     = xa.name
                         and ne.obj_type = 110));
commit;

Rem *************************************************************************
Rem END Network ACL changes
Rem *************************************************************************

Rem *************************************************************************
Rem BEGIN bug 17515047, 17513956, 17515547 for 12.1.0.2
Rem *************************************************************************
-- Bug 17513956: Revoke incorrect grant on CDB_AUDIT_MGMT views to SELECT_CATALOG_ROLE
CREATE OR REPLACE PROCEDURE SYS.REVOKE_SELECT_FROM_CATALOG(tablename varchar2)
AS
  cdb_root number := 0;
  stmt varchar2(4000) := 'REVOKE SELECT ON ' || tablename || ' FROM SELECT_CATALOG_ROLE';
BEGIN
  select sys_context('USERENV','CON_ID') into cdb_root from dual;
  IF (cdb_root = 1) THEN
     stmt := stmt || ' container=all'; /* add CONTAINER=ALL clause if CDB$ROOT */
  END IF;
  IF (cdb_root = 1 OR cdb_root = 0) THEN
     EXECUTE IMMEDIATE stmt;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE IN ( -1927 ) THEN NULL;
    /*Ignore ORA-01927: cannot REVOKE privileges you did not grant */
    ELSE RAISE;
    END IF;
END;
/

exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_AUDIT_MGMT_CONFIG_PARAMS');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_AUDIT_MGMT_LAST_ARCH_TS');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_AUDIT_MGMT_CLEAN_EVENTS');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_AUDIT_MGMT_CLEANUP_JOBS');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_USERS_WITH_DEFPWD');

-- Bug 17515047: Revoke incorrect grant to SELECT_CATALOG_ROLE on CDB$ROOT or legacy DB
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_PRIV_CAPTURES');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_USED_PRIVS');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_USED_SYSPRIVS');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_USED_SYSPRIVS_PATH');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_USED_OBJPRIVS');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_USED_OBJPRIVS_PATH');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_USED_USERPRIVS');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_USED_USERPRIVS_PATH');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_USED_PUBPRIVS');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_UNUSED_PRIVS');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_UNUSED_SYSPRIVS');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_UNUSED_SYSPRIVS_PATH');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_UNUSED_OBJPRIVS');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_UNUSED_OBJPRIVS_PATH');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_UNUSED_USERPRIVS');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_UNUSED_USERPRIVS_PATH');

-- Bug17526562 : Revoke incorrect grant to SELECT_CATALOG_ROLE on 
-- CDB_SECUREFILE* VIEWS
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_SECUREFILE_LOGS');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_SECUREFILE_LOG_TABLES');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_SECUREFILE_LOG_INSTANCES');
exec SYS.REVOKE_SELECT_FROM_CATALOG('SYS.CDB_SECUREFILE_LOG_PARTITIONS');

-- drop the temporary procedure after it's used.
DROP PROCEDURE SYS.REVOKE_SELECT_FROM_CATALOG;
/

--Fix bug 17515547: revoke SELECT ON CDB_XS_xxx session and audit views from 
--SELECT_CATALOG_ROLE
DECLARE
  cdb_root number := 0;
  type obj_name_list IS VARRAY(10) OF VARCHAR2(128);
  xs_view_list obj_name_list;
  buf varchar2(4000);
BEGIN
  xs_view_list := obj_name_list('CDB_XS_ACTIVE_SESSIONS',
                                'CDB_XS_AUDIT_POLICY_OPTIONS',
                                'CDB_XS_AUDIT_TRAIL',
                                'CDB_XS_ENB_AUDIT_POLICIES',
                                'CDB_XS_SESSIONS',
                                'CDB_XS_SESSION_NS_ATTRIBUTES',
                                'CDB_XS_SESSION_ROLES');

  select sys_context('USERENV','CON_ID') into cdb_root from dual;

  IF (cdb_root = 1 OR cdb_root = 0) THEN
    FOR i IN xs_view_list.first..xs_view_list.last
     LOOP
       IF (cdb_root = 0) THEN
         buf:= 'revoke SELECT ON SYS.'|| xs_view_list(i) ||
               ' from SELECT_CATALOG_ROLE';
       ELSE
         buf:= 'revoke SELECT ON SYS.'|| xs_view_list(i) ||
               ' from SELECT_CATALOG_ROLE container=all';
       END IF;
       BEGIN
         EXECUTE IMMEDIATE buf;

       EXCEPTION
         WHEN OTHERS THEN
           IF SQLCODE IN ( -1927 ) THEN NULL;
           ELSE RAISE;
           END IF;
       END;
    END LOOP;
  END IF;
END;
/

Rem *************************************************************************
Rem END bug 17515047, 17513956, 17515547 for 12.1.0.2
Rem *************************************************************************
Rem *************************************************************************
Rem BEGIN changes for Progress Table Optimization 
Rem *************************************************************************

/* Infer the pto fields for logical standby
 * pto_recovery_scn - set to MIN_REQUIRED_CAPTURE_CHANGE# as this gets
 *                    maintained considering PTO recovery requirements.
 * pto_recovery_incarnation - incarnation of the db when commit_time was last
 *                            updated.
 *
 * All these fields will get updated during the first lwm recording time
 * after the upgrade and subsequently will get maintained there after
 *
 */
declare
  recovery_scn number;
  last_event_time date;
begin
  select nvl(MIN_REQUIRED_CAPTURE_CHANGE#,current_scn) into recovery_scn from
  v$database;

  /* This should give us a time when apply was last known to have run.
   * The incarnation of the db at that time is what we want.
   */
  select max(event_time) into last_event_time from sys.dba_logstdby_events;

  update system.logstdby$apply_milestone am
  set pto_recovery_scn = recovery_scn,
      pto_recovery_incarnation = 
        (select max(incarnation#) 
         from v$database_incarnation where
          last_event_time > resetlogs_time
        )
  where bitand(flags, 1) <> 0;
  commit;
end;
/

/* Infer the pto fields for (x)streams.
 * pto_recovery_scn - set to MIN_REQUIRED_CAPTURE_CHANGE# as this gets
 *                    maintained considering PTO recovery requirements.
 * pto_recovery_incarnation - incarnation of the db when lwm_time was last
 *                            updated.
 * 
 * All these fields will get updated during the first lwm recording time
 * after the upgrade and subsequently will get maintained there after
 *
 */
declare
  recovery_scn number;
begin
  select nvl(MIN_REQUIRED_CAPTURE_CHANGE#,current_scn) into recovery_scn from
  v$database;

  update  sys.streams$_apply_milestone am
  set pto_recovery_scn = recovery_scn,
      pto_recovery_incarnation = 
        (select max(incarnation#)
         from v$database_incarnation where
          am.apply_time > resetlogs_time 
        )
  where bitand(flags, 1) <> 0;

  commit;
end;
/

Rem *************************************************************************
Rem END changes for Progress Table Optimization 
Rem *************************************************************************

-- populate the sync table with common DDLs for current state
exec dbms_pdb.populatesynctable;

Rem =========================================================================
Rem BEGIN AQ Correct grant for unflushed_dequeues
Rem =========================================================================

DECLARE
  stmt  VARCHAR2(500);
BEGIN

  -- only when it has flags multiple deq(1), multi-cosnumer(8)
  -- and 10i style queue tables(8192)
  FOR cur_rec IN (
                  SELECT distinct(schema)
                  FROM system.aq$_queue_tables
                  WHERE bitand(flags, 1)=1 and
                        bitand(flags, 8)=8 and
                        bitand(flags, 8192)=8192
                 )
  LOOP
    BEGIN
      stmt := 'GRANT SELECT ON aq$_unflushed_dequeues to ' || 
               dbms_assert.enquote_name(cur_rec.schema, FALSE);
      EXECUTE IMMEDIATE stmt;
    END;
  END LOOP;

  EXCEPTION
         WHEN OTHERS THEN
           DBMS_SYSTEM.ksdwrt(DBMS_SYSTEM.trace_file,'error in aq grant:' ||
                              sqlcode);
           RAISE;

END;
/

Rem =========================================================================
Rem END AQ Correct grant for unflushed_dequeues
Rem =========================================================================
Rem =========================================================================
Rem BEGIN AQ Correct subshard,flag,dequeue log
Rem =========================================================================
DECLARE
CURSOR dqm_qptid_to_qm_sbshid IS
SELECT qm.SUBSHARD, dqm.QUEUE_PART#,qm.queue
FROM sys.aq$_queue_partition_map qm, sys.aq$_dequeue_log_partition_map dqm
WHERE  qm.PARTITION# = dqm.QUEUE_PART# and qm.queue = dqm.queue;

BEGIN
FOR dqm_qptid_to_qm_sbshid_crec IN dqm_qptid_to_qm_sbshid LOOP
  update sys.aq$_dequeue_log_partition_map
  set SUBSHARD = dqm_qptid_to_qm_sbshid_crec.subshard
  where QUEUE_PART# = dqm_qptid_to_qm_sbshid_crec.QUEUE_PART# and
  queue=dqm_qptid_to_qm_sbshid_crec.queue;
end loop;
END;
/

commit;
update system.aq$_queues set MEMORY_THRESHOLD=2000 where sharded=1 and
NVL(MEMORY_THRESHOLD,0) = 0;
update sys.aq$_queue_shards set flags = 0;
commit;

DECLARE
CURSOR dql_alter IS
select name, TABLE_OBJNO from system.aq$_queues where sharded =1;
stmt varchar2(500);
tmptabname VARCHAR2(30);
usern VARCHAR2(30);
BEGIN
sys.dbms_aqadm_syscalls.kwqa_3gl_Mark_Internal_Tables
(dbms_aqadm_sys.ENABLE_AQ_DDL);
FOR dql_alter_rec IN dql_alter LOOP
select name into usern from sys.user$ 
where user#=(select owner# from sys.obj$ where obj#=dql_alter_rec.TABLE_OBJNO);
tmptabname := 'AQ$_' || dql_alter_rec.name ||'_L';
    
    stmt := 'alter table '||DBMS_ASSERT.ENQUOTE_NAME(usern)|| '.'||
            tmptabname ||
   ' modify(msgid RAW(16) default ''FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'', ' ||
   ' shard NUMBER default 4294967295, flags NUMBER default 4294967295, '  ||
   ' transaction_id VARCHAR2(30) default ''FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'', '||
   ' dequeue_user VARCHAR2(30) default ''FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF'',' ||
   ' subscriber# default 4294967295 ,retry_count default 0) ' ;
    execute immediate stmt;
    tmptabname := NULL;

end loop;
sys.dbms_aqadm_syscalls.kwqa_3gl_Mark_Internal_Tables
(dbms_aqadm_sys.DISABLE_AQ_DDL);
END;
/


Rem =========================================================================
Rem END AQ Correct subshard,flag,dequeue log table
Rem =========================================================================

Rem *************************************************************************
Rem END a1201000.sql
Rem *************************************************************************
