Rem
Rem $Header: rdbms/admin/c1201000.sql /st_rdbms_12.1/17 2014/06/25 11:11:31 pyam Exp $
Rem
Rem c1201000.sql
Rem
Rem Copyright (c) 2012, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      c1201000.sql - Script to apply current release patch release
Rem
Rem    DESCRIPTION
Rem      This script encapsulates the "post install" steps necessary
Rem      to upgrade the SERVER dictionary to the new patchset version.
Rem      It runs the new patchset versions of catalog.sql and catproc.sql
Rem      and calls the component patch scripts.
Rem
Rem    NOTES
Rem      Use SQLPLUS and connect AS SYSDBA to run this script.
Rem      The database must be open for UPGRADE.
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    surman      06/13/14 - 18977120: Add bundle_series to registry$history
Rem    pyam        06/10/14 - 18764101: add pdb_inv_types$
Rem    sankejai    06/06/14 - 18912837: use replay# in i_pdbsync1 index
Rem    surman      06/05/14 - Backport surman_bug-17277459 from main
Rem    surman      04/21/14 - 17277459: Add bundle columns to SQL registry
Rem    cxie        05/30/14 - Backport cxie_bug-18810866 from main
Rem    aketkar     05/29/14 - bug 18764751: resolve ORA-01449
Rem    pyam        05/27/14 - 18858022: fix reco_script_params$ value column
Rem                           to clob
Rem    atomar      05/20/14 - bkp bug 18799102 unbound_idx, subshard default -1
Rem    suelee      05/12/14 - Backport jomcdon_bug-18622736 from main
Rem    apfwkr      04/28/14 - Backport ssathyan_bug-18288676 from main
Rem    apfwkr      04/24/14 - Backport akruglik_bug-17446096 from main
Rem    surman      04/17/14 - Backport surman_bug-17665117 from main
Rem    dkoppar     02/10/14 - #17665104 add Patch UID col
Rem    apfwkr      04/10/14 - Backport akruglik_bug-18417322 from main
Rem    youyang     04/02/14 - Backport youyang_bug-18442084 from main
Rem    cxie        05/15/14 - add CAUSE colunm to pdb_alert$
Rem    akruglik    04/09/14 - Bug 17446096: populate adminauth$ in a non-CDB
Rem                           using data in v$pwfile_users
Rem    akruglik    04/01/14 - Bug 18417322: adding columns to
Rem                           CDB_LOCAL_ADMINAUTH$
Rem    youyang     03/26/14 - bug18442084:fix type grant_path
Rem    surman      03/19/14 - 17665117: Patch UID
Rem    apfwkr      03/17/14 - Backport pyam_bug-17630050 from main
Rem    ssathyan    03/10/14 - Backport ssathyan_bug-17675121 from main
Rem    ssathyan    03/13/14 - disable_directory_link_check
Rem    jinjche     02/28/14 - Rename a couple of columns
Rem    skayoor     02/21/14 - Bug 18180897: Grant privilege to SYSTEM
Rem    risgupta    02/17/14 - Bug 18174384: Remove Logon/Logoff actions from
Rem                           ORA_SECURECONFIG audit policy
Rem    ssathyan    03/03/14 - 17675121:opatch_xml_inv change charset to utf8
Rem    pyam        02/16/14 - change i_pdbsync2 to non-unique index
Rem    skayoor     01/31/14 - Bug 18019880: Remove admin option from DBA.
Rem    p4kumar     01/21/14 - Bug 17537632
Rem    traney      01/16/14 - 17971391: increase size of opbinding$.functionname
Rem    hlakshma    01/10/14 - Bug-18046497. Handle ORA-02206 
Rem    abrumm      12/24/13 - exadoop-upgrade: add raw attribute to
Rem                           ODCIExtTable[Open,Fetch,Populate,Close]
Rem    rkagarwa    01/06/14 - 17954127: patch synobj# of MDSYS objects
Rem    arbalakr    11/21/13 - Bug17425096: Add Full plan hash value to ASH
Rem    gravipat    12/30/13 - Add pdb_sync$ on upgrade
Rem    pyam        12/19/13 - 17976551: fix ALTER TABLE UPGRADE query
Rem    achaudhr    12/16/13 - 17793123: Add oracle_loader deterministic keyword
Rem    pyam        12/14/13 - readd 17860560 with proper code to support it
Rem    pyam        12/12/13 - 17937809: backout 17860560
Rem    hlakshma    12/10/13 - Add ADO related constraints
Rem    yberezin    12/04/13 - bug 17391276: introduce OS time for
Rem                           capture/replay start
Rem    pyam        12/05/13 - 17670879, 17860560: patch 12.1.0.1 dict problems
Rem    talliu      12/05/13 - revoke grant select_catalog_role on cdb views
REM    tianli      12/04/13 - 17742001: fix process_drop_user_cascade
Rem    jinjche     11/22/13 - Add big SCN support
Rem    praghuna    11/20/13 - Added pto recovery fields to apply milestone
Rem    jmuller     09/17/13 - Fix bug 17250794: upgrade actions re: edition
Rem                           security
REM    surman      10/24/13 - 14563594: Add version to registry$sqlpatch
REM    rpang       10/23/13 - 17637420: add tracking columns to sqltxl tables
Rem    qinwu       10/21/13 - bug 17456719: add divergence_load_status
Rem    cxie        10/16/13 - make index i_pdb_alert2 not unique
Rem    jinjche     10/16/13 - Rename nab to old_blocks
REM    cxie        10/16/13 - make index i_pdb_alert2 not unique
Rem    tianli      10/03/13 - add apply$_cdr_info
Rem    sguirgui    10/02/13 - bug 17191640 - drop wrm$_wr_control_name_uk
Rem    cxie        10/01/13 - add index i_pdb_alert2 on pdb_alert$
Rem    huntran     09/30/13 - add lob apply stats
Rem    sasounda    09/26/13 - proj 47829: add READ ANY TABLE sys priv
Rem    shiyadav    09/26/13 - bug 17348607: modify wrh$_dyn_remaster_stats
Rem    vpriyans    09/21/13 - Bug 17299076: Added ORA_CIS_RECOMMENDATIONS
Rem    minx        09/18/13 - Fix Bug 17478619: drop data realm description 
Rem    amunnoli    09/15/13 - Bug #17459511: mark pwd_verifier column of 
Rem                           default_pwd$ as sensitive 
Rem    dvoss       09/11/13 - bug 17328599: standardize logminer create types
Rem    desingh     08/28/13 - add columns in AQ sys.*_PARTITION_MAP tables
Rem    jerrede     08/28/13 - Fix bug 17267114 Convert Data
Rem    jinjche     08/27/13 - Add a column and rename some columns
Rem    sdball      08/26/13 - Bug 17199155: add db_type to database
Rem    shiyadav    08/22/13 - bug 13375362: increase column width for baseline
Rem    cechen      08/22/13 - add domains for PKI keys in database and cloud
Rem    pxwong      08/12/13 - bug16017445 revoke public grant for dbms_job
Rem    jheng       08/08/13 - Bug 16931220: drop and re-create type grant_path
Rem    schakkap    07/08/13 - #(16576884) revisit indexes for directive tables
Rem    nkgopal     07/16/13 - Bug 14168362: Add dbid, pdb guid to
Rem                           sys.dam_last_arch_ts$
Rem    shiyadav    07/10/13 - Bug 17042658: update the flush_type flag
Rem    mjungerm    07/08/13 - revert addition of CREATE JAVA priv
Rem    pradeshm    07/03/13 - Proj#46908: new columns in RAS principal table
Rem    svivian     06/28/13 - bug 16848187: add con_id to logstdby$events
Rem    cxie        06/13/13 - bug 16863416: add vsn column to container$
Rem    xha         06/03/13 - Bug 16739969: invalid imcflag_stg
Rem    mjungerm    05/23/13 - ignore constraint violations for java privs in
Rem                           case of reupgrade
Rem    cgervasi    05/10/13 - bump up AWR version
Rem    jinjche     05/20/13 - Make the redo_rta_idx a unique index
Rem    svivian     05/17/13 - bug 16684631: add LOGMINING to
Rem                           system_privilege_map
Rem    jovillag    05/08/13 - lrg 9137071 - dont revoke execute from 
Rem                           public from dbms_streams_pub_rpc
Rem    mjungerm    05/06/13 - add create java and related privs
Rem    sdball      05/06/13 - Bug 16770655 - Add weights to region
Rem    sdball      05/15/13 - Bug 16816121: Add data_vers to cloud
Rem    jinjche     05/02/13 - Set default to 0 in newly added columns
Rem    jinjche     04/30/13 - Rename and add columns for cross-endian support
Rem    abrown      04/26/13 - abrown_bug-16594543: Enable logmnrUid to cycle
Rem    jovillag    04/23/13 - bug 16047985 - revoke execute from public from
Rem                           some replication packages
Rem    jekamp      04/10/13 - Project 35591: IMC flag in deferred_stg$
Rem    amunnoli    04/02/13 - Bug #16496620: Enable audit on directory, 
Rem                           pluggable database by default
Rem    minwei      03/18/13 - Bug 13105099: alter index i_aclmv
Rem    sdball      03/12/13 - Bug 16789945: add old_instances to gsm_requests
Rem    sdball      03/06/13 - Move GDS upgrade code here from a1201000.sql
Rem    jkati       02/11/13 - bug#16080525: Enable audit on DBMS_RLS by default
Rem    amunnoli    02/08/13 - Bug 16066652: add  job_flags column in
Rem                           sys.dam_cleanup_jobs$
Rem    praghuna    13/01/11 - Add lwm_upd_time to logstdby$apply_milestone
Rem    sylin       12/27/12 - drop package procedure with zero argument in
Rem                           argument$ view
Rem    cdilling    10/19/12 - patch upgrade script for 12.1.0.1 to 12.1.0.2
Rem    cdilling    10/19/12 - Created
Rem

Rem *************************************************************************
Rem BEGIN c1201000.sql
Rem *************************************************************************

Rem ====================================================================
Rem Begin Changes for Security
Rem ====================================================================
Rem
Rem [17250794] With the new requirement that a user must have USE privilege WITH
Rem GRANT OPTION on an edition in order to make it the default edition, we grant
Rem this privilege to SYSTEM for edition ora$base.
Rem
DECLARE
  edition_does_not_exist EXCEPTION;
  PRAGMA EXCEPTION_INIT(edition_does_not_exist, -38802);
BEGIN
  execute immediate
    'grant use on edition ora$base to system with grant option';
EXCEPTION
  WHEN edition_does_not_exist THEN
    NULL;
END;
/

Rem ====================================================================
Rem End Changes for Security
Rem ====================================================================

Rem *************************************************************************
Rem START Bug 17267114
Rem *************************************************************************

--
-- Guarantee that object types without super types
-- have a NULL super type object ID
--
update sys.type$ set supertoid=null where 
        supertoid='00000000000000000000000000000000';
commit;

Rem *************************************************************************
Rem END Bug 17267114
Rem *************************************************************************

Rem =======================================================================
Rem BEGIN Changes for container$
Rem =======================================================================

rem bug 16863416
alter table container$ rename column spare1 to vsn;


Rem =======================================================================
Rem  END Changes for container$
Rem =======================================================================

rem delete package procedure with zero arguments from argument$
delete from argument$ where argument is null and type#=0 and pls_type is null
  and position#=1 and sequence#=0 and level#=0;

Rem =======================================================================
Rem Begin Changes for Traditional Audit
Rem =======================================================================

rem Bug 16496620
AUDIT DIRECTORY BY ACCESS
/

AUDIT PLUGGABLE DATABASE BY ACCESS
/

Rem =======================================================================
Rem End Changes for Traditional Audit
Rem =======================================================================

Rem =======================================================================
Rem  Begin Changes for Unified Auditing
Rem =======================================================================

rem Bug 16066652
begin
  execute immediate 'alter table sys.dam_cleanup_jobs$ add job_flags number';
exception when others then
  if sqlcode in (-904, -942) then null;
  else raise;
  end if;
end;
/
rem Bug 16080525 : add DBMS_RLS to default out-of-the-box Unified audit policy
alter audit policy ora_secureconfig add actions execute on dbms_rls
/

rem Bug 17299076: audit policy with CIS recommended audit options
CREATE AUDIT POLICY ORA_CIS_RECOMMENDATIONS
              PRIVILEGES SELECT ANY DICTIONARY, CREATE ANY LIBRARY,
                         DROP ANY LIBRARY, CREATE ANY TRIGGER,
                         ALTER ANY TRIGGER, DROP ANY TRIGGER, ALTER SYSTEM 
                 ACTIONS CREATE USER, ALTER USER, DROP USER,
                         CREATE ROLE, DROP ROLE, ALTER ROLE,
                         GRANT, REVOKE, CREATE DATABASE LINK,
                         ALTER DATABASE LINK, DROP DATABASE LINK,
                         CREATE PROFILE, ALTER PROFILE, DROP PROFILE,
                         CREATE SYNONYM, DROP SYNONYM,
                         CREATE PROCEDURE, DROP PROCEDURE, ALTER PROCEDURE
/

rem Bug 18174384: remove Logon/Logoff from default out-of-the-box 
rem Unified audit policy
create audit policy ora_logon_failures actions logon
/
alter audit policy ora_secureconfig drop actions logon, logoff
/

Rem *************************************************************************
Rem Begin Bug 14168362: Support cleanup of old dbid and guid based audit data
Rem *************************************************************************
alter table sys.dam_last_arch_ts$ drop constraint DAM_LAST_ARCH_TS_UK1;
alter table sys.dam_last_arch_ts$ add(database_id     number);
alter table sys.dam_last_arch_ts$ add(container_guid  varchar2(33));

declare
  dbid number;
  pdbguid varchar2(33);
begin
  select dbid into dbid from v$containers
  where name = SYS_CONTEXT('USERENV', 'CON_NAME');
  select guid into pdbguid from v$containers 
  where name = SYS_CONTEXT('USERENV', 'CON_NAME');

  execute immediate 'update sys.dam_last_arch_ts$ ' ||
                    'set database_id = :dbid, container_guid = :pdbguid'
  using dbid, pdbguid;
  commit;
end;
/

alter table sys.dam_last_arch_ts$ modify(database_id not null);
alter table sys.dam_last_arch_ts$ modify(container_guid not null);

drop index sys.i_dam_last_arch_ts$;
create unique index sys.i_dam_last_arch_ts$ on sys.dam_last_arch_ts$
(audit_trail_type#, rac_instance#, database_id, container_guid);

Rem *************************************************************************
Rem End Bug 14168362: Support cleanup of old dbid and guid based audit data
Rem *************************************************************************

Rem =======================================================================
Rem  End Changes for Unified Auditing
Rem =======================================================================

Rem =======================================================================
Rem  Begin Changes for RAS
Rem =======================================================================
-- drop column profile from xs$prin : project#46908
begin
  execute immediate 'alter table sys.xs$prin drop column profile';
exception when others then
  if sqlcode in (-904, -942) then null;
  else raise;
  end if;
end;
/

-- add columns in xs$prin table : project#46908
begin
  execute immediate 'alter table sys.xs$prin add profile# number default 0';
  execute immediate 'alter table sys.xs$prin add ptime date';
  execute immediate 'alter table sys.xs$prin add exptime date';
  execute immediate 'alter table sys.xs$prin add ltime date';
  execute immediate 'alter table sys.xs$prin add lslogontime date';
  execute immediate 'alter table sys.xs$prin add astatus number default 0';
exception when others then
  if sqlcode in (-904, -942) then null;
  else raise;
  end if;
end;
/ 

-- add columns description in xs$instset_rule
  alter table sys.xs$instset_rule add description varchar2(4000) default null;

-- drop type XS$REALM_CONSTRAINT_TYPE 
  drop type XS$REALM_CONSTRAINT_TYPE force;


Rem =======================================================================
Rem  End Changes for RAS
Rem =======================================================================

Rem =======================================================================
Rem  Begin 12.1.0.2 Changes for Logminer
Rem =======================================================================

Rem Must ensure that at least one value has been fetched from logmnr_uids$
Rem to ensure that min is at least 100.  Without min being at least 100
Rem the following alter will fail

SELECT system.logmnr_uids$.nextval
FROM dual;
COMMIT;
ALTER SEQUENCE system.logmnr_uids$
       INCREMENT BY 1 ORDER NOCACHE
       MINVALUE 100
       MAXVALUE 99999 CYCLE ;

BEGIN
  INSERT INTO SYSTEM_PRIVILEGE_MAP(PRIVILEGE,NAME,PROPERTY)
  VALUES (-389, 'LOGMINING', 0);
EXCEPTION
  WHEN OTHERS THEN IF SQLCODE = -00001 THEN NULL; ELSE RAISE; END IF;
END;
/

BEGIN
  INSERT INTO STMT_AUDIT_OPTION_MAP(OPTION#,NAME,PROPERTY)
  VALUES (389, 'LOGMINING', 0);
EXCEPTION
  WHEN OTHERS THEN IF SQLCODE = -00001 THEN NULL; ELSE RAISE; END IF;
END;
/

-- Drop types modified in 12.1.0.2
-- These types are only used as a part of the API for internally used
-- table functions so there should not be any user objects dependent
-- upon them, hence dropping is ok.  Types will be recreated in
-- catlmnr.sql.

drop TYPE SYSTEM.LOGMNR$TAB_GG_RECS;
drop TYPE SYSTEM.LOGMNR$TAB_GG_REC;
drop TYPE SYSTEM.LOGMNR$COL_GG_RECS;
drop TYPE SYSTEM.LOGMNR$COL_GG_REC;

Rem =======================================================================
Rem  End 12.1.0.2 Changes for Logminer
Rem =======================================================================

Rem =======================================================================
Rem  Begin 12.1.0.2 Changes for Logical Standby
Rem =======================================================================

alter table system.logstdby$apply_milestone add (lwm_upd_time DATE);
update system.logstdby$apply_milestone set lwm_upd_time = sysdate;
commit;

alter table system.logstdby$apply_milestone add (spare4 NUMBER);
alter table system.logstdby$apply_milestone add (spare5 NUMBER);
alter table system.logstdby$apply_milestone add (spare6 NUMBER);
alter table system.logstdby$apply_milestone add (spare7 DATE);
alter table system.logstdby$apply_milestone add (pto_recovery_scn NUMBER);
alter table system.logstdby$apply_milestone 
            add (pto_recovery_incarnation NUMBER);


alter table system.logstdby$events add (con_id number);

Rem =======================================================================
Rem  End 12.1.0.2 Changes for Logical Standby
Rem =======================================================================

Rem =======================================================================
Rem BEGIN IMC flag changes
Rem =======================================================================

Rem File dcore.bsq - add imc flag to deferred_stg$
alter table deferred_stg$ add (imcflag_stg number);

Rem =======================================================================
Rem END IMC flag changes
Rem =======================================================================

Rem =======================================================================
Rem  Begin 12.2 Changes for Physical Standby
Rem =======================================================================

alter table system.redo_db  rename column spare2 to endian;
alter table system.redo_db  rename column spare3 to enqidx;
alter table system.redo_db  rename column scn1_bas to resetlogs_scn;
alter table system.redo_db  rename column scn1_wrp to presetlogs_scn;
alter table system.redo_db  rename column scn1_time to gap_ret2;
alter table system.redo_db  rename column curscn_bas to gap_next_scn;
alter table system.redo_db  rename column curscn_wrp to gap_next_time;
alter table system.redo_db  add (spare8 NUMBER default 0);
alter table system.redo_db  add (spare9 NUMBER default 0);
alter table system.redo_db  add (spare10 NUMBER default 0);
alter table system.redo_db  add (spare11 NUMBER default 0);
alter table system.redo_db  add (spare12 NUMBER default 0);
update system.redo_db set resetlogs_scn_bas=0, resetlogs_scn_wrp=0, resetlogs_time=2, presetlogs_scn_bas=0, presetlogs_scn_wrp=0 where dbid=0 and thread#=0;

alter table system.redo_log  rename column spare1 to endian;
alter table system.redo_log  rename column current_scn_bas to first_scn;
alter table system.redo_log  rename column current_scn_wrp to next_scn;
alter table system.redo_log  rename column current_time to resetlogs_scn;
alter table system.redo_log  rename column current_blkno to presetlogs_scn;
alter table system.redo_log  rename column nab to old_blocks;
alter table system.redo_log  add (spare8 NUMBER default 0);
alter table system.redo_log  add (spare9 NUMBER default 0);
alter table system.redo_log  add (spare10 NUMBER default 0);
alter table system.redo_log  add (old_status1 NUMBER default 0);
alter table system.redo_log  add (old_status2 NUMBER default 0);
alter table system.redo_log  add (old_filename VARCHAR2(513) default '');

alter table system.redo_rta  rename column rlsb to rls;
alter table system.redo_rta  rename column rlsw to spare9;
alter table system.redo_rta  rename column pscnb to pscn;
alter table system.redo_rta  rename column pscnw to spare10;
alter table system.redo_rta  rename column rscnb to rscn;
alter table system.redo_rta  rename column rscnw to spare11;
alter table system.redo_rta  add (spare7 NUMBER default 0);
alter table system.redo_rta  add (spare8 NUMBER default 0);

drop index system.redo_rta_idx;
CREATE UNIQUE INDEX system.redo_rta_idx ON
        system.redo_rta(dbid, thread)
        TABLESPACE SYSAUX LOGGING
/

Rem =======================================================================
Rem  End 12.2 Changes for Physical Standby
Rem =======================================================================

Rem ====================================================================
Rem BEGIN GDS changes since 12.1.0.1
Rem ===================================================================

-- create gsmadmin_internal user in case it doesn't already exist (upgrade
-- from pre 12.1 release)
CREATE USER gsmadmin_internal identified by gsm
  account lock password expire
  default tablespace sysaux
  quota 100M on sysaux
/

ALTER SESSION SET CURRENT_SCHEMA = gsmadmin_internal
/

-- Create types to hold database specific service information

CREATE TYPE dbparams_t AS OBJECT (
    param_name     VARCHAR2(30),
    param_value    VARCHAR2(100))
/

CREATE TYPE dbparams_list IS VARRAY(10) OF dbparams_t
/

CREATE TYPE rac_instance_t AS OBJECT (
    instance_name  VARCHAR2(30),
    pref_or_avail  CHAR(1)          -- 'P' (preferred)
                                    -- 'A' (available)
)
/

CREATE TYPE instance_list IS TABLE OF rac_instance_t
/

ALTER TABLE service_preferred_available ADD 
   dbparams        dbparams_list DEFAULT NULL
/

ALTER TABLE service_preferred_available ADD
   instances       instance_list DEFAULT NULL
NESTED TABLE instances STORE AS instances_nt
/

ALTER TABLE service_preferred_available ADD
    change_state    CHAR(1) DEFAULT NULL -- record is being changed ?
                                -- NULL - No changes in progress
                                -- 'N' - change is being procesed
/

ALTER TABLE region ADD
   change_state    CHAR(1) DEFAULT NULL -- record is being changed ?
                                -- NULL - No changes in progress
                                -- 'N' - change is being procesed
/

ALTER TABLE region ADD
   weights         VARCHAR2(500) DEFAULT NULL -- weight for manual RLB override
/

ALTER TABLE service ADD
   change_state    CHAR(1) DEFAULT NULL -- record is being changed ?
                                -- NULL - No changes in progress
                                -- 'N' - change is being procesed
/

ALTER TABLE database ADD
   srlat_thresh    NUMBER      DEFAULT 20  -- disk threshold
/

ALTER TABLE database ADD
   cpu_thresh      NUMBER      DEFAULT 75  -- cpu threshold
/

ALTER TABLE database ADD
   version         VARCHAR(30) DEFAULT NULL --database version
/

ALTER TABLE database ADD
   db_type         CHAR(1)     DEFAULT NULL -- database type
/

ALTER TABLE database ADD
   encrypted_gsm_password      RAW(2000)  DEFAULT NULL --encrypted gsm password
/

ALTER TABLE cloud ADD
   private_key      RAW(2000)      DEFAULT NULL  -- PKI private key
/

ALTER TABLE cloud ADD
   public_key       RAW(2000)      DEFAULT NULL  -- PKI public key
/

ALTER TABLE cloud ADD
   prvk_enc_str    RAW(1000)  DEFAULT NULL -- flag for private key status
/

ALTER TABLE gsm ADD
   version         VARCHAR(30) DEFAULT NULL  -- GSM version
/

ALTER TABLE gsm ADD
   change_state    CHAR(1) DEFAULT NULL -- record is being changed ?
                                -- NULL - No changes in progress
                                -- 'N' - change is being procesed
/

ALTER TYPE gsm_change_message
   MODIFY ATTRIBUTE additional_params VARCHAR(4000) CASCADE
/

ALTER TABLE gsm_requests ADD
   old_instances   instance_list DEFAULT NULL
NESTED TABLE old_instances STORE AS old_instances_nt
/

ALTER TABLE cloud ADD
   data_vers       VARCHAR2(30) DEFAULT NULL
/

ALTER SESSION SET CURRENT_SCHEMA = SYS
/

COMMIT;

Rem ====================================================================
Rem END GDS changes since 12.1.0.1
Rem ===================================================================

Rem =========================================================================
Rem BEGIN dictionary changes for static ACL MV
Rem =========================================================================

drop index i_acl_mv$_1;
create unique index i_aclmv$_1 on aclmv$(table_obj#, acl_mview_obj#);

Rem =========================================================================
Rem END dictionary changes for  static ACL MV
Rem =========================================================================

Rem =========================================================================
Rem BEGIN Replication changes (Repcat, Streams, XStream, OGG) 
Rem =========================================================================

-- Bug 16047985: Revoke execute grant from public on these packages; 
-- ignore the following errors:
-- -04042: Procedure, function, package, or package body does not exist 
-- -01927: Cannot REVOKE privileges you did not grant

BEGIN
  EXECUTE IMMEDIATE 'REVOKE EXECUTE ON dbms_checksum FROM PUBLIC';
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE IN ( -04042, -1927 ) THEN NULL;
    ELSE RAISE;
    END IF;
END;
/

BEGIN
  EXECUTE IMMEDIATE 'REVOKE EXECUTE ON dbms_offline_rgt FROM PUBLIC';
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE IN ( -04042, -1927 ) THEN NULL;
    ELSE RAISE;
    END IF;
END;
/

BEGIN
  EXECUTE IMMEDIATE 'REVOKE EXECUTE ON lcr$_parameter_list FROM PUBLIC';
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE IN ( -04042, -1927 ) THEN NULL;
    ELSE RAISE;
    END IF;
END;
/

rem stores the CDR resolution information for populating IR exception tables
create table apply$_cdr_info
(
  local_transaction_id  varchar2(22),      /*local id of txn that errors out */
  Source_transaction_id varchar2(128),       /* transaction id at the source */
  source_database       varchar2(128),       /* db which originated this txn */   
  error_number          number,                     /* error number reported */
  error_message         varchar2(4000),              /* explanation of error */
  source_object_owner   varchar2(30),        /* source database object owner */
  source_object_name    varchar2(30),         /* source database object name */
  dest_object_owner     varchar2(30),          /* dest database object owner */
  dest_object_name      varchar2(30),           /* dest database object name */
  operation             number,                             /* LCR operation */
  position              raw(64),                             /* LCR position */
  seq#                  number,                /* seq# of the replicat trail */
  rba                   number,                 /* rba of the replicat trail */
  index#                number,            /* index # of the replicat record */
  resolution_status     number,                    /* 1. SUCCEEDED 2. FAILED */
  resolution_column     varchar2(4000),        /* column used for resolution */
  resolution_method     number,            /* resolution method
                                            * 1 RECORD, 2 IGNORE, 3 OVERWRITE,
                                            * 4 MAXIMUM, 5 MINIMUM, 6 DELTA  */
  resolution_time       timestamp,           /* time when resolution happens */
  table_successful_cdr  number, /* # of successful resolutions for the table */
  table_failed_cdr      number,     /* # of failed resolutions for the table */
  all_successful_cdr    number, /* # of successful resolutions for the table */
  all_failed_cdr        number,     /* # of failed resolutions for the table */
  flags                 number,                                     /* flags */
  spare1                number,
  spare2                varchar2(4000),
  spare3                timestamp
)
/
create unique index apply$_cdr_info_unq1
 on apply$_cdr_info(local_transaction_id,seq#,rba,index#)
/

alter table sys.apply$_table_stats add (lob_operations NUMBER default 0);

DELETE FROM sys.duc$ WHERE owner='SYS' AND pack='DBMS_STREAMS_ADM_UTL' 
  AND proc='PROCESS_DROP_USER_CASCADE' AND operation#=1;


alter table sys.streams$_apply_milestone add (pto_recovery_scn number);
alter table sys.streams$_apply_milestone add (pto_recovery_incarnation  number);



Rem =========================================================================
Rem END Replication changes (Repcat, Streams, XStream, OGG)  
Rem =========================================================================

Rem =========================================================================
Rem BEGIN AWR Changes
Rem =========================================================================

alter table wrm$_baseline modify (baseline_name  VARCHAR2(128));
alter table wrm$_baseline modify (template_name  VARCHAR2(128));

alter table wrm$_baseline_template modify (template_name VARCHAR2(128));
alter table wrm$_baseline_template modify (baseline_name_prefix VARCHAR2(128));

alter table wrh$_dyn_remaster_stats add 
        (remaster_type varchar2(11) default 'AFFINITY' not null);

alter table wrh$_dyn_remaster_stats drop constraint wrh$_dyn_remaster_stats_pk;

alter table wrh$_dyn_remaster_stats add constraint wrh$_dyn_remaster_stats_pk 
        primary key (dbid, snap_id, instance_number, con_dbid, remaster_type);


Rem Drop the WRM$_WR_CONTROL_NAME_UK constraint, and ignore
Rem error in case constraint did not exist (ORA 02443)

BEGIN
  EXECUTE IMMEDIATE 'alter table wrm$_wr_control 
                     drop constraint WRM$_WR_CONTROL_NAME_UK';
EXCEPTION
  WHEN OTHERS THEN
    IF (SQLCODE = -2443) THEN
      NULL;
    ELSE
      RAISE;
    END IF;  
END;
/

Rem ****************************************************************
Rem * Set "flush_type" flag to 1 for existing non-local DBIDs
Rem ****************************************************************
BEGIN
  EXECUTE IMMEDIATE 'UPDATE wrm$_wr_control ' ||
                    '   SET flush_type = 1 '  ||
                    ' WHERE dbid != (SELECT dbid FROM v$database)';
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    IF (SQLCODE = -942) THEN
      NULL;
    ELSE
      RAISE; 
    END IF;
END;
/

Rem *************************************************************************
Rem Increment AWR version for 12.1.0.2
Rem *************************************************************************
Rem =======================================================
Rem ==  Update the SWRF_VERSION to the current version.  ==
Rem ==          (12cR102   = SWRF Version 11)            ==
Rem ==  This step must be the last step for the AWR      ==
Rem ==  upgrade changes.  Place all other AWR upgrade    ==
Rem ==  changes above this.                              ==
Rem =======================================================

BEGIN
  EXECUTE IMMEDIATE 'UPDATE wrm$_wr_control SET swrf_version = 11';
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    IF (SQLCODE = -942) THEN
      NULL;
    ELSE
      RAISE;
    END IF;
END;
/

Rem *************************************************************************
Rem End Increment AWR version
Rem *************************************************************************

Rem ========================================================================
Rem END AWR Changes
Rem =========================================================================

Rem ========================================================================
Rem BEGIN scheduler Changes
Rem =========================================================================
BEGIN
  EXECUTE IMMEDIATE 'REVOKE EXECUTE ON dbms_job FROM PUBLIC';
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE IN ( -04042, -1927 ) THEN NULL;
    ELSE RAISE;
    END IF;
END;
/

Rem ========================================================================
Rem END scheduler Changes
Rem =========================================================================

Rem =========================================================================
Rem BEGIN Privilege Analysis Changes
Rem =========================================================================
alter table sys.priv_used_path$ drop column path;
alter table sys.priv_unused_path$ drop column path;

drop type sys.grant_path;
create or replace type sys.grant_path AS VARRAY(150) OF VARCHAR2(128);
/
create or replace PUBLIC synonym grant_path for sys.grant_path;
/
grant execute on grant_path to PUBLIC;

ALTER TABLE sys.priv_used_path$ add path sys.grant_path;
ALTER TABLE sys.priv_unused_path$ add path sys.grant_path;

Rem =========================================================================
Rem END Privilege Analysis Changes
Rem =========================================================================

Rem =========================================================================
Rem BEGIN changes specific to proj 47829 - insert READ ANY TABLE sys priv
Rem =========================================================================
BEGIN
  INSERT INTO SYSTEM_PRIVILEGE_MAP(PRIVILEGE,NAME,PROPERTY)
  VALUES (-397, 'READ ANY TABLE', 0);
EXCEPTION
  WHEN OTHERS THEN IF SQLCODE = -00001 THEN NULL; ELSE RAISE; END IF;
END;
/

-- auditing support
BEGIN
  INSERT INTO STMT_AUDIT_OPTION_MAP(OPTION#,NAME,PROPERTY)
  VALUES (397, 'READ ANY TABLE', 0);
EXCEPTION
  WHEN OTHERS THEN IF SQLCODE = -00001 THEN NULL; ELSE RAISE; END IF;
END;
/
Rem =========================================================================
Rem END changes specific to proj 47829
Rem =========================================================================

Rem *************************************************************************
Rem BEGIN Bug 17459511 Mark pwd_verifier column of default_pwd$ as sensitive
Rem *************************************************************************

update col$ set property = property + 8796093022208 - bitand(property, 8796093022208) where name = 'PWD_VERIFIER' and obj# = (select obj# from obj$ where name = 'DEFAULT_PWD$' and owner# = (select user# from user$ where name = 'SYS'))
/
commit;

Rem *************************************************************************
Rem END Bug 17459511 Mark pwd_verifier column of default_pwd$ as sensitive
Rem *************************************************************************


Rem =======================================================================
Rem  Begin changes for AQ SYS.*_PARTITION_MAP tables & *_pmap* types.
Rem =======================================================================

alter table sys.aq$_queue_partition_map add (unbound_idx   NUMBER default -1);
alter table sys.aq$_dequeue_log_partition_map add (subshard   NUMBER default -1);
alter table sys.aq$_dequeue_log_partition_map add (unbound_idx   NUMBER default -1);


DROP TYPE sys.sh$qtab_pmap_list;

create or replace type sys.sh$qtab_pmap as object(
 queue number,
 shard number,
 priority number,
 subshard number,
 partition# number,
 partname  varchar2(30),
 map_time   TIMESTAMP(6) WITH TIME ZONE,
 instance number,
 unbound_idx    number,

 CONSTRUCTOR FUNCTION sh$qtab_pmap (queue NUMBER, shard number, priority number,
                     subshard number, partition# number, partname  varchar2,
             map_time TIMESTAMP WITH TIME ZONE, instance number)
             RETURN SELF AS RESULT

 );
/

CREATE OR REPLACE TYPE BODY sh$qtab_pmap AS
  CONSTRUCTOR FUNCTION sh$qtab_pmap (queue NUMBER, shard number, priority number,
                     subshard number, partition# number, partname  varchar2,
             map_time TIMESTAMP WITH TIME ZONE, instance number)
             RETURN SELF AS RESULT
  IS
  BEGIN
    self.queue := queue;
    self.shard := shard;
    self.priority := priority;
    self.subshard := subshard;
    self.partition# := partition#;
    self.partname := partname;
    self.map_time := map_time;
    self.instance := instance;
    self.unbound_idx := -1;
      return;
  END;

END;
/

CREATE or replace TYPE sys.sh$qtab_pmap_list AS VARRAY(1000000) OF sys.sh$qtab_pmap;
/

DROP TYPE sys.sh$deq_pmap_list;

create or replace type sys.sh$deq_pmap as object(
 queue number,
 queue_part# number,
 subshard    number,
 subscriber_id number,
 instance number,
 partition# number,
 partname varchar2(30),
 flag number,
 unbound_idx    number,

 CONSTRUCTOR FUNCTION sh$deq_pmap (queue number,queue_part# number,
  subscriber_id number, instance   number,
  partition#  number, partname  varchar2, flag   number)
  RETURN SELF AS RESULT

 );
/

CREATE OR REPLACE TYPE BODY sh$deq_pmap AS
  CONSTRUCTOR FUNCTION sh$deq_pmap (queue number,queue_part# number,
  subscriber_id number, instance   number,
  partition#  number, partname  varchar2, flag   number)
  RETURN SELF AS RESULT
  IS
  BEGIN
    self.queue := queue;
    self.queue_part# := queue_part#;
    self.subscriber_id := subscriber_id;
    self.instance := instance;
    self.partition# := partition#;
    self.partname := partname;
    self.flag := flag;
    self.subshard := 0;
    self.unbound_idx := -1;

       return;
  END;

END;
/

CREATE OR REPLACE TYPE sys.sh$deq_pmap_list AS VARRAY(1000000) OF sys.sh$deq_pmap;
/

Rem =======================================================================
Rem  End changes for AQ *_PARTITION_MAP tables  & *_pmap* types.
Rem =======================================================================


Rem ====================================================================
Rem BEGIN changes for PDB_ALERT$
Rem ====================================================================
CREATE INDEX i_pdb_alert2 ON pdb_alert$(name, cause#)
/
alter table pdb_alert$ add (cause varchar(64));
update pdb_alert$ set cause=decode(cause#, 
  36, 'Database CHARACTER SET', 37, 'NATIONAL CHARACTER SET', 
  39, 'OPTION',  40, 'OLS Configuration', 41, 'Database Vault', 
  42, 'Non-CDB to PDB', 43, 'Sync Failure', 43, 'APEX', 45, 'APEX', 
  46, 'APEX', 48, 'Parameter', 50, 'SQL Patch', 51, 'Offline Tablespace',
  52, 'No CDB spfile', 54, 'Time Zone Version', 55, 'Wallet Key Needed', 
  57, 'Service Name Conflict', 59, 'Oracle Opatch',
  60, 'PDB version not allowed', 63, 'AWR load profile', 65, 'VSN not match', 
  'UNDEFINED');

Rem ====================================================================
Rem End changes for PDB_ALERT$
Rem ===================================================================

Rem ====================================================================
Rem BEGIN changes for PDB_INV_TYPE$
Rem ====================================================================
create table pdb_inv_type$
(
  owner     varchar2(128),                                /* type owner */
  type_name varchar2(128)                                  /* type name */
)
/
Rem ====================================================================
Rem End changes for PDB_INV_TYPE$
Rem ===================================================================

Rem *************************************************************************
Rem Revisit indexes for SQL Plan Directive dictionary tables for 12.1.0.2
Rem #(16576884)
Rem *************************************************************************

drop index sys.i_opt_directive_last_used;

drop index sys.i_opt_directive_own#_id;

create unique index sys.i_opt_directive_dirid on
  opt_directive$(dir_id)
  tablespace sysaux
/

create index sys.i_opt_directive_dirown# on
  opt_directive$(dir_own#)
  tablespace sysaux
/

Rem =======================================================================
Rem  Begin Changes for Database Workload Capture and Replay
Rem =======================================================================
Rem
Rem Add columns introduced in 12.1.0.2
ALTER TABLE wrr$_captures ADD( internal_start_time INTEGER );
ALTER TABLE wrr$_replays  ADD( divergence_load_status VARCHAR2(5) );
ALTER TABLE wrr$_replays  ADD( internal_start_time INTEGER );

Rem =======================================================================
Rem  End Changes for Database Workload Capture and Replay
Rem =======================================================================

Rem *************************************************************************
Rem End Revisit indexes for SQL Plan Directive dictionary tables for 12.1.0.2
Rem *************************************************************************

Rem =======================================================================
Rem Begin Changes for WRH$_ACTIVE_SESSION_HISTORY
Rem - Add columns to ASH
Rem =======================================================================
alter table WRH$_ACTIVE_SESSION_HISTORY add (sql_full_plan_hash_value NUMBER);
alter table WRH$_ACTIVE_SESSION_HISTORY add (sql_adaptive_plan_resolved NUMBER);

alter table WRH$_ACTIVE_SESSION_HISTORY_BL
           add (sql_full_plan_hash_value NUMBER);
alter table WRH$_ACTIVE_SESSION_HISTORY_BL 
           add (sql_adaptive_plan_resolved NUMBER);
Rem =======================================================================
Rem End Changes for WRH$_ACTIVE_SESSION_HISTORY
Rem =======================================================================


Rem =========================================================================
Rem Begin ADO changes
Rem =========================================================================
Rem
Rem
Rem Add referential constraints introduced in 12.1.0.2 to ADO execution 
Rem related dictionary tables

drop index  sys.i_ilmexec_execid;

DECLARE
  primary_key_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(primary_key_exists, -02260);
BEGIN
  execute immediate
    'alter table sys.ilm_execution$ add constraint pk_taskid ' ||
    ' primary key (execution_id) ' ;
EXCEPTION
  WHEN primary_key_exists THEN
    NULL;
END;
/

DECLARE
  foreign_key_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(foreign_key_exists, -02275);
BEGIN
  execute immediate
    'alter table sys.ilm_executiondetails$ add constraint  fk_execdet ' ||
    ' foreign key (execution_id) references  ilm_execution$(execution_id) ' ||
    ' on delete cascade ' ;
EXCEPTION
  WHEN foreign_key_exists THEN
    NULL;
END;
/

drop index sys.i_ilm_results$;

DECLARE
  primary_key_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(primary_key_exists, -02260);
BEGIN
  execute immediate
    'alter table sys.ilm_results$ add constraint pk_res ' ||
    ' primary key (jobname) ' ;
EXCEPTION
  WHEN primary_key_exists THEN
    NULL;
END;
/


DECLARE
  foreign_key_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(foreign_key_exists, -02275);
BEGIN
  execute immediate
    'alter table sys.ilm_results$ add constraint  fk_res ' ||
    ' foreign key (execution_id) references  ilm_execution$(execution_id) ' ||
    ' on delete cascade ' ;
EXCEPTION
  WHEN foreign_key_exists THEN
    NULL;
END;
/

DECLARE
  foreign_key_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(foreign_key_exists, -02275);
BEGIN
  execute immediate
    'alter table sys.ilm_result_stat$ add constraint  fk_resst ' ||
    ' foreign key (jobname) references  ilm_results$(jobname) ' ||
    ' on delete cascade ' ;
EXCEPTION
  WHEN foreign_key_exists THEN
    NULL;
END;
/

DECLARE
  foreign_key_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(foreign_key_exists, -02275);
BEGIN
  execute immediate
    'alter table sys.ilm_dependant_obj$ add constraint  fk_depobj' ||
    ' foreign key (execution_id) references  ilm_execution$(execution_id) ' ||
    ' on delete cascade ' ;
EXCEPTION
  WHEN foreign_key_exists THEN
    NULL;
END;
/


DECLARE
  foreign_key_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(foreign_key_exists, -02275);
BEGIN
  execute immediate
    'alter table sys.ilm_dependant_obj$ add constraint  fk_depobjjobn' ||
    ' foreign key (par_jobname) references  ilm_results$(jobname) ' ||
    ' on delete cascade ' ;
EXCEPTION
  WHEN foreign_key_exists THEN
    NULL;
END;
/

DECLARE
  foreign_key_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(foreign_key_exists, -02275);
BEGIN
  execute immediate
    'alter table sys.ilm_dep_executiondetails$ add constraint  fk_depdet' ||
    ' foreign key (execution_id) references  ilm_execution$(execution_id) ' ||
    ' on delete cascade ' ;
EXCEPTION
  WHEN foreign_key_exists THEN
    NULL;
END;
/

DECLARE
  foreign_key_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(foreign_key_exists, -02275);
BEGIN
  execute immediate
    'alter table sys.ilm_dep_executiondetails$ add constraint fk_depdetjobn' ||
    ' foreign key (par_jobname) references  ilm_results$(jobname) ' ||
    ' on delete cascade ' ;
EXCEPTION
  WHEN foreign_key_exists THEN
    NULL;
END;
/

Rem =========================================================================
Rem End ADO changes
Rem =========================================================================

Rem *************************************************************************
Rem Begin Bug 17637420: Add tracking columns to SQL and error translation tables
Rem *************************************************************************

alter table sqltxl_sql$ add(rtime timestamp);
alter table sqltxl_sql$ add(cinfo varchar2(64));
alter table sqltxl_sql$ add(module varchar2(64));
alter table sqltxl_sql$ add(action varchar2(64));
alter table sqltxl_sql$ add(puser# number);
alter table sqltxl_sql$ add(pschema# number);
alter table sqltxl_sql$ add(comment$ varchar2(4000));

alter table sqltxl_err$ add(rtime timestamp);
alter table sqltxl_err$ add(comment$ varchar2(4000));

Rem *************************************************************************
Rem End Bug 17637420
Rem *************************************************************************

Rem *************************************************************************
Rem 17670879: remove extraneous local Oracle-supplied system privileges
Rem *************************************************************************

update sysauth$
   set option$=bitand(option$,56)+4
 where sys_context('USERENV', 'CON_ID') > 1
   and grantee# in (select user# from user$ where bitand(spare1,256)<>0)
   and privilege#<0
   and bitand(option$, 12)=8;
commit;

Rem *************************************************************************
Rem End 17670879
Rem *************************************************************************

Rem *************************************************************************
Rem 17860560: run ALTER TABLE UPGRADE on table dependents of types
Rem *************************************************************************

-- run ALTER TABLE UPGRADE on table dependents of common types
DECLARE
  cursor c is
    select u.name owner, o.name object_name
      from sys.obj$ o, sys.user$ u
    where sys_context('userenv', 'con_id') > 1 and
      o.type#=2 and u.user#=o.owner# and obj# in
      (select d_obj# from sys.dependency$ d, sys.obj$ typo where
       typo.type#=13 and typo.obj#=d.p_obj# and d.p_timestamp <> typo.stime and
       bitand(typo.flags, 196608)<>0);
BEGIN
  FOR tab in c
  LOOP
    execute immediate 'ALTER TABLE ' ||
                      dbms_assert.enquote_name(tab.owner, FALSE) || '.' ||
                      dbms_assert.enquote_name(tab.object_name, FALSE) ||
                      ' UPGRADE';
  END LOOP;
  commit;
END;
/

Rem *************************************************************************
Rem End 17860560
Rem *************************************************************************

Rem *************************************************************************
Rem Begin Bug 17526652 17526621 revoke select_catalog_role
Rem *************************************************************************

begin
  execute immediate 'revoke select on cdb_keepsizes from select_catalog_role';
  execute immediate 'revoke select on cdb_analyze_objects from select_catalog_role';
exception when others then
  if sqlcode in (-1927, -942) then null;
  else raise;
  end if;
end;
/

Rem *************************************************************************
Rem End Bug 17526652 17526621
Rem *************************************************************************

Rem ********************************************************************
Rem Begin sys.ORACLE_LOADER: Make methods deterministic for Result Cache
Rem                        : Add xtArgs argument to Open,Fetch,
Rem                          Populate,Close methods.
Rem ********************************************************************

-- Make all the methods of ORACLE_LOADER type DETERMINISTIC 
-- by dropping and then recreating each of them with the new 
-- annotation. (This approach is required for "upgrade" to 
-- work correctly.)
-- Also, add the xtArgs attribute from each method by dropping and
-- and recreating each method WITH the attibute.

ALTER TYPE sys.oracle_loader DROP 
  STATIC FUNCTION ODCIGetInterfaces(ifclist OUT NOCOPY SYS.ODCIObjectList)
         RETURN NUMBER;
ALTER TYPE sys.oracle_loader ADD 
  STATIC FUNCTION ODCIGetInterfaces(ifclist OUT NOCOPY SYS.ODCIObjectList)
         RETURN NUMBER DETERMINISTIC;

ALTER TYPE sys.oracle_loader DROP
  STATIC FUNCTION ODCIExtTableOpen(lctx  IN OUT NOCOPY oracle_loader,
                                   xti   IN            SYS.ODCIExtTableInfo,
                                   xri      OUT NOCOPY SYS.ODCIExtTableQCInfo,
                                   pcl      OUT NOCOPY SYS.ODCIColInfoList2,
                                   flag  IN OUT        number,
                                   strv  IN OUT        number,
                                   env   IN            SYS.ODCIEnv)
         RETURN number;
ALTER TYPE sys.oracle_loader ADD
  STATIC FUNCTION ODCIExtTableOpen(lctx   IN OUT NOCOPY oracle_loader,
                                   xti    IN            SYS.ODCIExtTableInfo,
                                   xri       OUT NOCOPY SYS.ODCIExtTableQCInfo,
                                   pcl       OUT NOCOPY SYS.ODCIColInfoList2,
                                   flag   IN OUT        number,
                                   strv   IN OUT        number,
                                   env    IN            SYS.ODCIEnv,
				   xtArgs IN OUT        raw)
         RETURN number DETERMINISTIC;

ALTER TYPE sys.oracle_loader DROP
  MEMBER FUNCTION ODCIExtTableFetch(gnum   IN     number,
                                    cnverr IN OUT number,
                                    flag   IN OUT number,
                                    env    IN     SYS.ODCIEnv)
         RETURN number;
ALTER TYPE sys.oracle_loader ADD
  MEMBER FUNCTION ODCIExtTableFetch(gnum   IN     number,
                                    cnverr IN OUT number,
                                    flag   IN OUT number,
                                    env    IN     SYS.ODCIEnv,
				   xtArgs  IN OUT raw)
         RETURN number DETERMINISTIC;

ALTER TYPE sys.oracle_loader DROP
  MEMBER FUNCTION ODCIExtTablePopulate(flag IN OUT number,
                                       env  IN     SYS.ODCIEnv)
         RETURN number;
ALTER TYPE sys.oracle_loader ADD
  MEMBER FUNCTION ODCIExtTablePopulate(flag   IN OUT number,
                                       env    IN     SYS.ODCIEnv,
				       xtArgs IN OUT raw)
         RETURN number DETERMINISTIC;

ALTER TYPE sys.oracle_loader DROP
  MEMBER FUNCTION ODCIExtTableClose(flag IN OUT number,
                                    env  IN     SYS.ODCIEnv)
         RETURN number;
ALTER TYPE sys.oracle_loader ADD
  MEMBER FUNCTION ODCIExtTableClose(flag  IN OUT number,
                                    env   IN     SYS.ODCIEnv,
				   xtArgs IN OUT raw)
         RETURN number DETERMINISTIC;

Rem ********************************************************************
Rem End   sys.ORACLE_LOADER: Make methods deterministic for Result Cache
Rem                        : Add xtArgs argument to Open,Fetch,
Rem                          Populate,Close methods.
Rem ********************************************************************

Rem ********************************************************************
Rem Begin sys.ORACLE_DATAPUMP: Add xtArgs argument from Open,Fetch,
Rem                            Populate,Close methods.
Rem ********************************************************************

-- Add the xtArgs attribute from each method by dropping and
-- and recreating each method WITH the attibute.

ALTER TYPE sys.oracle_datapump DROP
  STATIC FUNCTION ODCIExtTableOpen(lctx  IN OUT NOCOPY oracle_datapump,
                                   xti   IN            SYS.ODCIExtTableInfo,
                                   xri      OUT NOCOPY SYS.ODCIExtTableQCInfo,
                                   pcl      OUT NOCOPY SYS.ODCIColInfoList2,
                                   flag  IN OUT        number,
                                   strv  IN OUT        number,
                                   env   IN            SYS.ODCIEnv)
         RETURN number;
ALTER TYPE sys.oracle_datapump ADD
  STATIC FUNCTION ODCIExtTableOpen(lctx   IN OUT NOCOPY oracle_datapump,
                                   xti    IN            SYS.ODCIExtTableInfo,
                                   xri       OUT NOCOPY SYS.ODCIExtTableQCInfo,
                                   pcl       OUT NOCOPY SYS.ODCIColInfoList2,
                                   flag   IN OUT        number,
                                   strv   IN OUT        number,
                                   env    IN            SYS.ODCIEnv,
				   xtArgs IN OUT        raw)
         RETURN number;

ALTER TYPE sys.oracle_datapump DROP
  MEMBER FUNCTION ODCIExtTableFetch(gnum   IN     number,
                                    cnverr IN OUT number,
                                    flag   IN OUT number,
                                    env    IN     SYS.ODCIEnv)
         RETURN number;
ALTER TYPE sys.oracle_datapump ADD
  MEMBER FUNCTION ODCIExtTableFetch(gnum   IN     number,
                                    cnverr IN OUT number,
                                    flag   IN OUT number,
                                    env    IN     SYS.ODCIEnv,
				    xtArgs IN OUT raw)
         RETURN number;

ALTER TYPE sys.oracle_datapump DROP
  MEMBER FUNCTION ODCIExtTablePopulate(flag IN OUT number,
                                       env  IN     SYS.ODCIEnv)
         RETURN number;
ALTER TYPE sys.oracle_datapump ADD
  MEMBER FUNCTION ODCIExtTablePopulate(flag   IN OUT number,
                                       env    IN     SYS.ODCIEnv,
				       xtArgs IN OUT raw)
         RETURN number;

ALTER TYPE sys.oracle_datapump DROP
  MEMBER FUNCTION ODCIExtTableClose(flag IN OUT number,
                                    env  IN     SYS.ODCIEnv)
         RETURN number;
ALTER TYPE sys.oracle_datapump ADD
  MEMBER FUNCTION ODCIExtTableClose(flag  IN OUT number,
                                    env   IN     SYS.ODCIEnv,
				   xtArgs IN OUT raw)
         RETURN number;

Rem ********************************************************************
Rem End   sys.ORACLE_DATAPUMP: Add xtArgs argument from Open,Fetch,
Rem                            Populate,Close methods.
Rem ********************************************************************

Rem =======================================================================
Rem BEGIN Changes for pdb_sync$
Rem =======================================================================
REM This table stores some information about any common ddl changes that may
REM have happened in root when one or more of the pdbs were closed. This will
REM be consulted during the next read write open of the pdb to sync only the
REM changed information.
REM This table usually has data in root only.
create table pdb_sync$
(
  scnwrp      number not null,       /* scnbas - scn base, scnwrp - scn wrap */
  scnbas      number not null,                 /* scn for the current change */
  ctime       date not null,                                /* creation time */
  sqlstmt     varchar2(4000),    /* responsible sql statement for the change */
  name        varchar2(128) not null,         /* primary object name changed */
  auxname1    varchar2(128),                     /* aux name1 for the object */
  auxname2    varchar2(128),                     /* aux name2 for the object */
  opcode      number not null,                      /* opcode for the change */
  flags       number,                                               /* flags */
  longsqltxt  clob,                                         /* long sql text */
  replay#     number not null,      /* replay counter:
                                    /*     in PDB,  total # of DDLs replayed */
                                    /*     in ROOT, total # of DDLs executed */
  creation#   number,    /* for dropped user: replay# of when it was created */
  spare3      varchar2(128),                                        /* spare */
  spare4      varchar2(128),                                        /* spare */
  spare5      varchar2(4000),                                       /* spare */
  spare6      number,                                               /* spare */
  spare7      number,                                               /* spare */
  spare8      number                                                /* spare */
)
/

CREATE UNIQUE INDEX i_pdbsync1 ON pdb_sync$(opcode, replay#)
/

CREATE INDEX i_pdbsync2 on pdb_sync$(name)
/

Rem initial row to initialize replay counter. Use opcode -1
BEGIN
  insert into pdb_sync$(scnwrp, scnbas, ctime, name, opcode, flags, replay#)
  values(0, 0, sysdate, 'PDB$LASTREPLAY', -1, 0, 0);
EXCEPTION
  WHEN OTHERS THEN IF SQLCODE = -00001 THEN NULL; ELSE RAISE; END IF;
END;
/

commit;

Rem =======================================================================
Rem  END Changes for pdb_sync$
Rem =======================================================================

Rem *************************************************************************
Rem 17954127: patch synobj# of MDSYS objects to point to PUBLIC.XMLTYPE
Rem *************************************************************************

declare
  xmltype_pub_syn   number := -1;
  entries_to_patch  number := -1;
begin

  select count(*) into entries_to_patch
  from coltype$
  where synobj# NOT IN (select obj# from obj$)
        and obj# in (select obj# from obj$
                     where owner# = (select user#
                                     from user$ where name = 'MDSYS'));

  select obj# into xmltype_pub_syn
  from obj$
  where name = 'XMLTYPE'
        and type# = 5
        and owner# = (select user# from user$ where name = 'PUBLIC');

  if entries_to_patch <> 0 then
    update coltype$
    set synobj# = xmltype_pub_syn
    where synobj# NOT IN (select obj# from obj$)
          and obj# in (select obj# from obj$
                       where owner# = (select user#
                                       from user$ where name = 'MDSYS'));
    commit;
  end if;

exception when others then
  if entries_to_patch = 0 then null;
  else raise;
  end if;
end;
/

Rem *************************************************************************
Rem End 17954127
Rem *************************************************************************

Rem *************************************************************************
Rem 17971391: increase size of opbinding$.functionname
Rem *************************************************************************

alter table sys.opbinding$ modify functionname varchar2(386);

Rem *************************************************************************
Rem End 17971391
Rem *************************************************************************

Rem *************************************************************************
Rem 18019880: Update sysauth$ to remove admin option for DBA
Rem *************************************************************************

update sysauth$ set option$ = decode (bitand (option$,46), 0, null,
bitand (option$,46)) where grantee# = 
(select user# from user$ where name = 'DBA');
/
commit;

Rem *************************************************************************
Rem End 18019880
Rem *************************************************************************

Rem *************************************************************************
Rem 18180897: Grant privileges to SYSTEM
Rem *************************************************************************

grant enqueue any queue to system with admin option;
/
grant dequeue any queue to system with admin option;
/
grant manage any queue to system with admin option;
/

Rem *************************************************************************
Rem End 18180897
Rem *************************************************************************

Rem *************************************************************************
Rem 17675121: alter table to include characterset utf8 
Rem           so that after upgrade we use right characterset.
Rem *************************************************************************
alter table opatch_xml_inv
    ACCESS PARAMETERS
    (
      RECORDS DELIMITED BY NEWLINE CHARACTERSET UTF8
      DISABLE_DIRECTORY_LINK_CHECK
      READSIZE 8388608 
      preprocessor opatch_script_dir:'qopiprep.bat'
      BADFILE opatch_script_dir:'qopatch_bad.bad'
      LOGFILE opatch_log_dir:'qopatch_log.log'
      FIELDS TERMINATED BY 'UIJSVTBOEIZBEFFQBL'
      MISSING FIELD VALUES ARE NULL
      REJECT ROWS WITH ALL NULL FIELDS
      (
        xml_inventory    CHAR(100000000)
      )
    )
    LOCATION(opatch_script_dir:'qopiprep.bat');
Rem *************************************************************************
Rem End 17675121
Rem *************************************************************************


Rem =======================================================================
Rem BEGIN bug 18417322: add flags and a couple of spare columns to 
Rem CDB_LOCAL_ADMINAUTH$
Rem =======================================================================

alter table cdb_local_adminauth$ add flags number default 0 not null;
alter table cdb_local_adminauth$ add spare1 number;
alter table cdb_local_adminauth$ add spare2 varchar2(128);

Rem Set a bit (0x01) in FLAGS in CDB_LOCAL_ADMINAUTH$ rows that represent 
Rem administrative privilege(s) granted locally to Common Users
update CDB_LOCAL_ADMINAUTH$ a set flags = flags + 1
  where sys_context('userenv', 'con_id') = 1 
    and bitand(flags, 1) = 0 
    and exists (select null from user$ u
                  where a.grantee$ = u.name
                    and bitand(u.spare1, 128) = 128)
/

commit
/
  
Rem =======================================================================
Rem  END bug 18417322
Rem =======================================================================

Rem *************************************************************************
Rem Begin 17665117 & 17277459 : Add patch UID and bundle columns to
Rem registry$sqlpatch
Rem 14563594: Add version to registry$sqlpatch
Rem *************************************************************************

begin
  execute immediate 
    'alter table registry$sqlpatch drop constraint registry$sqlpatch_pk';

  execute immediate
    'alter table registry$sqlpatch add (
     version       varchar2(20),
     patch_uid     number,
     flags         varchar2(10),
     bundle_series varchar2(30),
     bundle_id     number,
     bundle_data   XMLType)';

  -- 18764751: Update new columns so they will not violate constraints
  execute immediate
    'update registry$sqlpatch set version = ''0'', patch_uid = 0';

  execute immediate
    'alter table registry$sqlpatch add (
       constraint registry$sqlpatch_pk PRIMARY KEY
         (patch_id, patch_uid, version, action, action_time))';
exception
  when others then
    if sqlcode in (-904, -942) then null;
    else raise;
    end if;
end;
/


Rem *************************************************************************
Rem End 17665117 & 17277459 : Add patch UID and bundle columns to
Rem registry$sqlpatch
Rem *************************************************************************

Rem *************************************************************************
Rem Begin 18977120: Add bundle_series to registry$history
Rem *************************************************************************
begin
  execute immediate
    'alter table registry$history add (bundle_series varchar2(30))';
exception
  when others then
    if sqlcode in (-904, -942, -1430) then
      null;
    else
      raise;
    end if;
end;
/


Rem *************************************************************************
Rem bug 17446096: populate adminauth$ in a non-CDB using data in 
Rem v$pwfile_users.  Do not propagate data from a row corresponding to SYS
Rem because SYS always has SYSDBA and SYSOPER
Rem *************************************************************************

Rem delete rows from adminauth$ in a non-CDB before doing an insert to avoid 
Rem unique key violations
delete from adminauth$ where sys_context('userenv', 'con_id') = 0
/

insert into adminauth$ (user#, syspriv, common)
  select u.user#, 
         decode(p.SYSDBA,    'TRUE', 2,    0) +
         decode(p.SYSOPER,   'TRUE', 4,    0) +
         decode(p.SYSBACKUP, 'TRUE', 256,  0) +
         decode(p.SYSDG,     'TRUE', 512,  0) +
         decode(p.SYSKM,     'TRUE', 1024, 0) as syspriv,
         0 as common
  from v$pwfile_users p, user$ u
  where sys_context('userenv', 'con_id') = 0
    and p.username = u.name
    and u.name != 'SYS'
/

commit
/

Rem ********************************************************************
Rem End  17446096
Rem ********************************************************************

Rem *************************************************************************
Rem : bug #17665104 add patch-UID to opatch_inst_patch
Rem *************************************************************************
ALTER  TABLE  opatch_inst_patch ADD
patchUId VARCHAR2(20);

Rem ********************************************************************
Rem End  17665104
Rem ********************************************************************

Rem *************************************************************************
Rem Begin 17665117 & 17277459 : Add patch UID and bundle columns to
Rem registry$sqlpatch
Rem 14563594: Add version to registry$sqlpatch
Rem ************************************************************************* 
begin
execute immediate 'alter table registry$sqlpatch drop constraint registry$sqlpatch_pk';
execute immediate 'alter table registry$sqlpatch add (
        version       varchar2(20),
        patch_uid     number
        )';
execute immediate 'update registry$sqlpatch set version = ''0'', patch_uid = 0';
execute immediate 'alter table registry$sqlpatch add (
     constraint registry$sqlpatch_pk PRIMARY KEY
      (patch_id, patch_uid, version, action, action_time))';
exception when others then
  if sqlcode in (-904, -942) then null;
  else raise;
  end if;
end;
/
Rem *************************************************************************
Rem End 17665117 & 17277459 : Add patch UID and bundle columns to 
Rem registry$sqlpatch
Rem 14563594: Add version to registry$sqlpatch
Rem *************************************************************************

Rem *************************************************************************
Rem Resource Manager related changes - BEGIN
Rem *************************************************************************

Rem Add directive_type column to cdb_resource_plan_directive$
alter table cdb_resource_plan_directive$ add (directive_type varchar2(30));

Rem All directives other than the default and autotask directives
Rem have directive_type = PDB.
update cdb_resource_plan_directive$ set directive_type = 'PDB';
update cdb_resource_plan_directive$ set directive_type = 'DEFAULT_DIRECTIVE'
 where pdb = 'ORA$DEFAULT_PDB_DIRECTIVE';
update cdb_resource_plan_directive$ set directive_type = 'AUTOTASK'
 where pdb = 'ORA$AUTOTASK';

Rem Add memory_min and memory_limit columns to cdb_resource_plan_directive$
alter table cdb_resource_plan_directive$ add (memory_min number);
alter table cdb_resource_plan_directive$ add (memory_limit number);

update cdb_resource_plan_directive$ set memory_min = 4294967295;
update cdb_resource_plan_directive$ set memory_limit = 4294967295;

Rem *************************************************************************
Rem Resource Manager related changes - END
Rem *************************************************************************

Rem *************************************************************************
Rem Change reco_script_params$ VARCHAR to CLOB
Rem *************************************************************************
ALTER TABLE reco_script_params$ ADD (TEMP clob);
UPDATE reco_script_params$ SET TEMP = VALUE;
ALTER TABLE reco_script_params$ DROP COLUMN VALUE;
ALTER TABLE reco_script_params$ RENAME COLUMN TEMP to VALUE;
Rem *************************************************************************
Rem End change reco_script_params$ VARCHAR to CLOB
Rem *************************************************************************

Rem *************************************************************************
Rem END   c1201000.sql
Rem *************************************************************************
