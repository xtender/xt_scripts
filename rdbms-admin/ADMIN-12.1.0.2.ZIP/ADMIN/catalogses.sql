Rem
Rem $Header: rdbms/admin/catalogses.sql /main/2 2013/06/07 13:23:50 cmlim Exp $ catalogses.sql
Rem
Rem catalogses.sql
Rem
Rem Copyright (c) 2006, 2013, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catalogses.sql - Catalog Upgrade Session script
Rem
Rem    DESCRIPTION
Rem      This script contains session initialization statements
Rem      for catalog.sql that perform per-session start up actions
Rem      when running catupgrd.sql in parallel processes.
Rem
Rem    NOTES
Rem      
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    cmlim       05/15/13 - bug 16816410: add table name to errorlogging
Rem                           syntax
Rem    jerrede     10/29/11 - Fix Bug 13252372
Rem    jerrede     10/29/11 - Created
Rem

Rem =====================================================================
Rem Catalog.sql settings
Rem =====================================================================
set errorlogging on table sys.registry$error identifier 'CATALOG';

