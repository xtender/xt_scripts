Rem
Rem $Header: rdbms/admin/catawrtv.sql /main/3 2014/02/20 12:45:55 surman Exp $
Rem
Rem catawrtv.sql
Rem
Rem Copyright (c) 2002, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catawrtv.sql - Catalog script for Automatic Workload Repository
Rem                   (AWR) Tables and Views
Rem
Rem    DESCRIPTION
Rem      Creates tables, views
Rem
Rem    NOTES
Rem      Must be run when connected as SYSDBA
Rem      The newly created tables should be TRUNCATE in the downgrade script.
Rem      Any new views and their synonyms should be dropped in the downgrade
Rem      script.
Rem
Rem
Rem BEGIN SQL_FILE_METADATA
Rem SQL_SOURCE_FILE: rdbms/admin/catawrtv.sql
Rem SQL_SHIPPED_FILE: rdbms/admin/catawrtv.sql
Rem SQL_PHASE: CATAWRTV
Rem SQL_STARTUP_MODE: NORMAL
Rem SQL_IGNORABLE_ERRORS: NONE
Rem SQL_CALLING_FILE: rdbms/admin/catptabs.sql
Rem END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    surman      12/29/13 - 13922626: Update SQL metadata
Rem    surman      03/27/12 - 13615447: Add SQL patching tags
Rem    ilistvin    06/11/22 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

Rem The following script will create the WR tables
@@catawrtb

Rem The following script will create the DBA_HIST views for the 
Rem Workload Repository, except those that depend on packages
@@catawrvw


@?/rdbms/admin/sqlsessend.sql
