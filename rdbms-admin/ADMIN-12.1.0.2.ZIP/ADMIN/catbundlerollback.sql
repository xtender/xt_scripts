Rem
Rem $Header: rdbms/admin/catbundlerollback.sql /main/1 2013/08/13 10:30:38 surman Exp $
Rem
Rem catbundlerollback.sql
Rem
Rem Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.
Rem
Rem    NAME
Rem      catbundlerollback.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    surman      08/06/13 - 17005047: Wrappers for catbundle
Rem    surman      08/06/13 - 17005047: Add catbundleapply and
Rem                           catbundlerollback
Rem    surman      08/06/13 - Created
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/admin/catbundlerollback.sql 
Rem    SQL_SHIPPED_FILE: rdbms/admin/catbundlerollback.sql 
Rem    SQL_PHASE: NONE
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: NONE
Rem    END SQL_FILE_METADATA

@@?/rdbms/admin/sqlsessstart.sql

Rem Determine proper bundle series

COLUMN bnd_series NEW_VALUE bundle_series NOPRINT;

SELECT (CASE WHEN sys.dbms_registry.num_of_exadata_cells() > 0 THEN
               'EXA'
             ELSE
               'PSU'
             END) AS bnd_series
  FROM dual;

Rem And call catbundle to roll it back

@@catbundle.sql &bundle_series rollback

@?/rdbms/admin/sqlsessend.sql

