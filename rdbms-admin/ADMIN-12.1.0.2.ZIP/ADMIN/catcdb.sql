Rem
Rem $Header: rdbms/admin/catcdb.sql /st_rdbms_12.1/1 2014/06/03 11:24:49 aketkar Exp $
Rem
Rem catcdb.sql
Rem
Rem Copyright (c) 2013, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catcdb.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      call catcdb_ini.sql to setup the new cdb
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    apfwkr      05/20/14 - Backport aketkar_bug-18331292 from main
Rem    aketkar     04/30/14 - remove SQL file metadata
Rem    cxie        08/16/13 - remove SQL_PHASE
Rem    cxie        07/10/13 - 17033183: add shipped_file metadata
Rem    cxie        03/19/13 - create CDB with all options installed
Rem    cxie        03/19/13 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

ACCEPT sysPassword CHAR PROMPT 'Enter new password for SYS: ' HIDE
ACCEPT systemPassword CHAR PROMPT 'Enter new password for SYSTEM: ' HIDE
ACCEPT tempTablespace CHAR PROMPT 'Enter temporary tablespace name: ' 
@@catcdb_int.sql

@?/rdbms/admin/sqlsessend.sql
