Rem
Rem $Header: rdbms/admin/catcdb_int.sql /st_rdbms_12.1/2 2014/06/03 11:24:49 aketkar Exp $
Rem
Rem catcdb_int.sql
Rem
Rem Copyright (c) 2013, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catcdb_int.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      set up the new cdb
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    apfwkr      05/20/14 - Backport aketkar_bug-18331292 from main
Rem    apfwkr      05/16/14 - Backport cxie_bug-18609226 from main
Rem    cxie        05/09/14 - create symlink to ovm files under rdbms/admin
Rem    aketkar     04/30/14 - remove SQL file metadata
Rem    cxie        10/16/13 - bug 17608025: use var defintion instead of string replacement
Rem    talliu      10/02/13 - remove catblock
Rem    cxie        08/16/13 - remove SQL_PHASE
Rem    cxie        08/16/13 - bug 17316776: fix sys password
Rem    cxie        07/10/13 - 17033183: add shipped_file metadata
Rem    pyam        06/28/13 - Change catbundle to catbundleapply
Rem    cxie        03/25/13 - Created


@@?/rdbms/admin/sqlsessstart.sql

connect "SYS"/"&&sysPassword" as SYSDBA

column oracle_home new_value oracle_home noprint
select sys_context('userenv', 'oracle_home') as oracle_home from dual;
column slash new_value slash noprint
select sys_context('userenv', 'platform_slash') as slash from dual;

column rdbms_admin_catcon new_value rdbms_admin_catcon noprint
select '&&oracle_home'||'&&slash'||'rdbms'||'&&slash'||'admin'||'&&slash'||'catcon.pl' as rdbms_admin_catcon from dual;
column rdbms_admin new_value rdbms_admin noprint
select '&&oracle_home'||'&&slash'||'rdbms'||'&&slash'||'admin' as rdbms_admin from dual;
column sqlplus_admin_help new_value sqlplus_admin_help noprint
select '&&oracle_home'||'&&slash'||'sqlplus'||'&&slash'||'admin'||'&&slash'||'help' as sqlplus_admin_help from dual;
column sqlplus_admin new_value sqlplus_admin noprint
select '&&oracle_home'||'&&slash'||'sqlplus'||'&&slash'||'admin' as sqlplus_admin from dual;
column jvm_install new_value jvm_install noprint
select '&&oracle_home'||'&&slash'||'javavm'||'&&slash'||'install' as jvm_install from dual;
column xdk_admin new_value xdk_admin noprint
select '&&oracle_home'||'&&slash'||'xdk'||'&&slash'||'admin' as xdk_admin from dual;
column ctx_admin new_value ctx_admin noprint
select '&&oracle_home'||'&&slash'||'ctx'||'&&slash'||'admin' as ctx_admin from dual;
column ctx_admin_defaults new_value ctx_admin_defaults noprint
select '&&oracle_home'||'&&slash'||'ctx'||'&&slash'||'admin'||'&&slash'||'defaults' as ctx_admin_defaults from dual;
column ord_admin new_value ord_admin noprint
select '&&oracle_home'||'&&slash'||'ord'||'&&slash'||'admin' as ord_admin from dual;
column im_admin new_value im_admin noprint
select '&&oracle_home'||'&&slash'||'ord'||'&&slash'||'im'||'&&slash'||'admin' as im_admin from dual;
column olap_admin new_value olap_admin noprint
select '&&oracle_home'||'&&slash'||'olap'||'&&slash'||'admin' as olap_admin from dual;
column md_admin new_value md_admin noprint
select '&&oracle_home'||'&&slash'||'md'||'&&slash'||'admin' as md_admin from dual;
column apex_home new_value apex_home noprint
select '&&oracle_home'||'&&slash'||'apex' as apex_home from dual;

/* ------------------------------------------- */                      
/* run catcon                                  */
/* ------------------------------------------- */
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&rdbms_admin -n 1 -b catalog catalog.sql
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&rdbms_admin -n 1 -b catproc catproc.sql
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&rdbms_admin -n 1 -b catoctk catoctk.sql
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&rdbms_admin -n 1 -b owminst owminst.plb
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYSTEM/&&systemPassword -U SYS/&&sysPassword -d &&sqlplus_admin -n 1 -b pupbld pupbld.sql
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYSTEM/&&systemPassword -U SYS/&&sysPassword -d &&sqlplus_admin_help -n 1 -b hlpbld hlpbld.sql '--phelpus.sql'
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&jvm_install -n 1 -b initjvm initjvm.sql
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&xdk_admin -n 1 -b initxml initxml.sql
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&xdk_admin -n 1 -b xmlja xmlja.sql
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&rdbms_admin -n 1 -b catjava catjava.sql
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&rdbms_admin -n 1 -b catxdbj catxdbj.sql
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&ctx_admin -n 1 -b catctx catctx.sql '--pchange_on_install' '--pSYSAUX' '--p&&tempTablespace' '--pLOCK'
alter user CTXSYS account unlock identified by "CTXSYS";
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u CTXSYS/CTXSYS -U SYS/&&sysPassword -d &&ctx_admin_defaults -n 1 -b dr0defin dr0defin.sql '--p\"AMERICAN\"'
alter user CTXSYS password expire account lock;
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&rdbms_admin -n 1 -b dbmsxdbt dbmsxdbt.sql
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&ord_admin -n 1 -b ordinst ordinst.sql '--pSYSAUX' '--pSYSAUX'
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&im_admin -n 1 -b catim catim.sql
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&olap_admin -n 1 -b olap.sql olap.sql '--pSYSAUX' '--p&&tempTablespace'
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&md_admin -n 1 -b mdinst mdinst.sql
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&rdbms_admin -n 1 -b catols catols.sql
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&apex_home -n 1 -b catapx catapx.sql '--pchange_on_install' '--pSYSAUX' '--pSYSAUX' '--p&&tempTablespace' '--p/i/' '--pNONE'
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&rdbms_admin -n 1 -b catmac catmac.sql '--pSYSAUX' '--p&&tempTablespace' '--p&&sysPassword'
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&rdbms_admin -n 1 -b catclust catclust.sql
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&rdbms_admin -n 1 -b catbundleapply catbundleapply.sql
host perl -I &&rdbms_admin &&rdbms_admin_catcon -u SYS/&&sysPassword -U SYS/&&sysPassword -d &&rdbms_admin -n 1 -b utlrp utlrp.sql

/* ------------------------------------------- */                      
/* lock accounts                               */
/* ------------------------------------------- */
SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
alter session set "_oracle_script"=true;
alter pluggable database pdb$seed close;
alter pluggable database pdb$seed open READ WRITE;
BEGIN 
 FOR item IN ( SELECT USERNAME FROM DBA_USERS WHERE ACCOUNT_STATUS IN ('OPEN', 'LOCKED', 'EXPIRED') AND USERNAME NOT IN ( 
'SYS','SYSTEM') ) 
 LOOP 
  dbms_output.put_line('Locking and Expiring: ' || item.USERNAME); 
  execute immediate 'alter user ' ||
 	 sys.dbms_assert.enquote_name(
 	 sys.dbms_assert.schema_name(
 	 item.USERNAME),false) || ' password expire account lock' ;
 END LOOP;
END;
/
alter session set container=pdb$seed;
BEGIN 
 FOR item IN ( SELECT USERNAME FROM DBA_USERS WHERE ACCOUNT_STATUS IN ('OPEN', 'LOCKED', 'EXPIRED') AND USERNAME NOT IN ( 
'SYS','SYSTEM') ) 
 LOOP 
  dbms_output.put_line('Locking and Expiring: ' || item.USERNAME); 
  execute immediate 'alter user ' ||
 	 sys.dbms_assert.enquote_name(
 	 sys.dbms_assert.schema_name(
 	 item.USERNAME),false) || ' password expire account lock' ;
 END LOOP;
END;
/
alter session set container=cdb$root;
alter pluggable database pdb$seed close;
alter pluggable database pdb$seed open READ ONLY;
alter session set "_oracle_script"=false;

@?/rdbms/admin/sqlsessend.sql
