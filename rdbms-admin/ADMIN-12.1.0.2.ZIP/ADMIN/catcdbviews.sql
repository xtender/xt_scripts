Rem
Rem $Header: rdbms/admin/catcdbviews.sql /st_rdbms_12.1/1 2014/05/20 11:57:35 prshanth Exp $
Rem
Rem catCDBViews.sql
Rem
Rem Copyright (c) 2011, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catCDBViews.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem
Rem BEGIN SQL_FILE_METADATA
Rem SQL_SOURCE_FILE: rdbms/admin/catcdbviews.sql
Rem SQL_SHIPPED_FILE: rdbms/admin/catcdbviews.sql
Rem SQL_PHASE: CATCDBVIEWS
Rem SQL_STARTUP_MODE: NORMAL
Rem SQL_IGNORABLE_ERRORS: NONE
Rem SQL_CALLING_FILE: rdbms/admin/catpstrt.sql
Rem END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    apfwkr      05/11/14 - Backport prshanth_bug-18657870 from main
Rem    prshanth    16/04/14 - 18657870: replace CDB$VIEW with CONTAINERS
Rem    surman      12/29/13 - 13922626: Update SQL metadata
Rem    gravipat    11/22/13 - 17843598: populate view comments correctly
Rem    gravipat    11/07/13 - quote view names
Rem    thbaby      10/29/12 - 14781792: ignore GRANT_PATH type
Rem    thbaby      09/26/12 - 13867272: unconditionally create cdb views in
Rem                           catcdbviews during upgrade, catch recompilation 
Rem                           error in create_cdbview
Rem    gravipat    08/22/12 - 13739232: Ignore long columns
Rem    vpriyans    07/05/12 - Bug 14272027: Allow audit_admin and audit_viewer
Rem                           roles to select from cdb_unified_audit_trail
Rem    thbaby      06/21/12 - prevent sql injection by correctly using quotes
Rem    gravipat    06/15/12 - lrg 6995210: Remove quotes around oldview_name
Rem    thbaby      06/11/12 - allow CDB_* views over non-SYS-owned DBA_* views
Rem    gravipat    05/14/12 - 13083137: Make create_cdbview private
Rem    ssonawan    04/25/12 - bug 13964209: add cdb_unified_audit_trail
Rem    surman      03/27/12 - 13615447: Add SQL patching tags
Rem    gravipat    02/21/12 - 13724677: CDB_USERS should only show common users
Rem                           once
Rem    bhammers    07/28/07 - add exception for new vies containing xml type
Rem    gravipat    11/29/11 - Get rid of CDBView table function
Rem    sumkumar    11/09/11 - Remove WITH GRANT OPTION from public grants
Rem                         - Do not run SQL statements twice
Rem    gravipat    11/08/11 - 13356587: Use a different escape character
Rem    bhammers    07/28/07 - add exception for new vies containing xml type
Rem    gravipat    04/25/11 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

create or replace package sys.CDBView as 
  ----------------------------
  --  PROCEDURES AND FUNCTIONS
  --
procedure create_cdbview(chk_upgrd IN boolean, owner IN varchar2,
                         oldview_name IN varchar2, newview_name IN varchar2);
end CDBView;
/

grant execute on sys.CDBView to execute_catalog_role
/

create or replace package body sys.CDBView is
-- Create the cdb view
-- private helper procedure to create the cdb view
-- Note that quotes should not be added around owner, oldview_name and 
-- newview_name before create_cdbview is invoked since all three are used 
-- as literals to query dictionary views.
procedure create_cdbview(chk_upgrd IN boolean, owner IN varchar2,
                         oldview_name IN varchar2, newview_name IN varchar2) as
  sqlstmt        varchar2(4000);
  col_name       varchar2(128);
  comments       varchar2(4000);
  col_type       number;
  upper_owner    varchar2(128);
  upper_oldview  varchar2(128);
  quoted_owner   varchar2(130); -- 2 more than size of owner
  quoted_oldview varchar2(130); -- 2 more than size of oldview_name
  quoted_newview varchar2(130); -- 2 more than size of newview_name

  cursor tblcommentscur is select c.comment$
                from sys.obj$ o, sys.user$ u, sys.com$ c
                where o.name = upper_oldview and u.name = upper_owner
                and o.obj# = c.obj# and o.owner#=u.user# and o.type# = 4
                and c.col# is null;

  cursor colcommentscur is select c.name, co.comment$, c.type#
                     from sys.obj$ o, sys.col$ c, sys.user$ u, sys.com$ co
                     where o.name = upper_oldview and u.name = upper_owner
                     and o.owner# = u.user# and o.type# = 4 and o.obj# = c.obj#
                     and c.obj# = co.obj# and c.intcol# = co.col#
                     and bitand(c.property, 32) = 0;

begin

  -- convert owner and view names to upper case
  upper_owner    := upper(owner);
  upper_oldview  := upper(oldview_name);

  quoted_owner   := '"' || upper_owner         || '"';
  quoted_oldview := '"' || upper_oldview       || '"';
  quoted_newview := '"' || upper(newview_name) || '"';

  -- Create cdb view
  sqlstmt := 'CREATE OR REPLACE VIEW ' || 
     quoted_owner || '.' || quoted_newview || 
     ' CONTAINER_DATA AS SELECT * FROM CONTAINERS(' ||
     quoted_owner || '.' || quoted_oldview || ')';

  --dbms_output.put_line(sqlstmt);
  execute immediate sqlstmt;

  -- table and column comments
  open tblcommentscur;
  fetch tblcommentscur into comments;
  comments := replace(comments, '''','''''');
  sqlstmt := 'comment on table ' || quoted_owner || '.' || quoted_newview ||
              ' is ''' || comments || ' in all containers''';
  -- dbms_output.put_line(sqlstmt);
  execute immediate sqlstmt;
  close tblcommentscur;

  sqlstmt := 'comment on column ' || quoted_owner || '.' || quoted_newview ||
             '.CON_ID is ''container id''';
  -- dbms_output.put_line(sqlstmt);
  execute immediate sqlstmt;
  open colcommentscur;
  loop
    fetch colcommentscur into col_name, comments, col_type;
    exit when colcommentscur%NOTFOUND;

    comments := replace(comments, '''','''''');
    if comments is not NULL and
       col_type <> 8        and
       col_type <> 123      then
      sqlstmt := 'comment on column ' ||
                 quoted_owner || '.' || quoted_newview || '.' ||
                 col_name || ' is ''' || comments || '''';
      -- dbms_output.put_line(sqlstmt);
      execute immediate sqlstmt;
    end if;
  end loop;
  close colcommentscur;
end;

end CDBView;
/
show errors;
/

@?/rdbms/admin/sqlsessend.sql
