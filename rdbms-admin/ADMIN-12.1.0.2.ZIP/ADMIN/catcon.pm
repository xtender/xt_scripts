# 
# $Header: rdbms/admin/catcon.pm /st_rdbms_12.1/10 2014/06/27 12:11:59 akruglik Exp $
#
# catcon.pm
# 
# Copyright (c) 2011, 2014, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      catcon.pm - CONtainer-aware Perl Module for creating/upgrading CATalogs
#
#    DESCRIPTION
#      This module defines subroutines which can be used to execute one or 
#      more SQL statements or a SQL*Plus script in 
#      - a non-Consolidated Database, 
#      - all Containers of a Consolidated Database, or 
#      - a specified Container of a Consolidated Database
#
#    NOTES
#      Subroutines which handle invocation of SQL*Plus scripts may be invoked 
#      from other scripts (e.g. catctl.pl) or by invoking catcon.pl directly.  
#      Subroutines that execute one or more SQL statements may only be 
#      invoked from other Perl scripts.
#
#    MODIFIED   (MM/DD/YY)
#    jerrede     06/19/14 - Backport jerrede_bug-18969473 from main
#    akruglik    06/05/14 - Backport akruglik_bug18738302-main from main
#    apfwkr      05/16/14 - Backport akruglik_bug-18745291 from main
#    akruglik    05/01/14 - Bug 18672126: having unlinked a file in 
#                           sureunlink, give it some time to disappear
#    apfwkr      04/21/14 - Backport akruglik_pdbseed_mode from main
#    apfwkr      04/17/14 - Backport akruglik_bug-18548396 from main
#    akruglik    04/10/14 - XbranchMerge akruglik_bug18011217 from main
#    apfwkr      04/06/14 - Backport akruglik_bug-18488530 from main
#    akruglik    05/19/14 - add support for -z flag used to supply EZConnect
#                           strings corresponding to RAC instances which should
#                           be used to run scripts
#    akruglik    05/12/14 - Bug 18745291: produce progress messages
#    akruglik    04/17/14 - Bug 18606911: when deciding whether PDB$SEED is 
#                           already open in correct mode, treat READ WRITE as 
#                           a special case of UPGRADE
#    akruglik    04/11/14 - Bug 18548396: set $catcon_RevertSeedPdbMode before 
#                           calling reset_seed_pdb_mode
#    akruglik    04/02/14 - Bug 18488530: make sure pdb$seed is OPEN in READ
#                           ONLY mode if the catcon process gets killed
#    akruglik    03/26/14 - Bug 18011217: address unlink issues on Windows by
#                           embedding process id in names of various "done"
#                           files
#    dkeswani    03/14/14 - Bug 18011217: unlink issues on windows
#    akruglik    01/21/14 - Bug 17898118: rename catconInit.MigrateMode to 
#                           SeedMode and change semantics
#    talliu      01/09/13 - 14223369: add new parameter in catconInit to 
#                           indicated whether it is called by cdb_sqlexec.pl 
#    akruglik    01/16/14 - Bug 18085409: add support for running scripts
#                           against ALL PDBs and then the Root
#    akruglik    01/13/14 - Bug 18070841: modify get_pdb_names to ensure that
#                           PDB name and open_mode appear on the same line
#    dkeswani    01/13/14 - Diagnostic txn for intermittent issue in sureunlink
#                           PDB name and open_mode appear on the same line
#    akruglik    01/09/14 - Bug 18029946: add support for ignoring non-existent
#                           or closed PDBs
#    akruglik    01/07/14 - Bug 18020158: provide for a better default
#                           mechanism for internal connect string
#    akruglik    01/06/14 - Bug 17976046: get rid of Term::ReadKey workaround
#    akruglik    01/03/14 - Bug 18003416: add support for determining whether a
#                           script ended with an uncommitted transaction
#    jerrede     12/25/13 - Stripe Comma's from container name
#    akruglik    12/13/13 - Bug 17898041: use user connect string when starting
#                           SQLPlus processes
#    akruglik    12/13/13 - Bug 17898041: use "/ AS SYSDBA" as the default 
#                           connect string
#    akruglik    12/12/13 - Bug 17898118: once a process finishes running a
#                           script in a CDB, force it to switch into the Root
#    akruglik    12/09/13 - Bug 17810688: detect the case where sqlplus is not
#                           in the PATH
#    jerrede     12/05/13 - Don't override set timing values
#    akruglik    11/26/13 - modify get_connect_string to fetch password from
#                           the environment variable, if it is set
#    akruglik    11/20/13 - Bug 17637320: remove workaround added to
#                           additionalInitStmts eons ago
#    jerrede     11/18/13 - Comment out workaround additionalInitStmts
#                           Causing problems when writing to the
#                           seed database. When running post upgrade
#                           in read write mode we were unable to
#                           write to the database when calling
#                           the post upgrade procedure.
#    jerrede     11/06/13 - Move Dangling Flush Statement
#    akruglik    10/28/13 - Add support for migrate mode indicator; add
#                           subroutine to return password supplied by the user
#    akruglik    10/20/13 - Back out ReadKey-related changes
#    akruglik    10/07/13 - Bug 17550069: accept an indicator that we are being
#                           called from a GUI tool which on Windows means that
#                           the passwords and hidden parameters need not be
#                           hidden
#    jerrede     10/02/13 - Performance Improvements
#    akruglik    09/06/13 - in get_num_procs, don't impose a fixed maximum on a
#                           number of processes which may be started
#    akruglik    08/20/13 - ensure that subroutines expected to return a value
#                           do so under all cercumstances
#    jerrede     07/29/13 - Add End Process to Avoid Windows communication
#                           errors
#    akruglik    07/19/13 - add 3 new parameters to the interface of 
#                           catconExec + define catconIsCDB, catconGetConNames 
#                           and catconQuery
#    jerrede     06/18/13 - Fix shutdown checks.
#    akruglik    05/15/13 - Bug 16603368: add support for -I flag
#    akruglik    03/19/13 - do not quote the password if the user has already
#                           quoted it
#    akruglik    03/07/13 - use v$database.cdb to determine whether a DB is a
#                           CDB
#    akruglik    02/08/13 - Bug 16177906: quote user-supplied password in case
#                           it contains any special characters
#    akruglik    12/03/12 - (LRG 8526376): replace calls to
#                           DBMS_APPLICATION_INFO.SET_MODULE/ACTION with
#                           ALTER SESSION SET APPLICATION MODULE/ACTION
#    akruglik    11/15/12 - (LRG 8522365) temporarily comment out calls to
#                           DBMS_APPLICATION_INFO
#    surman      11/09/12 - 15857388: Resolve Perl typo warning
#    akruglik    11/09/12 - (LRG 7357087): PDB$SEED needs to be reopened READ
#                           WRITE unless it is already open READ WRITE or
#                           READ WRITE MIGRATE
#    akruglik    11/08/12 - use DBMS_APPLICATION_INFO to store info about
#                           processes used to run SQL scripts
#    akruglik    11/08/12 - if debugging is turned on, make STDERR hot
#    akruglik    11/08/12 - (15830396): read and ignore output in
#                           exec_DB_script if no marker was passed, to avoid
#                           hangs on Windows
#    surman      10/29/12 - 14787047: Save and restore stdout
#    mjungerm    09/10/12 - don't assume unlink will succeed - lrg 7184718
#    dkeswani    08/13/12 - Bug 14380261 : delete LOCAL variable on WINDOWS
#    akruglik    08/02/12 - (13704981): report an error if database is not open
#    sankejai    07/23/12 - 14248297: close/open PDB$SEED on all RAC instances
#    akruglik    06/26/12 - modify exec_DB_script to check whether @Output
#                           contains at least 1 element before attempting to
#                           test last character of its first element
#    akruglik    05/23/12 - rather than setting SQLTERMINATOR ON, use /
#                           instead of ; to terminate SQL statements
#    akruglik    05/18/12 - add SET SQLTERMINATOR ON after every CONNECT to
#                           ensure that SQLPLus processes do not hang if the
#                           caller sets SQLTERMINATOR to something other than
#                           ON in glogin.sql or login.sql
#    akruglik    04/18/12 - (LRG 6933132) ignore row representing a non-CDB
#                           when fetching rows from CONTAINER$
#    gravipat    03/20/12 - Rename x$pdb to x$con
#    akruglik    02/22/12 - (13745315): chop @Output in exec_DB_script to get 
#                           rid of trailing \r which get added on Windows
#    akruglik    12/09/11 - (13404337): in additionalInitStmts, set SQLPLus
#                           vars to their default values
#    akruglik    10/31/11 - modify additionalInitStmts to set more of SQLPlus
#                           system vars to prevent values set in a script run
#                           against one Container from affecting output of
#                           another script or a script run against another
#                           Container
#    prateeks    10/21/11 - MPMT changes : connect string
#    akruglik    10/14/11 - Bug 13072385: if PDB$SEED was reopened READ WRITE
#                           in concatExec, it will stay that way until
#                           catconWrapUp
#    akruglik    10/11/11 - Allow user to optionally specify internal connect
#                           string
#    akruglik    10/03/11 - address 'Use of uninitialized value in
#                           concatenation' error
#    akruglik    09/20/11 - Add support for specifying multiple containers in
#                           which to run - or not run - scripts
#    akruglik    09/20/11 - make --p and --P the default tags for regular and
#                           secret arguments
#    akruglik    09/20/11 - make default number of processes a function of
#                           cpu_count
#    akruglik    08/24/11 - exec_DB_script was hanging on Windows because Perl
#                           does not handle CHLD signal on Windows
#    pyam        08/08/11 - don't run scripts AS SYSDBA unless running as sys
#    akruglik    08/03/11 - unset TWO_TASK to ensure that connect without
#                           specifyin a service results in a connection to the
#                           root
#    akruglik    07/01/11 - encapsulate common code into subroutines
#    akruglik    06/30/11 - temporarily suspend use of Term::ReadKey
#    akruglik    06/10/11 - rename CatCon.pm to catcon.pm because oratst get
#                           macro is case-insensitive
#    akruglik    06/10/11 - Add support for spooling output of individual
#                           scripts into separate files
#    akruglik    05/26/11 - Creation
#

package catcon;

use 5.006;
use strict;
use warnings;
use English;
use IO::Handle;       # to flush buffers
use Term::ReadKey;    # to not echo password
use IPC::Open2;       # to perform 2-way communication with SQL*Plus
use File::Spec ();    # for fix of bug 17810688

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration       use catcon ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
        
) ] );

our @EXPORT_OK = qw ( catconInit catconExec catconRunSqlInEveryProcess catconShutdown catconBounceProcesses catconWrapUp catconIsCDB catconGetConNames catconQuery catconUpgEndSessions catconUpgStartSessions catconUserPass catconSetDbClosed catconGetUsrPasswdEnvTag catconGetIntPasswdEnvTag catconXact catconForce catconReverse catconRevertPdbSeedMode catconEZConnect );

our @EXPORT = qw(
        
);
our $VERSION = '0.01';


# Preloaded methods go here.

#
# get_connect_string
#
# Description:
#   If user supplied a user[/password] string
#     If user-supplied string contained a password, 
#       get user name and password from that string
#     else if constructing a user connect string and the appropriate 
#       environment variable was set, set user name to the user-supplied 
#       string and get the password from that variable
#     else 
#       set user name to the user-supplied string and prompt user for a 
#       password
#     end if
#     construct the connect string as a concatenation of 
#     - caller-supplied user,
#     - '/', 
#     - password, 
#     - "@%s" (placeholder which can be relpalced with an EZConnect string 
#         to generate a connect string for connecting to a specific instance) 
#         if $Instances is true, and
#     - AS SYSDBA if user name was SYS.
#   Otherwise,
#     set connect string to '/ AS SYSDBA'
#
# Parameters:
#   - user name, optionally with password; may be undefined
#   - a flag indicating whether to NOT echo a password if a user has to enter 
#     it
#   - password value obtained from the appropriate environment variable, if any
#   - an indicator of whether this string may need to accommodate 
#     specification of EZConnect strings for connecting to various instances
#
# Returns:
#   A string as described above.
#
sub get_connect_string ($$$$) {
  my ($user, $hidePasswd, $envPasswd, $Instances) = @_;

  my $password;
  my $connect;                                       # assembled connect string
  my $sysdba = 0;

  if ($user) {
    # user name specified, possibly followed by /password
    #
    # if the password was not supplied, try to get it from the environment 
    # variable, or, failing that, by prompting the user

    if ($user =~ /(.*)\/(.*)/) {
      # user/password
      $user = $1;
      $password = $2;
    } elsif ($envPasswd) {
      $password = $envPasswd;
      $password =~ tr/"//d;  # strip double quotes
    } else {
      # prompt for password
      print "Enter Password: ";

      # do not enter noecho mode if told to not hide password
      if ($hidePasswd) {
        ReadMode 'noecho';
      }

      $password = ReadLine 0;
      chomp $password;

      # do not restore ReadMode if told to not hide password
      if ($hidePasswd) {
        ReadMode 'normal';
      }

      print "\n";
    }

    if (uc($user) eq "SYS") {
      $sysdba = 1;
    }
   
    # quote the password unless the user has done it for us.  We assume that 
    # passwords cannot contains double quotes and trust the user to not play 
    # games with us and only half-quote the password
    if (substr($password,1,1) ne '"') {
      $password = '"'.$password.'"'
    }
    
    if ($Instances) {
      # add a placeholder for an EZConnect string so we can use it 
      # to connect to a specific instance
      $connect = $user."/"."$password"."@%s";
    } else {
      $connect = $user."/"."$password";
    }
  } else {
    # default to OS authentication

    # OS authentication cannot be used if the user wants to run scripts using
    # specified instances
    if ($Instances) {
      log_msg("get_connect_string: OS authentication cannot be used with specified instances\n");
      $connect = undef;
    } else {
      $connect = "/"; 
    }

    $password = undef;
    $sysdba = 1;
  } 

  # $connect may be undefined if the caller has not supplied user[/password] 
  # while the user specified instances on which to run scripts
  if ($sysdba && $connect) {
    $connect = $connect . " AS SYSDBA";
  }

  return ($connect, $password);
}

# A wrapper over unlink to retry if it fails, as can happen on Windows
# apparently if unlink is attempted on a .done file while the script is
# is still writing to it.  Silent failure to unlink a .done file can
# cause incorrect sequencing leading to problems like lrg 7184718
sub sureunlink ($$) {
  my ($DoneFile, $debugOn) = @_;

  my $iters = 0;
  my $MAX_ITERS = 120;

  while (!unlink($DoneFile) && $iters < $MAX_ITERS) { 
    $iters++;
    if ($debugOn) {
      log_msg("sureunlink: unlink($DoneFile) failed after $iters attempts due to $!\n");
    }

    sleep(1);
  }

  # Bug 18672126: it looks like sometimes on Windows unlink returns 1 
  # indicating that the file has been deleted, but a subsequent -e test seems 
  # to indicate that it still exists, causing us to die.  
  # 
  # One alternative would be to trust unlink and not perform the -e test at 
  # all, but I am concerned that if things really get out of whack, we may 
  # mistakenly conclude that the next script sent to a given SQL*Plus process 
  # has completed simply because the "done" file created to indicate 
  # completion of previous script took too long to go away
  #
  # To alleviate this conern, I will, instead, give the file a bit of time to 
  # really go away by running a loop while -e returns TRUE for the same 
  # number of iterations as we used above to allow unlink to succeed

  if ($iters < $MAX_ITERS) {
    if ($debugOn) {
      log_msg("sureunlink: unlink($DoneFile) succeeded after ".($iters + 1)." attempt(s)\n");
      log_msg("sureunlink: verify that the file really no longer exists\n");
    }

    $iters = 0;
    while ((-e $DoneFile) && $iters < $MAX_ITERS) { 
      $iters++;
      if ($debugOn) {
        log_msg("sureunlink: unlinked file ($DoneFile) appears to still exist after $iters checks\n");
      }
      
      sleep(1);
    }

    if ($debugOn) {
      if ($iters < $MAX_ITERS) {
        log_msg("sureunlink: confirmed that $DoneFile no longer exists after ".($iters + 1)." attempts\n");
      } else {
        log_msg("sureunlink: $DoneFile refused to go away, despite unlink apparently succeeding\n");
      }
    }
  }  else {
    log_msg("sureunlink: could not unlink $DoneFile - $!\n");
  }

  die "could not unlink $DoneFile - $!" if (-e $DoneFile);
}

{
  # This block consists of 2 subroutines:
  # - handle_aux_sigchld() - handles CHLD signal by simply returning
  # - exec_DB_script() - execute an array of statements, possibly returning 
  #     filtered output produced by executing them; sets $SIG{CHLD} to
  #     handle_aux_sigchld() to ensure that CHLD handler does not get reset 
  #     to a proper signal handler (which kills the session) until the process 
  #     executing statements has terminated

  # this handler is used when we are waiting for an auxiliary process to 
  # finish; instead of killing the session running the script, we just return
  sub handle_aux_sigchld () {
    return;
  }

  #
  # exec_DB_script
  #
  # Description:
  #   Connect to a database using connect string supplied by the caller, run 
  #   statement(s) supplied by the caller, and if caller indicated interest in 
  #   some of the output produced by the statements, return a list, possibly 
  #   empty, consisting of results returned by that query which contain 
  #   specified marker
  #
  # Parameters:
  #   - a reference to a list of statements to execute
  #   - a string (marker) which will mark values of interest to the caller; 
  #     if no value is supplied, an uninitialized list will be returned
  #   - a command to create a file whose existence will indicate that the 
  #     last statement of the script has executed
  #   - base for a name of a "done" file (see above)
  #   - an indicator of whether to produce debugging info
  #
  # Returns
  #   A list consisting of values returned by the query, stripped off the 
  #   marker
  #
  sub exec_DB_script (\@$$$$) {
    my ($statements, $marker, $DoneCmd, $DoneFilePathBase, $debugOn) = @_;

    # file whose existence will indicate that all statements in caller's 
    # script have executed
    my $DoneFile = $DoneFilePathBase."_exec_DB_script.done";

    my @Output;

    local (*Reader, *Writer);

    # temporarily reset $SIG{CHLD} to avoid killing the session when exit 
    # statement contained in the script shuts down SQL*Plus process
    my $saveHandlerRef = $SIG{CHLD};

    $SIG{CHLD} = \&handle_aux_sigchld;

    if ($debugOn) {
      log_msg("exec_DB_script: temporarily reset SIGCHLD handler\n");
    }

    # if the "done" file exists, delete it
    if (-e $DoneFile) {
      sureunlink($DoneFile, $debugOn);

      if ($debugOn) {
        log_msg("exec_DB_script: deleted $DoneFile before running a script\n");
      }
    } elsif ($debugOn) {
      log_msg("exec_DB_script: $DoneFile did not need to be deleted before running a script\n");
    }

    my $pid = open2(\*Reader, \*Writer, "sqlplus /nolog");

    if ($debugOn) {
      log_msg("exec_DB_script: opened Reader and Writer\n");
    }

    # execute sqlplus statements supplied by the caller
    foreach (@$statements) {
      print Writer $_;
      if ($debugOn) {
        log_msg("exec_DB_script: executed $_\n");
      }
    }

    # send a statement to generate a "done" file
    print Writer qq/$DoneCmd $DoneFile\n/;

    if ($debugOn) {
      log_msg("exec_DB_script: sent $DoneCmd $DoneFile to Writer\n");
    }

    # send EXIT
    print Writer qq/exit\n/;

    if ($debugOn) {
      log_msg("exec_DB_script: sent -exit- to Writer\n");
    }

    close Writer;       #have to close Writer before read

    if ($debugOn) {
      log_msg("exec_DB_script: closed Writer\n");
    }

    if ($marker) {
      if ($debugOn) {
        log_msg("exec_DB_script: marker = $marker - examine output\n");
      }

      # have to read one line at a time
      while (<Reader>) { 
        if ($_ =~ /^$marker/) {
          if ($debugOn) {
            log_msg("exec_DB_script: line matches marker: $_\n");
          }
          # strip off the marker that was added to identify values of interest
          s/$marker(.*)//;
          # and add it to the list
          push @Output, $1;
        } elsif ($debugOn) {
          log_msg("exec_DB_script: line does not match marker: $_\n");
        }
      }

      # (13745315) on Windows, values fetched from SQL*Plus contain trailing 
      # \r, but the rest of the code does not expect these \r's, so we will 
      # chop them here
      if (@Output && substr($Output[0], -1) eq "\r") {
        chop @Output;
      }
    } else {
      if ($debugOn) {
        log_msg("exec_DB_script: marker was undefined; read and ignore output, if any\n");
      }

      # (15830396) read anyway
      while (<Reader>) {
        ;
      }

      if ($debugOn) {
        log_msg("exec_DB_script: finished reading and ignoring output\n");
      }
    }

    if ($debugOn) {
      log_msg("exec_DB_script: waiting for child process to exit\n");
    }

    # wait until the process running SQL statements terminates
    # 
    # NOTE: Instead of waiting for CHLD signal which gets issued on Linux, 
    #       we wait for a "done" file to be generated because this should 
    #       work on Windows as well as Linux (and other Operating Systems, 
    #       one hopes)
    select (undef, undef, undef, 0.01)    until (-e $DoneFile);

    if ($debugOn) {
      log_msg("exec_DB_script: child process exited\n");
    }

    sureunlink($DoneFile, $debugOn);

    if ($debugOn) {
      log_msg("exec_DB_script: deleted $DoneFile after running a script\n");
    }

    close Reader;

    if ($debugOn) {
      log_msg("exec_DB_script: closed Reader\n");
    }

    waitpid($pid, 0);   #makes your program cleaner
  
    if ($debugOn) {
      log_msg("exec_DB_script: waitpid returned\n");
    }

    # 
    # restore CHLD signal handler
    #
    $SIG{CHLD} = $saveHandlerRef;

    if ($debugOn) {
      log_msg("exec_DB_script: restored SIGCHLD handler\n");
    }

    return @Output;
  }
}

#
# get_instance_status
#   
# Description
#   Obtain instance status.
#
# Parameters:
#   - connect string - used to connect to a DB 
#   - a command to create a file whose existence will indicate that the 
#     last statement of the script has executed (needed by exec_DB_script())
#   - base for a name of a "done" file (see above)
#   - indicator of whether to produce debugging info
#
# Returns
#   String found in V$INSTANCE.STATUS
#
sub get_instance_status ($$$$) {

  my ($connectString, $DoneCmd, $DoneFilePathBase, $debugOn) = @_;

  my @GetInstStatusStatements = (
    "connect $connectString\n",
    "set echo off\n",
    "set heading off\n",
    "select \'XXXXXX\' || status from v\$instance\n/\n",
  );

  my @InstStatus = exec_DB_script(@GetInstStatusStatements, "XXXXXX", 
                                  $DoneCmd, $DoneFilePathBase, $debugOn);
  return $InstStatus[0];
}

#
# get_instance_status_and_name
#   
# Description
#   Obtain instance status and name.
#
# Parameters:
#   - connect string - used to connect to a DB 
#   - a command to create a file whose existence will indicate that the 
#     last statement of the script has executed (needed by exec_DB_script())
#   - base for a name of a "done" file (see above)
#   - indicator of whether to produce debugging info
#
# Returns
#   Strings found in V$INSTANCE.STATUS and V$INSTANCE.INSTANCE_NAME
#
sub get_instance_status_and_name ($$$$) {

  my ($connectString, $DoneCmd, $DoneFilePathBase, $debugOn) = @_;

  my @GetInstStatusStatements = (
    "connect $connectString\n",
    "set echo off\n",
    "set heading off\n",
    "select \'XXXXXX\' || status, instance_name from v\$instance\n/\n",
  );

  # should return exactly 1 row
  my @rows = exec_DB_script(@GetInstStatusStatements, "XXXXXX", 
                           $DoneCmd, $DoneFilePathBase, $debugOn);

  my $InstStatus;
  my $InstName;

  # split the row into instance status and instance name
  if (@rows && $#rows == 0) {
    ($InstStatus, $InstName) = split /\s+/, $rows[0];
  }

  return ($InstStatus, $InstName);
}

#
# get_CDB_indicator
#   
# Description
#   Obtain an indicator of whether a DB is a CDB
#
# Parameters:
#   - connect string - used to connect to a DB 
#   - a command to create a file whose existence will indicate that the 
#     last statement of the script has executed (needed by exec_DB_script())
#   - base for a name of a "done" file (see above)
#   - indicator of whether to produce debugging info
#
# Returns
#   String found in V$DATABASE.CDB
#
sub get_CDB_indicator ($$$$) {

  my ($connectString, $DoneCmd, $DoneFilePathBase, $debugOn) = @_;

  # We used to rely on CONTAINER$ not returning any rows, but in 
  # a non-CDB from a shiphome, CONTAINER$ will have a row representing 
  # CDB$ROOT (because we ship a single Seed which is is CDB and unlink 
  # PDB$SEED if a customer wants a non-CDB; you could argue that we 
  # could have purged CDB$ROOT from CONTAINER$ the same way we purged 
  # SEED$PDB, but things are the way they are, and it is more robust 
  # to query V$DATABASE.CDB)

  my @GetIsCdbStatements = (
    "connect $connectString\n",
    "set echo off\n",
    "set heading off\n",
    "select \'XXXXXX\' || cdb from v\$database\n/\n",
  );

  my @IsCDB = exec_DB_script(@GetIsCdbStatements, "XXXXXX", 
                             $DoneCmd, $DoneFilePathBase, $debugOn);
  return $IsCDB[0];
}

#
# get_dbid
#   
# Description
#   Obtain database' DBID
#
# Parameters:
#   - connect string - used to connect to a DB 
#   - a command to create a file whose existence will indicate that the 
#     last statement of the script has executed (needed by exec_DB_script())
#   - base for a name of a "done" file (see above)
#   - indicator of whether to produce debugging info
#
# Returns
#   Database' DBID (V$DATABASE.DBID)
#
sub get_dbid ($$$$) {

  my ($connectString, $DoneCmd, $DoneFilePathBase, $debugOn) = @_;

  my @GetDbIdStatements = (
    "connect $connectString\n",
    "set echo off\n",
    "set heading off\n",
    "select \'XXXXXX\' || dbid from v\$database\n/\n",
  );

  my @DBID = exec_DB_script(@GetDbIdStatements, "XXXXXX", 
                            $DoneCmd, $DoneFilePathBase, $debugOn);
  return $DBID[0];
}

#
# get_con_id
#   
# Description
#   Obtain id of a CDB Container to which we will connect using a specified 
#   EZConnect string
#
# Parameters:
#   - connect string - used to connect to a DB 
#   - a command to create a file whose existence will indicate that the 
#     last statement of the script has executed (needed by exec_DB_script())
#   - base for a name of a "done" file (see above)
#   - indicator of whether to produce debugging info
#
# Returns
#   CON_ID o the container to which we are connected.
#
sub get_con_id ($$$$) {

  my ($connectString, $DoneCmd, $DoneFilePathBase, $debugOn) = @_;

  my @GetConIdStatements = (
    "connect $connectString\n",
    "set echo off\n",
    "set heading off\n",
    "select \'XXXXXX\' || sys_context(\'USERENV\', \'CON_ID\') as con_id from dual\n/\n",
  );

  my @CON_ID = exec_DB_script(@GetConIdStatements, "XXXXXX", 
                              $DoneCmd, $DoneFilePathBase, $debugOn);
  return $CON_ID[0];
}

#
# build_connect_string
#   
# Description
#    Build a Connect String, possibly including an EZConnect String
#
# Parameters:
#   - connect string template - a string that looks like 
#     - user/password [AS SYSDBA] or "/ AS SYSDBA" if EZConnect strings were 
#       not supplied by the caller or
#     - user/password@%s [AS SYSDBA] otherwise
#   - an EZConnect string corresponding to an instance or an empty string if 
#       the default instance is to be used
#   - an indicator of whether to produce debugging messages
# Returns
#   A connect string which can be used to connect to the instance with 
#   specified EZConnect string or to the default instance
#
sub build_connect_string ($$$) {
  my ($connStrTemplate, $EZConnect, $debugOn) = @_;
  
  if ($debugOn) {
    my $msg = <<build_connect_string_DEBUG;
running build_connect_string(
  connStrTemplate = $connStrTemplate, 
  EZConnect       = $EZConnect)
build_connect_string_DEBUG
    log_msg($msg);
  }

  if (!$EZConnect || ($EZConnect eq "")) {
    # caller has not supplied an EZConnect string. Make sure that 
    # $connStrTemplate does not contain a placeholder for one
    if (index($connStrTemplate, "@%s") != -1) {
      my $msg = <<msg;
build_connect_string: connect string template includes an EZConnect 
    placeholder but the caller has supplied an empty EZConnect String
msg
      log_msg($msg);
      return undef;
    }

    # EZConnect string was not supplied, nor was it expected, so just use 
    # the default instance
    if ($debugOn) {
      my $msg = <<msg;
build_connect_string: return caller-supplied string (".$connStrTemplate.")
    as the connect string
msg
      log_msg($msg);
    }

    return $connStrTemplate;
  } 
    
  # caller has supplied an EZConnect string. Make sure that $connStrTemplate 
  # contains a placeholder for one
  if (index($connStrTemplate, "@%s") == -1) {
    my $msg = <<msg;
build_connect_string: connect string template does not include an EZConnect 
    placeholder but the caller has supplied an EZConnect String
msg
    log_msg($msg);
    return undef;
  }
  
  # construct a connect string by replacing the placeholder with the 
  # supplied EZConnect string
  
  my $outStr = sprintf($connStrTemplate, $EZConnect);

  if ($debugOn) {
    log_msg("build_connect_string: return ".$outStr." as the connect string\n");
  }

  return $outStr;
}

#
# get_num_procs_int
#   
# Description
#   Get the value of CPU_COUNT parameter (number of cores) and double it to 
#   derive the number of processes which will be used to run script(s) 
#   (similar to how PDML determines how many slaves it can create.)
#
# Parameters:
#   - connect string - used to connect to a DB and determine whether it is 
#     consolidated (and eventually to determine how many processes should be 
#     created to run script(s)
#   - a command to create a file whose existence will indicate that the 
#     last statement of the script has executed (needed by exec_DB_script())
#   - base for a name of a "done" file (see above)
#   - indicator of whether to produce debugging info
#
# Returns
#   number of processes which will be used to run script(s)
#
sub get_num_procs_int ($$$$) {

  my ($connectString, $DoneCmd, $DoneFilePathBase, $debugOn) = @_;

  my @GetNumCoresStatements = (
    "connect $connectString\n",
    "set echo off\n",
    "set heading off\n",
    "select \'XXXXXX\' || p.value * 2 from v\$parameter p where p.name=\'cpu_count\'\n/\n",
  );

  my @NumCores = exec_DB_script(@GetNumCoresStatements, "XXXXXX", 
                                $DoneCmd, $DoneFilePathBase, $debugOn);
  return $NumCores[0];
}

#
# get_num_procs - determine number of processes which should be created
#
# parameters:
#   - number of processes, if any, supplied by the user
#   - number of concurrent script invocations, as supplied by the user 
#     (external degree of parallelism)
#   - connect string
#   - a command to create a file whose existence will indicate that the 
#     last statement of the script has executed (needed by exec_DB_script())
#   - base for a name of a "done" file (see above)
#   - an indicator of whether to produce debugging info
#
sub get_num_procs ($$$$$$) {
  my ($NumProcs, $ExtParaDegree, $ConnectString, $DoneCmd, $DoneFilePathBase, 
      $DebugOn) = @_;

  my $MinNumProcs  = 1;   # minimum number of processes
  my $ProcsToStart;       # will be returned to the caller

  # compute the number of processes to be started

  if ($NumProcs > 0) {

    # caller supplied a number of processes; 
    $ProcsToStart = $NumProcs;

    if ($DebugOn) {
      log_msg("get_num_procs: caller-supplied number of processes (not final) = $NumProcs\n");
    }
  } else {    
    # first obtain a default value for number of processes based on 
    # hardware characteristics
    $ProcsToStart = get_num_procs_int($ConnectString, $DoneCmd, 
                                      $DoneFilePathBase, $DebugOn);
      
    if ($DebugOn) {
      log_msg("get_num_procs: computed number of processes (not final) = $ProcsToStart\n");
    }

    # if called interactively and the caller has provided the number of 
    # concurrent script invocations on this host, compute number of 
    # processes which will be started in this invocation
    if ($ExtParaDegree) {
      if ($DebugOn) {
        log_msg("get_num_procs: number of concurent script invocations = $ExtParaDegree\n");
      }

      $ProcsToStart = int ($ProcsToStart / $ExtParaDegree);

      if ($DebugOn) {
        my $msg = <<msg;
get_num_procs: adjusted for external parallelism, number of processes (still 
    not final) for this invocation of the script = $ProcsToStart
msg
        log_msg($msg);
      }
    }
  }

  # use number of processes which was either supplied by the user or 
  # computed by get_num_procs_int() it unless it is too small
    
  if ($ProcsToStart < $MinNumProcs) {
    $ProcsToStart = $MinNumProcs;
  }

  if ($DebugOn) {
    log_msg("get_num_procs: will start $ProcsToStart processes (final)\n");
  }

  return $ProcsToStart;
}

#
# valid_src_dir make sure source directory exists and is readable
#
# Parameters:
#   - source directory name; may be undefined
#
# Returns
#   1 if valid; 0 otherwise
#
sub valid_src_dir ($) {
  my ($SrcDir) = @_;

  if (!$SrcDir) {
    # no source directory specified - can't complain of it being invalid
    return 1;
  }

  # if a directory for sqlplus script(s) has been specified, verify that it 
  # exists and is readable
  stat($SrcDir);

  if (! -e _ || ! -d _) {
    log_msg("valid_src_dir: Specified source file directory ($SrcDir) does not exist or is not a directory\n");
    return 0;
  }

  if (! -r _) {
    log_msg("valid_src_dir: Specified source file directory ($SrcDir) is unreadable\n");
    return 0;
  }

  return 1;
}

#
# valid_log_dir make sure log directory exists and is writable
#
# Parameters:
#   - log directory name; may be undefined
#
# Returns
#   1 if valid; 0 otherwise
#
sub valid_log_dir ($) {
  my ($LogDir) = @_;

  if (!$LogDir) {
    # no log directory specified - can't complain of it being invalid
    return 1;
  }

  stat($LogDir);

  if (! -e _ || ! -d _) {
    # use STDERR because CATCONOUT is yet to be opened
    print STDERR "valid_log_dir: Specified log file directory ($LogDir) does not exist or is not a directory\n";
    return 0;
  }

  if (! -w _) {
    # use STDERR because CATCONOUT is yet to be opened
    print STDERR "valid_log_dir: Specified log file directory ($LogDir) is unwritable\n";
    return 0;
  }

  return 1;
}

#
# validate_con_names - determine whether Container name(s) supplied
#     by the caller are valid (i.e. that the DB is Consolidated and contains a 
#     Container with specified names) and modify a list of Containers against 
#     which scripts/statements will be run as directed by the caller:  
#     - if the caller indicated that a list of Container names to be validated
#       refers to Containers against which scripts/statements should not be 
#       run, remove them from $Containers
#     - otherwise, remove names of Containers which did not appear on the 
#       list of Container names to be validated from $Containers
#
# Parameters:
#   - reference to a string containing space-delimited name(s) of Container
#   - an indicator of whether the above list refers to Containers against 
#     which scripts/statements should not be run
#   - reference to an array of Container names, if any
#   - reference to an array of indicators of whether a corresponding 
#     Container is open (Y/N)
#   - an indicator of whether non-existent and closed PDBs should be ignored
#   - an indicator of whether debugging information should be produced
#
# Returns:
#   An empty list if an error was encountered or if the list of names of 
#   Containers to be excluded consisted of names of all Containers of a CDB.
#   A list of names of Containers which were either explicitly included or 
#   were NOT explicitly excluded by the caller
#
sub validate_con_names (\$$\@\@$$) {
  my ($ConNameStr, $Exclude, $Containers, $IsOpen, $Force, $DebugOn) = @_;

  if ($DebugOn) {
    my $msg = <<validate_con_names_DEBUG;
running validate_con_names(
  ConNameStr   = $$ConNameStr, 
  Exclude      = $Exclude, 
  Containers   = @$Containers,
  IsOpen       = @$IsOpen,
  Force        = $Force)
validate_con_names_DEBUG
    log_msg($msg);
  }

  if (!${$ConNameStr}) {
    # this subroutine should not be called unless there are Container names to 
    # validate
    log_msg("validate_con_names: missing Container name string\n");

    return ();
  }

  my $LocConNameStr = $$ConNameStr;
  $LocConNameStr =~ s/^'(.*)'$/$1/;  # strip single quotes
  # extract Container names into an array
  my @ConNameArr = split(/  */, $LocConNameStr);

  if (!@ConNameArr) {
    # string supplied by the caller contained no Container names
    log_msg("validate_con_names: no Container names to validate\n");

    return ();
  }

  # string supplied by the caller contained 1 or more Container names

  if (!@$Containers) {
    # report error and quit since the database is not Consolidated
    log_msg("validate_con_names: Container name(s) supplied but the DB is not Consolidated\n");

    return ();
  } 
    
  if ($DebugOn) {
    log_msg("validate_con_names: Container name string consisted of the following names {\n");
    foreach (@ConNameArr) {
      log_msg("validate_con_names: \t$_\n");
    }
    log_msg("validate_con_names: }\n");
  }

  # so here's a dilemma: 
  #   we need to 
  #   (1) verify that all names in @ConNameArr are also in @$Containers AND
  #   (2) compute either 
  #       @$Containers - @ConNameArr (if $Exclude != 0) or 
  #       @$Containers <intersect> @ConNameArr (if $Exclude == 0)
  #
  #       In either case, I would like to ensure that CDB$ROOT, if it ends up 
  #       in the resulting set, remains the first element of the array (makes 
  #       it easier when we nnee to decide at what point we can parallelize 
  #       execution across all remaining PDBs) and that PDBs are ordered by 
  #       their Container ID (I am just used to processing them in that order)
  #
  #   (1) would be easiest to accomplish if I were to store contents of 
  #   @$Containers in a hash and iterate over @ConNameArr, checking against 
  #`  that hash.  However, (2) requires that I traverse @$Containers and 
  #   decide whether to keep or remove an element based on whether it occurs 
  #   in @ConNameArr (which would require that I construct a hash using 
  #   contents of @ConNameArr) and the value of $Exclude
  #
  # I intend to implement the following algorithm:
  # - store contents of @ConNameArr in a hash (%ConNameHash)
  # - create a new array which will store result of (2) (@ConOut)
  # - for every element C in @$Containers
  #   - if %ConNameHash contains an entry for C
  #     - if !$Exclude
  #       - append C to @ConOut
  #   - else
  #     - if $Exclude
  #       - append C to @ConOut
  # - if, after we traverse @$Containers, %ConNameHash still contains some 
  #   entries which were not matched, report an error since it indicates that 
  #   $$ConNameStr contained some names which do not refer to existing 
  #   Container names
  # - if @ConOut is empty, report an error since there will be no Containers 
  #   in which to run scripts/statements
  # - return @ConOut which will by now contain names of all Containers in which
  #   scripts/statements will need to be run
  #

  my %ConNameHash;   # hash of elements of @ConNameArr

  foreach (@ConNameArr) {
    undef $ConNameHash{$_};
  }

  # array of Container names against which scripts/statements should be run
  my @ConOut = ();
  my $matched = 0;   # number of elements of @$Containers found in %ConNameHash

  my $CurCon; # index into @$Containers and @$IsOpen;

  for ($CurCon = 0; $CurCon <= $#$Containers; $CurCon++) {

    my $Con = $$Containers[$CurCon];
    my $Open = $$IsOpen[$CurCon];
    
    # if we have matched every element of %ConNameHash, there is no reason to 
    # check whether it contains $Con
    if (($matched < @ConNameArr) && exists($ConNameHash{$Con})) {
      $matched++; # remember that one more element of @$Containers was found

      # remove $Con from %ConNameHash so that if we end up not matching some 
      # specified Container names, we can list them as a part of error message
      delete $ConNameHash{$Con};

      if ($DebugOn) {
        log_msg("validate_con_names: $Con was matched\n");
      }

      # add matched Container name to @ConOut if caller indicated that 
      # Containers whose names were specified are to be included in the set 
      # of Containers against which scripts/statements will be run
      if (!$Exclude) {
        # Bug 18029946: will run scripts against this Container only if it is 
        # open
        if ($Open eq "Y") {
          push(@ConOut, $Con); 

          if ($DebugOn) {
            log_msg("validate_con_names: Added $Con to ConOut\n");
          }
        } elsif ($Force) {
          if ($DebugOn) {
            log_msg("validate_con_names: $Con is not Open, but Force is specified, so skip it\n");
          }
        } else {
          log_msg("validate_con_names: $Con is not open\n");
          
          return ();
        }
      }
    } else {
      if ($DebugOn) {
        log_msg("validate_con_names: $Con was not matched\n");
      }

      # add unmatched Container name to @ConOut if caller indicated that 
      # Containers whose names were specified are to be excluded from the set 
      # of Containers against which scripts/statements will be run
      if ($Exclude) {
        # Bug 18029946: will run scripts against this Container only if it is 
        # open
        if ($Open eq "Y") {
          push(@ConOut, $Con); 

          if ($DebugOn) {
            log_msg("validate_con_names: Added $Con to ConOut\n");
          }
        } elsif ($Force) {
          if ($DebugOn) {
            log_msg("validate_con_names: $Con is not Open, but Force is specified, so skip it\n");
          }
        } else {
          log_msg("validate_con_names: $Con is not open\n");
          
          return ();
        }
      }
    }
  }

  # if any of specified Container names did not get matched, report an error
  if ($matched != @ConNameArr) {
    # Bug 18029946: print the list of unmatched Container names if were not 
    # told to ignore unmatched Container names or if debug flag is set
    if (!$Force || $DebugOn) {
      log_msg("validate_con_names: some specified Container names do not refer to existing Containers:\n");
      for (keys %ConNameHash) {
        log_msg("\t$_\n");
      }

      if ($Force) {
        log_msg("validate_con_names: unmatched Container names ignored because Force is specified\n");
      }
    }

    # Bug 18029946: unless told to ignore unmatched Container names, return 
    # an empty list which will cause the caller to report an error
    if (!$Force) {
      return ();
    }
  }

  # if @ConOut is empty (which could happen if we were asked to exclude every 
  # Container)
  if (!@ConOut) {
    log_msg("validate_con_names: resulting Container list is empty\n");

    return ();
  }

  if ($DebugOn) {
    log_msg("validate_con_names: resulting Container set consists of the following Containers {\n");
    foreach (@ConOut) {
      log_msg("validate_con_names:\t$_\n");
    }
    log_msg("validate_con_names: }\n");
  }

  return @ConOut;
}

#
# get_con_names_and_open_modes - query V$CONTAINERS to get names and open modes
#                                of all Containers
#
# parameters:
#   - connect string
#   - a command to create a file whose existence will indicate that the 
#     last statement of the script has executed (needed by exec_DB_script())
#   - base for a name of a "done" file (see above)
#   - reference to an array of Container names (OUT)
#   - reference to an array of indicators of whether a corresponding 
#     Container is open (OUT)
#   - indicator of whether to produce debugging info
#
sub get_con_names_and_open_modes ($$$\@\@$) {
  my ($myConnect, $DoneCmd, $DoneFilePathBase, $ConNames, $IsOpen, 
      $debugOn) = @_;

  # NOTE: it is important that we fetch data from tables (CONTAINER$ and OBJ$ 
  #       rather than dictionary views (e.g. DBA_PLUGGABLE_DATABASES) because 
  #       views may yet to be created if this procedure is used when running 
  #       catalog.sql
  # NOTE: since a non-CDB may also have a row in CONTAINER$ with con_id#==0,
  #       we must avoid fetching a CONTAINER$ row with con_id==0 when looking 
  #       for Container names 
  #
  # Bug 18070841: "SET LINES" was added to make sure that both the PDB name 
  #               and the open_mode are on the same line.  500 is way bigger 
  #               than what is really needed, but it does not hurt anything.

  my @GetConNamesAndOpenModesStmts = (
    "connect $myConnect\n",
    "set echo off\n",
    "set heading off\n",
    "set lines 500\n",
    "select \'XXXXXX\' || name, decode(open_mode, 'MOUNTED', 'N', 'Y') as open from v\$containers where con_id > 0 order by con_id\n/\n",
  );

  # each row consists of a Container name and Y/N indicating whether it is open
  my @rows = exec_DB_script(@GetConNamesAndOpenModesStmts, "XXXXXX", 
                            $DoneCmd, $DoneFilePathBase, $debugOn);

  # split each row into a Container name and an indicator of whether is is open
  for my $row ( @rows ) {
    my ($name, $open) = split /\s+/, $row;
    push @$ConNames, $name;
    push @$IsOpen, $open;
  }

  return;
}

#
# get_con_open_modes - query V$CONTAINERS to get Containers' open modes
#
# parameters:
#   - connect string
#   - a command to create a file whose existence will indicate that the 
#     last statement of the script has executed (needed by exec_DB_script())
#   - base for a name of a "done" file (see above)
#   - reference to an array of indicators of whether a Container is open (OUT)
#   - indicator of whether we will be running user scripts (meaning that
#     CDB$ROOT and PDB$SEED should be skipped)
#   - indicator of whether to produce debugging info
#
sub get_con_open_modes ($$$\@$$) {
  my ($myConnect, $DoneCmd, $DoneFilePathBase, $IsOpen, $userScript,
      $debugOn) = @_;

  # con_id for the first Container whose open_mode needs to be fetched
  my $firstConId = $userScript ? 3 : 1;

  my @GetConOpenModesStmts = (
    "connect $myConnect\n",
    "set echo off\n",
    "set heading off\n",
    "set lines 500\n",
    "select \'XXXXXX\' || decode(open_mode, 'MOUNTED', 'N', 'Y') as open from v\$containers where con_id >= ".$firstConId." order by con_id\n/\n",
  );

  # each row consists of a Container name and Y/N indicating whether it is open
  my @rows = exec_DB_script(@GetConOpenModesStmts, "XXXXXX", 
                            $DoneCmd, $DoneFilePathBase, $debugOn);

  for my $row ( @rows ) {
    push @$IsOpen, $row;
  }

  return;
}

#
# seed_pdb_mode_state - return PDB$SEED's state, 0 if not there
#
# parameters:
#   - connect string
#   - a command to create a file whose existence will indicate that the 
#     last statement of the script has executed (needed by exec_DB_script())
#   - base for a name of a "done" file (see above)
#   - indicator of whether to produce debugging info
#
sub seed_pdb_mode_state ($$$$) {
  my ($myConnect, $DoneCmd, $DoneFilePathBase, $debugOn) = @_;

  my @SeedModeStateStatements = (
    "connect $myConnect\n",
    "set echo off\n",
    "set heading off\n",
    "select \'XXXXXX\' || state from x\$con where name='PDB\$SEED'\n/\n",
  );


  my @retValues = exec_DB_script(@SeedModeStateStatements, "XXXXXX", 
                                 $DoneCmd, $DoneFilePathBase, $debugOn);

  foreach (@retValues) {
    return $_;
  }
  return 0;
}

# handler for SIGINT while resetting PDB$SEED mode
sub handle_sigint_for_pdb_seed_mode () {
  log_msg("Caught SIGINT while changing PDB\$SEED's mode\n");

  # reregister SIGINT handler in case we are running on a system where 
  # signal(3) acts in "the old unreliable System V way", i.e. clears the 
  # signal handler
  $SIG{INT} = \&handle_sigint_for_pdb_seed_mode;

  return;
}

#
# reset_seed_pdb_mode - close PDB$SEED on all instances and open it in the 
#                       specified mode
#
# parameters:
#   - connect string
#   - mode in which PDB$SEED is to be opened
#   - a command to create a file whose existence will indicate that the 
#     last statement of the script has executed (needed by exec_DB_script())
#   - base for a name of a "done" file (see above)
#   - indicator of whether to produce debugging info
#
# Bug 14248297: close PDB$SEED on all RAC instances. If the PDB$SEED is to be
# opened on all instances, then the 'seedMode' argument must specify it.
#
sub reset_seed_pdb_mode ($$$$$) {
  my ($myConnect, $seedMode, $DoneCmd, $DoneFilePathBase, $debugOn) = @_;

  my @ResetSeedModeStatements = (
    "connect $myConnect\n",
    qq#alter session set "_oracle_script"=TRUE\n/\n#,
    "alter pluggable database pdb\$seed close immediate instances=all\n/\n",
    "alter pluggable database pdb\$seed $seedMode\n/\n",
  );

  # temporarily reset $SIG{INT} to avoid dying while PDB$SEED is in transition
  my $saveIntHandlerRef = $SIG{INT};
  
  $SIG{INT} = \&handle_sigint_for_pdb_seed_mode;

  if ($debugOn) {
    log_msg("reset_seed_pdb_mode: temporarily reset SIGINT handler\n");
  }

  exec_DB_script(@ResetSeedModeStatements, undef, $DoneCmd, 
                 $DoneFilePathBase, $debugOn);

  # 
  # restore INT signal handler 
  #
  $SIG{INT} = $saveIntHandlerRef;

  if ($debugOn) {
    log_msg("reset_seed_pdb_mode: restored SIGINT handler\n");
  }

}

#
# shutdown_db - shutdown the database in specified mode
#
# parameters:
#   - connect string
#   - shutdown mode
#   - a command to create a file whose existence will indicate that the 
#     last statement of the script has executed (needed by exec_DB_script())
#   - base for a name of a "done" file (see above)
#   - indicator of whether to produce debugging info
#
sub shutdown_db ($$$$$) {
  my ($myConnect, $shutdownMode, $DoneCmd, $DoneFilePathBase, $debugOn) = @_;

  my @ShutdownStatements = (
    "connect $myConnect\n",
    "SHUTDOWN $shutdownMode\n",
  );

  exec_DB_script(@ShutdownStatements, undef, $DoneCmd, 
                 $DoneFilePathBase, $debugOn);
}

# validate_script_path
#
# Parameters:
#   $FileName - name of file to validate
#   $Dir      - directory, if any, in which the file is expected to be found
#   $DebugOn  - an indicator of whether to produce diagnostic messages
#
# Description:
#   construct file's path using its name and optional directory and determine 
#   if it exists and is readable
#
# Returns:
#   file's path
sub validate_script_path ($$$) {
  my ($FileName, $Dir, $DebugOn) = @_;

  my $Path;                                                       # file path
    
  if ($DebugOn) {
    log_msg("validate_script_path: getting ready to construct path for script $FileName\n");
  }

  if ($Dir) {
    $Path = $Dir."/".$FileName;
  } else {
    $Path = $FileName;
  }

  if ($DebugOn) {
    log_msg("validate_script_path: getting ready to validate script $Path\n");
  }

  stat($Path);

  if (! -e _ || ! -r _) {
    log_msg("validate_script_path: sqlplus script $Path does not exist or is unreadable\n");
    return undef;
  }

  if (! -f $Path) {
    log_msg("validate_script_path: supposed sqlplus script $Path is not a regular file\n");
    return undef;
  }

  if ($DebugOn) {
    log_msg("validate_script_path: successfully validated script $Path\n");
  }

  return $Path;
}

#
# err_logging_tbl_stmt - construct and issue SET ERRORLOGGING ON [TABLE ...]
#                        statement, if any, that needs to be issued to create 
#                        an Error Logging table
#
# parameters:
#   - an indicator of whether to save error logging information, which may be 
#     set to ON to create a default error logging table or to the name of an 
#     existing error logging table (IN)
#   - reference to an array of file handles containing a handle to which to 
#     send SET ERRORLOGGING statement (IN)
#   - process number (IN)
#   - an indicator of whether to produce debugging info (IN)
#
sub err_logging_tbl_stmt ($$$$) {
  my ($ErrLogging, $FileHandles_REF, $CurProc, $DebugOn) =  @_;

  # NOTE:
  # I have observed that if you issue 
  #   SET ERRORLOGGING ON IDENTIFIER ...
  # in the current Container after issuing
  #   SET ERRORLOGGING ON [TABLE ...] in a different Container, 
  # the error logging table will not be created in the current 
  # Container.  
  # 
  # To address this issue, I will first issue 
  #   SET ERRORLOGING ON [TABLE <table-name>]
  # and only then issue SET ERRORLOGGING ON [IDENTIFIER ...]
  #
  # To make sure that the error logging table does not get 
  # created as a Metadata Link, I will temporarily reset 
  # _ORACLE_SCRIPT parameter before issuing 
  #   SET ERRORLOGING ON [TABLE <table-name>]

  my $ErrLoggingStmt;

  if ($ErrLogging) {

    if ($DebugOn) {
      log_msg("err_logging_tbl_stmt: ErrLogging = $ErrLogging\n");
    }

    # if ERRORLOGGING is to be enabled, construct the SET ERRORLOGGING 
    # statement which will be sent to every process
    $ErrLoggingStmt = "SET ERRORLOGGING ON ";

    if ((lc $ErrLogging) ne "on") {
      # customer supplied error logging table name
      # @@@@ NO QUOTES WOULD GET
      # SP2-1507 Errorlogging table, role or privilege is missing or not accessible
      $ErrLoggingStmt .= qq#TABLE $ErrLogging#;
    }

    if ($DebugOn) {
      my $msg = <<msg;
err_logging_tbl_stmt: ErrLoggingStmt = $ErrLoggingStmt
    temporarily resetting _parameter before issuing 
    SET ERRORLOGGING ON [TABLE ...] in process $CurProc
msg
      log_msg($msg);
    }

    printToSqlplus("err_logging_tbl_stmt", $FileHandles_REF->[$CurProc],
                   qq#ALTER SESSION SET "_ORACLE_SCRIPT"=FALSE#,
                   "\n/\n", $DebugOn);

    # send SET ERRORLOGGING ON [TABLE ...] statement
    if ($DebugOn) {
      log_msg("err_logging_tbl_stmt: sending $ErrLoggingStmt to process $CurProc\n");
    }

    printToSqlplus("err_logging_tbl_stmt", $FileHandles_REF->[$CurProc],
                   $ErrLoggingStmt, "\n", $DebugOn);

    if ($DebugOn) {
      log_msg("err_logging_tbl_stmt: setting _parameter after issuing SET ERRORLOGGING ON [TABLE ...] in process $CurProc\n");
    }

    printToSqlplus("err_logging_tbl_stmt", $FileHandles_REF->[$CurProc],
                   qq#ALTER SESSION SET "_ORACLE_SCRIPT"=TRUE#, "\n/\n", 
                   $DebugOn);
  }

  return $ErrLoggingStmt;
}

#
# start_processes - start processes
#
# parameters:
#   - number of processes to start (IN)
#   - base for constructing log file names (IN)
#   - reference to an array of file handles; will be obtained as a 
#     side-effect of calling open() (OUT)
#   - reference to an array of process ids; will be obtained by calls 
#     to open (OUT)
#   - reference to an array of Container names; array will be empty if 
#     we are operating against a non-Consolidated DB (IN)
#   - name of the Root Container; undefined if operating against a non-CDB (IN)
#   - connect string used to connect to a DB (IN)
#   - an indicator of whether SET ECHO ON should be sent to SQL*Plus 
#     process (IN)
#   - an indicator of whether to save ERRORLOGGING information (IN)
#   - an indicator of whether to produce debugging info (IN)
#   - an indicator of whether processes are being started for the first 
#     time (IN)
#   - an indicator of whether called by cdb_sqlexec.pl
#
# Returns: 1 if an error is encountered
#
sub start_processes ($$\@\@\@$$$$$$$$) {
  my ($NumProcs, $LogFilePathBase, $FileHandles, $ProcIds, $Containers, $Root,
      $ConnectString, $EchoOn, $ErrLogging, $DebugOn, $FirstTime, 
      $userScript, $DoneCmd) =  @_;

  my $ps;

  #@@@@ add con_id
  my $CurrentContainerQuery = qq#select '==== Current Container = ' || SYS_CONTEXT('USERENV','CON_NAME') || ' Id = ' || SYS_CONTEXT('USERENV','CON_ID') || ' ' || TO_CHAR(SYSTIMESTAMP,'YY-MM-DD HH:MI:SS') || ' ====' AS now_connected_to from sys.dual;\n/\n#;

  if ($DebugOn) {
    log_msg("start_processes: will start $NumProcs processes\n");
  }

  # 14787047: Save STDOUT so we can restore it after we start each process
  if (!open(SAVED_STDOUT, ">&STDOUT")) {
    log_msg("start_processes: failed to open SAVED_STDOUT\n");
    return 1;
  }

  # Keep Perl happy and avoid the warning "SAVED_STDOUT used only once"
  print SAVED_STDOUT "";

  # remember whether processes will be running against one or more Containers 
  # of a CDB, starting with the Root
  my $switchIntoRoot = (@$Containers && ($Containers->[0] eq $Root));

  for ($ps=0; $ps < $NumProcs; $ps++) {
    my $LogFile = $LogFilePathBase.$ps.".log";

    # If starting for the first time, open for write; otherwise append
    if ($FirstTime) {
      if (!open (STDOUT,">", "$LogFile")) {
        log_msg("start_processes: failed to open STDOUT (1)\n");
        return 1;
      }
    } else {
      close (STDOUT);
      if (!open (STDOUT,"+>>", "$LogFile")) {
        log_msg("start_processes: failed to open STDOUT (2)\n");
        return 1;
      }
    }

    my $id = open ($FileHandles->[$ps], "|-", "sqlplus /nolog");

    if (!$id) {
      log_msg("start_processes: failed to open pipe to SQL*Plus\n");
      return 1;
    }

    push(@$ProcIds, $id);
      
    if ($DebugOn) {
      log_msg("start_processes: process $ps (id = $ProcIds->[$#$ProcIds]) will use log file $LogFile\n");
    }

    # file handle for the current process
    my $fh = $FileHandles->[$ps];

    # send initial commands to the sqlplus session
    print $fh "connect $ConnectString\n";

    if ($DebugOn) {
      log_msg(qq#start_processes: connected using $ConnectString\n#);
    }

    # use ALTER SESSION SET APPLICATION MODULE/ACTION to identify this process
    printToSqlplus("start_processes", $fh,
                   qq#ALTER SESSION SET APPLICATION MODULE = 'catcon(pid=$PID)'#,
                   "\n/\n", $DebugOn);

    if ($DebugOn) {
      log_msg("start_processes: issued ALTER SESSION SET APPLICATION MODULE = 'catcon(pid=$PID)'\n");
    }

    printToSqlplus("start_processes", $fh,
                   qq#ALTER SESSION SET APPLICATION ACTION = 'started'#,
                   "\n/\n", $DebugOn);

    if ($DebugOn) {
      log_msg("start_processes: issued ALTER SESSION SET APPLICATION ACTION = 'started'\n");
    }

    if ($EchoOn) {
      printToSqlplus("start_processes", $fh, qq#SET ECHO ON#, "\n", $DebugOn);

      if ($DebugOn) {
        log_msg("start_processes: SET ECHO ON has been issued\n");
      }
    }
    
    # if running scripts against one or more Containers of a Consolidated 
    # Database, 
    # - if the Root is among Containers against which scripts will 
    #   be run (in which case it will be found in $Containers->[0]), switch 
    #   into it (because code in catconExec() expects that to be the case); 
    #   if scripts will not be run against the Root, there is no need to 
    #   switch into any specific Container - catconExec will handle that case 
    #   just fine all by itself
    # - turn on the "secret" parameter to ensure correct behaviour 
    #   of DDL statements; it is important that we do it after we issue 
    #   SET ERRORLOGGING ON to avoid creating error logging table as a 
    #   Common Table
    if (@$Containers) {
      if ($switchIntoRoot) {
        printToSqlplus("start_processes", $fh, 
                       qq#ALTER SESSION SET CONTAINER = $Root#, "\n/\n", 
                       $DebugOn);
        if ($DebugOn) {
          log_msg(qq#start_processes: switched into Container $Root\n#);
        }
      }
      
      if (!$userScript) {
        printToSqlplus("start_processes", $fh, 
                       qq#ALTER SESSION SET "_ORACLE_SCRIPT"=TRUE#, "\n/\n", 
                       $DebugOn);
      }

      if ($DebugOn) {
        log_msg("start_processes: _parameter was set\n");
      }
    }
    #@@@@
    $fh->flush;
  }

  # 14787047: Restore saved stdout
  close (STDOUT);
  open (STDOUT, ">&SAVED_STDOUT");

  return create_done_files($NumProcs, $LogFilePathBase,
                           $FileHandles, $ProcIds, 
                           $DebugOn, $DoneCmd);
}

#
# done_file_name_prefix - generate prefix of a name for a "done" file using 
#                         file name base and the id of a process to which 
#                         the "done" file belongs
#
sub done_file_name_prefix($$) {
    my ($FilePathBase, $ProcId) =  @_;

  return $FilePathBase."_catcon_".$ProcId;
}

#
# done_file_name - generate name for a "done" file using file name base 
#                  and the id of a process to which the "done" dile belongs
#
sub done_file_name($$) {
    my ($FilePathBase, $ProcId) =  @_;

  return done_file_name_prefix($FilePathBase, $ProcId).".done";
}

#
# create_done_files - Creates "done" files to be created for all processes.
#                     next_proc() will look for these files to determine
#                     whether a given process is available to take on the
#                     next script or SQL statement
#
# parameters:
#   - number of processes to start (IN)
#   - base for constructing log file names (IN)
#   - reference to an array of file handles (IN)
#   - reference to an array of process ids (IN)
#   - an indicator of whether to produce debugging info (IN)
#   - Done Command (IN)
#
sub create_done_files ($$$$$$) {

    my ($NumProcs, $LogFilePathBase, $FileHandles_REF, 
        $ProcIds_REF, $DebugOn, $DoneCmd) =  @_;

    # Loop through processors
    for (my $CurProc = 0; $CurProc < $NumProcs; $CurProc++) {
      
      # file which will indicate that process $CurProc finished its work and 
      # is ready for more
      #
      # Bug 18011217: append _catcon_$ProcIds_REF->[$CurProc] to 
      # $LogFilePathBase to avoid conflicts with other catcon processes 
      # running on the same host
      my $DoneFile = 
        done_file_name($LogFilePathBase, $ProcIds_REF->[$CurProc]);

      # create a "done" file unless it already exists
      if (! -e $DoneFile) {
        # "done" file does not exist - cause it to be created
        printToSqlplus("create_done_files", $FileHandles_REF->[$CurProc],
                       qq/$DoneCmd $DoneFile/, "\n", $DebugOn);

        # flush the file so a subsequent test for file existence does 
        # not fail due to buffering
        $FileHandles_REF->[$CurProc]->flush;

        if ($DebugOn) {
          my $msg = <<msg;
create_done_files: sent "$DoneCmd $DoneFile"
    to process $CurProc (id = $ProcIds_REF->[$CurProc]) to indicate its 
    availability
msg
          log_msg($msg);
        }
      } elsif (! -f $DoneFile) {
        log_msg(qq#create_done_files: "done" file name collision: $DoneFile\n#);
        return 1;
      } else {
        if ($DebugOn) {
          log_msg(qq#create_done_files: "done" file $DoneFile already exists\n#);
        }
      }
    }
    return 0;
}

#
# end_processes - end all processes
#
# parameters:
#   - index of the first process to end (IN)
#   - index of the last process to end (IN)
#   - reference to an array of file handles (IN)
#   - reference to an array of process ids; will be cleared of its 
#     elements (OUT)
#   - an indicator of whether to produce debugging info (IN)
#   - log file path base
#
sub end_processes ($$\@\@$$) {
  my ($FirstProcIdx, $LastProcIdx, $FileHandles, $ProcIds, $DebugOn,
      $LogFilePathBase) =  @_;

  my $ps;

  if ($FirstProcIdx < 0) {
    log_msg("end_processes: FirstProcIdx ($FirstProcIdx) was less than 0\n");
    return 1;
  }

  if ($LastProcIdx < $FirstProcIdx) {
    log_msg("end_processes: LastProcIdx ($LastProcIdx) was less than  FirstProcIdx ($FirstProcIdx)\n");
    return 1;
  }

  if ($DebugOn) {
    log_msg("end_processes: will end processes $FirstProcIdx to $LastProcIdx\n");
  }

  $SIG{CHLD} = 'IGNORE';

  for ($ps = $FirstProcIdx; $ps <= $LastProcIdx; $ps++) {
    if ($FileHandles->[$ps]) {
      # @@@@
      #print {$FileHandles->[$ps]} "PROMPT ========== PROCESS ENDED ==========\n";
      #
      #printToSqlplus("end_processes", $FileHandles->[$ps],
      #               "EXIT", "\n", $DebugOn);

      print {$FileHandles->[$ps]} "EXIT\n";
      close ($FileHandles->[$ps]);
      $FileHandles->[$ps] = undef;
    } elsif ($DebugOn) {
      log_msg("end_processes: process $ps has already been stopped\n");
    }
  }

  # clean up completion files
  clean_up_compl_files($LogFilePathBase, $ProcIds, $FirstProcIdx, $LastProcIdx,
                       $DebugOn);
  
  splice @$ProcIds, $FirstProcIdx, $LastProcIdx - $FirstProcIdx + 1;

  if ($DebugOn) {
    log_msg("end_processes: ended processes $FirstProcIdx to $LastProcIdx\n");
  }

  return 0;
}

#
# clean_up_compl_files - purge files indicating completion of processes.
#                        Purging will start from the first process given
#                        and end at the last process given.
#
# parameters:
#   - base of process completion file name
#   - reference to an array of process ids
#   - First process whose completion files are to be purged
#   - Last processes whose completion files are to be purged
#   - an indicator of whether to print debugging info
#
sub clean_up_compl_files ($$$$$) {
  my ($FileNameBase, $ProcIds, $FirstProc, $LastProc, $DebugOn) =  @_;

  my $ps;

  if ($DebugOn) {
    log_msg(qq#clean_up_compl_files: FileNameBase = $FileNameBase, FirstProc = $FirstProc, LastProc = $LastProc\n#);
  }

  for ($ps=$FirstProc; $ps <= $LastProc; $ps++) {
    my $DoneFile = done_file_name($FileNameBase, $ProcIds->[$ps]);
    
    if (-e $DoneFile && -f $DoneFile) {
      if ($DebugOn) {
        log_msg(qq#clean_up_compl_files: call sureunlink to remove $DoneFile\n#);
      }

      sureunlink($DoneFile, $DebugOn);
      
      if ($DebugOn) {
        log_msg(qq#clean_up_compl_files: removed $DoneFile\n#);
      }
    }
  }
}

#
# get_log_file_base_path - determine base path for log files
#
# Parameters:
#   - log directory, as specified by the user
#   - base for log file names
#   - an indicator of whether to produce debugging info
#
sub get_log_file_base_path ($$$) {
  my ($LogDir, $LogBase, $DebugOn) = @_;

  if ($LogDir) {
    if ($DebugOn) {
      # use STDERR because CATCONOUT is yet to be opened
      print STDERR "get_log_file_base_path: log file directory = $LogDir\n";
    } 

    return ($LogDir."/".$LogBase);
  } else {
    if ($DebugOn) {
      # use STDERR because CATCONOUT is yet to be opened
      print STDERR "get_log_file_base_path: no log file directory was specified\n";
    }

    return $LogBase;
  }
}

#
# send_sig_to_procs - given an array of process ids, send specified signal to 
#                     these processes 
#
# Parameters:
#   - reference to an array of process ids
#   - signal to send
#
# Returns:
#   number of processes whose ids were passed to us which got the signal
#
sub send_sig_to_procs (\@$) {
  my ($ProcIds, $Sig)  =  @_;
  
  return  kill($Sig, @$ProcIds);
}

#
# next_proc - determine next process which has finished work assigned to it
#             (and is available to execute a script or an SQL statement)
#
# Description:
#   This subroutine will look for a file ("done" file) indicating that the 
#   process has finished running a script or a statement which was sent to it.
#   Once such file is located, it will be deleted and a number of a process 
#   to which that file corresponded will be returned to the caller
#
# Parameters:
#   - number of processes from which we may choose the next available process
#   - total number of processes which were started (used when we try to
#     determine if some processes may have died)
#   - number of the process starting with which to start our search; if the 
#     supplied number is greater than $ProcsUsed, it will be reset to 0
#   - reference to an array of booleans indicating status of which processes 
#     should be ignored; may be undefined
#   - base for names of files whose presense will indicate that a process has 
#     completed
#   - reference to an array of process ids
#   - an indicator of whether we are running under Windows
#   - an indicator of whether to display diagnostic info
#
sub next_proc ($$$$$$$$) {
  my ($ProcsUsed, $NumProcs, $StartingProc, $ProcsToIgnore, 
      $FilePathBase, $ProcIds, $Windows, $DebugOn) = @_;

  if ($DebugOn) {
    my $msg = <<next_proc_DEBUG;
  running next_proc(ProcsUsed    = $ProcsUsed, 
                    NumProcs     = $NumProcs,
                    StartingProc = $StartingProc,
                    FilePathBase = $FilePathBase,
                    Windows      = $Windows,
                    DebugOn      = $DebugOn);

next_proc_DEBUG
    log_msg($msg);
  }

  # process number; will be used to construct names of "done" files
  # before executing the while loop for the first time, it will be set to 
  # $StartingProc.  If that number is outside of [0, $ProcsUsed-1], 
  # it [$CurProc] will be reset to 0; for subsequent iterations through the 
  # while loop, $CurProc will start with 0
  my $CurProc = ($StartingProc >= 0 && $StartingProc <= $ProcsUsed-1) 
    ? $StartingProc : 0;
    
  # look for *.done files which will indicate which processes have 
  # completed their work

  # we may end up waiting a while before finding an available process and if 
  # debugging is turned on, user's screen may be flooded with 
  #     next_proc: Skip checking process ...
  # and
  #     next_proc: Checking if process ... is available
  # messages.  
  #
  # To avoid this, we will print this message every 10 second or so.  Since 
  # we check for processes becoming available every 0.01 of a second (or so), 
  # we will report generate debugging messages every 1000-th time through the 
  # loop
  my $itersBetweenMsgs = 1000;

  for (my $numIters = 0; ; $numIters++) {
    #
    # Make sure no sql processors died (Windows only).
    # For Unix this handle through signals.
    #
    if ($Windows) {
      # sending signal 0 to processes whose ids are stored in an array will 
      # return a number of processes to which this signal could be 
      # delivered, ergo which are alive
      my $LiveProcs = send_sig_to_procs(@$ProcIds, 0);
      
      if ($NumProcs != $LiveProcs) {

        log_msg(qq#next_proc: total processes ($NumProcs) != number of live processes ($LiveProcs); giving up\n#);

        catconWrapUp();
        send_sig_to_procs(@$ProcIds, 9);
        clean_up_compl_files($FilePathBase, $ProcIds, 0, $ProcsUsed-1, 
                             $DebugOn);
        catcon_HandleSigchld();

        return -1;
      }
    }

    for (; $CurProc < $ProcsUsed; $CurProc++) {
        
      if (   $ProcsToIgnore && @$ProcsToIgnore 
          && $ProcsToIgnore->[$CurProc]) {
        if ($DebugOn && $numIters % $itersBetweenMsgs == 0) {
          log_msg("next_proc: Skip checking process $CurProc\n");
        }

        next;
      }

      # file which will indicate that process $CurProc finished its work
      #
      # Bug 18011217: append _catcon_$ProcIds->[$CurProc] to $FilePathBase 
      # to avoid conflicts with other catcon processes running on the same 
      # host
      my $DoneFile = done_file_name($FilePathBase, $ProcIds->[$CurProc]);

      if ($DebugOn && $numIters % $itersBetweenMsgs == 0) {
        log_msg("next_proc: Checking if process $CurProc (id = $ProcIds->[$CurProc]) is available\n");
      }

      #
      # Is file is present, remove the "done" file (thus making this process 
      # appear "busy") and return process number to the caller.
      #
      if (-e $DoneFile) {
        if ($DebugOn) {
          log_msg("next_proc: call sureunlink to remove $DoneFile\n");
        }

        sureunlink($DoneFile, $DebugOn);

        if ($DebugOn) {
          log_msg("next_proc: process $CurProc is available\n");
        }

        return $CurProc;
      }
    }
    select (undef, undef, undef, 0.01);

    $CurProc = 0;
  }
  
  return -1;  # this statement will never be rached
}

#
# wait_for_completion - wait for completion of processes
#
# Description:
#   This subroutine will wait for processes to indicate that they've 
#   completed their work by creating a "done" file.  Since it will use 
#   next_proc() (which deleted "done" files of processes whose ids it returns) 
#   to find processes which are done running, this subroutine will generate 
#   "done" files once all processes are done to indicate that they are 
#   available to take on more work.
#
# Parameters:
#   - number of processes which were used (and whose completion we need to 
#     confirm)
#   - total number of processes which were started
#   - base for generating names of files whose presense will indicate that a 
#     process has completed
#   - references to an array of process file handles
#   - reference to a array of process ids
#   - command which will be sent to a process to cause it to generate a 
#     "done" file
#   - an indicator of whether we are running under Windows
#   - reference to an array of statements, if any, to be issued when a process 
#     completes
#   - if connected to a CDB, name of the Root Container into which we should 
#     switch (Bug 17898118: ensures that no process is connected to a PDB 
#     which may get closed by some script (which would run only if there are 
#     no processes running scripts in that PDB))
#   - internal connect string
#   - an indicator of whether to display diagnostic info
#
sub wait_for_completion ($$$\@\@$$\@$$$) {
  my ($ProcsUsed, $NumProcs, $FilePathBase, $ProcFileHandles, 
      $ProcIds, $DoneCmd, $Windows, $EndStmts, $Root, $InternalConnectString, 
      $DebugOn) = @_;

  if ($DebugOn) {
    my $msg = <<wait_for_completion_DEBUG;
  running wait_for_completion(ProcsUsed             = $ProcsUsed, 
                              FilePathBase          = $FilePathBase,
                              DoneCmd               = $DoneCmd,
                              Windows               = $Windows,
                              Root                  = $Root,
                              InternalConnectString = $InternalConnectString,
                              DebugOn               = $DebugOn);

wait_for_completion_DEBUG
      log_msg($msg);
  }

  # process number
  my $CurProc = 0;
    
  if ($DebugOn) {
    log_msg("wait_for_completion: waiting for $ProcsUsed processes to complete\n");
  }

  # look for *.done files which will indicate which processes have 
  # completed their work

  my $NumProcsCompleted = 0;  # how many processes have completed

  # this array will be used to keep track of processes which have completed 
  # so as to avoid checking for existence of files which have already been 
  # seen and removed
  my @ProcsCompleted = (0) x $ProcsUsed;

  while ($NumProcsCompleted < $ProcsUsed) {
    $CurProc = next_proc($ProcsUsed, $NumProcs, $CurProc + 1, \@ProcsCompleted,
                         $FilePathBase, $ProcIds, $Windows, $DebugOn);

    if ($CurProc < 0) {
      log_msg(qq#wait_for_completion: unexpected error in next_proc()\n#);
      return 1;
    }

    # if the caller has supplied us with statements to run after a 
    # process finished its work, do it now
    if ($EndStmts && $#$EndStmts >= 0) {

      if ($DebugOn) {
        log_msg("wait_for_completion: sending completion statements to process $CurProc:\n");
      }

      foreach my $Stmt (@$EndStmts) {

        # $Stmt may contain %proc strings which need to be replaced with 
        # process number, but we don't want to modify the statement in 
        # @$EndStmts, so we modify a copy of it
        my $Stmt1;

        ($Stmt1 = $Stmt) =~ s/%proc/$CurProc/g;
        
        if ($DebugOn) {
          log_msg("\t$Stmt1\n");
        }

        printToSqlplus("wait_for_completion", $ProcFileHandles->[$CurProc],
                       $Stmt1, "\n", $DebugOn);
      }

      $ProcFileHandles->[$CurProc]->flush; # flush the buffer
    }

    # Bug 17898118: if connected to a CDB, switch the process into the Root
    # to avoid getting caught connected to a PDB that gets closed. 
    #
    # Before switching, however, we need to check to make sure the CDB is 
    # open (some scripts shut down the CDB, and trying to switch into the 
    # Root while the CDB is closed results in errors
    #
    # Bug 18011217: append _catcon_$ProcIds->[0] to $FilePathBase to avoid 
    # conflicts with other catcon processes running on the same host
    if ($Root) {
      my $instanceStatus = 
        get_instance_status($InternalConnectString, $DoneCmd, 
                            done_file_name_prefix($FilePathBase, 
                                                  $ProcIds->[0]), 
                            $DebugOn);
      if ((defined $instanceStatus) && $instanceStatus =~ /^OPEN/) {
        if ($DebugOn) {
          log_msg("wait_for_completion: switching process $CurProc into $Root\n");
        }

        print {$ProcFileHandles->[$CurProc]} 
          qq#ALTER SESSION SET CONTAINER = "$Root"\n/\n#;
        $ProcFileHandles->[$CurProc]->flush; # flush the buffer
      } elsif ($DebugOn) {
        log_msg("wait_for_completion: process $CurProc not switched into $Root because the CDB is not open\n");
      }
    }

    if ($DebugOn) {
      log_msg("wait_for_completion: process $CurProc is done\n");
    }

    $NumProcsCompleted++; # one more process has comleted

    # remember that this process has completed so next_proc does not try to 
    # check its status
    $ProcsCompleted[$CurProc] = 1;
  }

  if ($DebugOn) {
    log_msg("wait_for_completion: All $NumProcsCompleted processes have completed\n");
  }
  
  # issue statements to cause "done" files to be created to indicate
  # that all $ProcsUsed processes are ready to take on more work
  for ($CurProc = 0; $CurProc < $ProcsUsed; $CurProc++) {

    # file which will indicate that process $CurProc finished its work
    #
    # Bug 18011217: append _catcon_$ProcIds->[$CurProc] to $FilePathBase to 
    # avoid conflicts with other catcon processes running on the same host
    my $DoneFile = done_file_name($FilePathBase, $ProcIds->[$CurProc]);

    printToSqlplus("wait_for_completion", $ProcFileHandles->[$CurProc],
                   qq/$DoneCmd $DoneFile/,
                   "\n", $DebugOn);

    # flush the file so a subsequent test for file existence does 
    # not fail due to buffering
    $ProcFileHandles->[$CurProc]->flush;

    if ($DebugOn) {
      my $msg = <<msg;
wait_for_completion: sent "$DoneCmd $DoneFile" 
    to process $CurProc (id = $ProcIds->[$CurProc]) to indicate that it is 
    available to take on more work
msg
      log_msg($msg);
    }
  }

  return 0;
}

#
# return a timestamp in yyyy-mm-dd h24:mi:sec format
#
sub TimeStamp {
  my ($sec,$min,$hour,$mday,$mon,$year)=localtime(time);

  return sprintf "%4d-%02d-%02d %02d:%02d:%02d",
                 $year+1900,$mon+1,$mday,$hour,$min,$sec;
}

#
# getSpoolFileNameSuffix - generate suffix for a spool file names using 
#   container name supplied by the caller
#
# Parameters:
# - container name (IN)
#
sub getSpoolFileNameSuffix ($) {
 my ($SpoolFileNameSuffix) = @_;

 # $SpoolFileNameSuffix may contain characters which may be 
 # illegal in file name - replace them all with _
 $SpoolFileNameSuffix =~ s/\W/_/g;

 return lc($SpoolFileNameSuffix);
}

#
# pickNextProc - pick a process to run next statement or script
#
# Parameters:
#   (IN) unless indicated otherwise
#   - number of processes from which we may choose the next available process 
#   - total number of processes which were started (used when we try to
#     determine if some processes may have died)
#   - number of the process starting with which to start our search; if the 
#     supplied number is greater than $ProcsUsed, it will be reset to 0
#   - base for names of files whose presense will indicate that a process has 
#     completed
#   - reference to an array of process ids
#   - an indicator of whether we are running under Windows
#   - a command to create a file whose existence will indicate that the 
#     last statement of the script has executed (needed by exec_DB_script())
#   - base for a name of a "done" file (see above)
#   - an indicator of whether to display diagnostic info
# 
sub pickNextProc ($$$$$$$$) {
  my ($ProcsUsed, $NumProcs, $StartingProc, $FilePathBase, 
      $ProcIds, $Windows, $DoneFilePathBase, $DebugOn) = @_;

  # find next available process
  my $CurProc = next_proc($ProcsUsed, $NumProcs, $StartingProc, undef,
                          $FilePathBase, $ProcIds, $Windows, $DebugOn);
  if ($CurProc < 0) {
    # some unexpected error was encountered
    log_msg("pickNextProc: unexpected error in next_proc\n");

    return -1;
  }

  return $CurProc;
}

#
# firstProcUseStmts - issue statements to a process that is being used for 
#                     the first time
# Parameters:
#   - value of IDENTIFIER if ERRORLOGGING is enabled (IN)
#   - value of custom Errorlogging Identifier; if defined, $ErrLoggingIdent 
#     will be used as is, without appending "InitStmts" (IN)
#   - name of error logging table, if defined (IN)
#   - reference to an array of file handle references (IN)
#   - number of the process about to be used (IN)
#   - reference to an array of statements which will be executed in every 
#     process before it is asked to run the first script (IN)
#   - array used to keep track of processes to which statements contained in 
#     @$PerProcInitStmts_REF need to be sent because they [processes]
#     have not been used in the course of this invocation of catconExec()
#   - an indicator of whether debugging is enabled (IN)
#
sub firstProcUseStmts($$$$$$$$) {
  my ($ErrLoggingIdent, $CustomErrLoggingIdent, $ErrLogging, $FileHandles_REF, 
      $CurProc, $PerProcInitStmts_REF, $NeedInitStmts_REF, $DebugOn) = @_;
  
  if ($ErrLogging) {
    # construct and issue SET ERRORLOGGING ON [TABLE...] statement
    err_logging_tbl_stmt($ErrLogging, $FileHandles_REF, $CurProc, $DebugOn);

    if ($ErrLoggingIdent) {
      # send SET ERRORLOGGING ON IDENTIFIER ... statement
      my $Stmt;
      if ($CustomErrLoggingIdent) {
        # NOTE: if the caller of catconExec() has supplied a custom 
        #       Errorlogging Identifier, it has already been copied into 
        #       $ErrLoggingIdent which was then normalized, so our use of 
        #       $ErrLoggingIdent rather than $CustomErrLoggingIdent below is 
        #       intentional
        $Stmt = "SET ERRORLOGGING ON IDENTIFIER '".substr($ErrLoggingIdent, 0, 256)."'";
      } else {
        $Stmt = "SET ERRORLOGGING ON IDENTIFIER '".substr($ErrLoggingIdent."InitStmts", 0, 256)."'";
      }

      if ($DebugOn) {
        log_msg("firstProcUseStmts: sending $Stmt to process $CurProc\n");
      }

      printToSqlplus("firstProcUseStmts", $FileHandles_REF->[$CurProc],
                     $Stmt, "\n", $DebugOn);
    }
  }

  if ($DebugOn) {
    log_msg("firstProcUseStmts: sending init statements to process $CurProc:\n");
  }

  foreach my $Stmt (@$PerProcInitStmts_REF) {

    # $Stmt may contain %proc strings which need to be replaced with 
    # process number, but we don't want to modify the statement in 
    # @$PerProcInitStmts_REF, so we modify a copy of its element
    my $Stmt1;

    ($Stmt1 = $Stmt) =~ s/%proc/$CurProc/g;

    if ($DebugOn) {
      log_msg("\t$Stmt1\n");
    }

    printToSqlplus("firstProcUseStmts", $FileHandles_REF->[$CurProc],
                   $Stmt1, "\n", $DebugOn);
  }

  # remember that "initialization" statements have been run for this 
  # process
  $NeedInitStmts_REF->[$CurProc] = 0;

  return;
}

sub printToSqlplus ($$$$$) {
  my ($func, $fh, $stmt, $tail, $DebugOn) = @_;

  if ($DebugOn) {
    my $printableStmt = $stmt;
    $printableStmt  =~ s/['"]/#/g; # mask quotes to avoid confusion
    $printableStmt  =~ s/\n/#LF#/g; # mask \n
    my $debugQry = qq{select '$func(): $printableStmt' as catcon_statement from dual\n/\n};
    print {$fh} $debugQry;
  }

  print {$fh} qq#$stmt$tail#;
}

#
# additionalInitStmts - issue additional initialization statements after 
#   picking a new process to run a script in a given Container
#
# Parameters: (all parameters are IN unless noted otherwise)
#   - reference to an array of file handles used to communicate to processes
#   - process number of the process which was picked to run the next script
#   - connect string
#   - name of the container against which the next script will be run
#     (can be null if running against ROOT or in a non-CDB
#   - query which will identify current container in the log
#     (can be null if running against ROOT or in a non-consolidated DB)
#   - process id of the process hich was picked to run the next script
#   - an inidcator of whether to produce debugging info
#   - an indicator of whether called by cdb_sqlexec.pl
#
sub additionalInitStmts ($$$$$$$$$) {
  my ($FileHandles_REF, $CurProc, $ConnectString, $CurConName,
      $CurrentContainerQuery, $CurProcId, $EchoOn, $DebugOn, $userScript) = @_;

  if (!$userScript) {
    printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                   qq#ALTER SESSION SET "_ORACLE_SCRIPT"=TRUE#, "\n/\n", 
                   $DebugOn);
  }

  # set tab and trimspool to on, so that spooled log files start 
  # with a consistent setting
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#SET TAB ON#, "\n", 
                 $DebugOn);

  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#SET TRIMSPOOL ON#, "\n", 
                 $DebugOn);

  # ensure that common SQL*PLus vars that affect appearance of log files are 
  # set to consistent values.  This will ensure that vars modified in one 
  # script do not affect appearance of log files produced by running another 
  # script or running the same script in a different Container
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set colsep ' '#, "\n", 
                 $DebugOn);
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set escape off#, "\n", 
                 $DebugOn);
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set feedback 6#, "\n", 
                 $DebugOn);
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set heading on#, "\n", 
                 $DebugOn);
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set linesize 80#, "\n", 
                 $DebugOn);
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set long 80#, "\n", 
                 $DebugOn);
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set newpage 1#, "\n", 
                 $DebugOn);
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set numwidth 10#, "\n", 
                 $DebugOn);
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set pagesize 14#, "\n", 
                 $DebugOn);
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set recsep wrapped#, "\n", 
                 $DebugOn);
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set showmode off#, "\n", 
                 $DebugOn);
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set sqlprompt "SQL> "#, "\n", 
                 $DebugOn);
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set termout on#, "\n", 
                 $DebugOn);
  #@@@@ Don't overide these values needed for performance work
  #printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
  #               qq#set time off#, "\n", 
  #               $DebugOn);
  #printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
  #               qq#set timing off#, "\n", 
  #               $DebugOn);
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set trimout on#, "\n", 
                 $DebugOn);
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set underline on#, "\n", 
                 $DebugOn);
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set verify on#, "\n", 
                 $DebugOn);
  printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                 qq#set wrap on#, "\n", 
                 $DebugOn);
          
  if ($CurConName) {
    printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                   qq#ALTER SESSION SET CONTAINER = "$CurConName"#, "\n/\n", 
                   $DebugOn);

    if ($DebugOn) {
      log_msg("additionalInitStmts: process $CurProc (id = $CurProcId) connected to Container $CurConName\n");
    }
  }

  if ($CurrentContainerQuery) {
    print {$FileHandles_REF->[$CurProc]} $CurrentContainerQuery;
  }

  if ($EchoOn) {
    printToSqlplus("additionalInitStmts", $FileHandles_REF->[$CurProc], 
                   qq#SET ECHO ON#, "\n", 
                   $DebugOn);
  }

  return;
}

sub find_in_path($$) {
  my ($exec, $windows) = @_;
  my @pathext = ('');

  # for Windows, look for $exec.<one of extensions (e.g. .exe or .bat)>
  if ($windows) {
    if ( $ENV{PATHEXT} ) {
      push @pathext, split ';', $ENV{PATHEXT};
    } else {
      # if PATHEXT is not set use one of .com, .exe or .bat
      push @pathext, qw{.com .exe .bat};
    }
  }

  my @path = File::Spec->path;
  if ($windows) {
    unshift @path, File::Spec->curdir;
  }
 
  foreach my $base ( map { File::Spec->catfile($_, $exec) } @path ) {
    for my $ext ( @pathext ) {
      my $file = $base.$ext;
 
      # We don't want dirs (as they are -x)
      next if -d $file;
      
      if (
          # Executable, normal case
          -x _
          or (
              (
               $windows
               and
               grep {$file =~ /$_\z/i} @pathext[1..$#pathext])
              # DOSish systems don't pass -x on
              # non-exe/bat/com files. so we check -e.
              # However, we don't want to pass -e on files
              # that aren't in PATHEXT, like README.
              and -e _)
         ) {
        return 1;
      }
    }
  }

  return undef;
}

#
# log_msg - add supplied string to both STDERR and CATCONOUT
#
sub log_msg($) {
  my ($LogMsg) = @_;
  
  print STDERR $LogMsg;
  print CATCONOUT $LogMsg;
}

#
# log_script_execution - produce a message indicating script or statement about
#                        to be executed as well as the name of a Container 
#                        (if applicable) in which it is being executed
#
sub log_script_execution (\$$$) {
  my ($FilePath, $ConName, $ProcIdx) = @_;

  my $msg;
  
  $msg = "executing".(($$FilePath =~ /^@/) ? " " : " statement ");
  $msg .= "\"".$$FilePath."\" in ".($ConName ? "container ".$ConName : "non-CDB");
  
  log_msg("catconExec_int: ".$msg." using process $ProcIdx\n");
}

# subroutines which may be invoked by callers outside this file and variables 
# that need to persist across such invocations
{
  # have all the vars that need to persist across calls been initialized?
  # computed
  my $catcon_InitDone;
  
  # name of the directory for sqlplus script(s), as supplied by the caller
  my $catcon_SrcDir;

  # name of the directory for log file(s), as supplied by the caller
  my $catcon_LogDir;

  # base for paths of log files
  my $catcon_LogFilePathBase;

  # number of processes which will be used to run sqlplus script(s) or SQL 
  # statement(s) using this instance of catcon.pl, as supplied by the caller; 
  my $catcon_NumProcesses;

  # indicator of whether echo should be turned on while running sqlplus 
  # script(s) or SQL statement(s), as supplied by the caller
  my $catcon_EchoOn;

  # indicator of whether output of running scripts should be spooled into 
  # Container- and script-specific spool files, as supplied by the caller
  my $catcon_SpoolOn;

  # indicator of whether debugging info should be generated while executing 
  # various subroutines in this block
  my $catcon_DebugOn;

  # an indicator of whether we are being invoked from a GUI tool which on 
  # Windows means that the passwords and hidden parameters need not be hidden
  my $catcon_GUI;

  # indicator of whether the caller wants us to check whether scripts end 
  # without committing the current transaction
  my $catcon_UncommittedXactCheck;

  # indicator of whether we were instructed to run scripts in ALL PDBs and 
  # then in Root
  my $catcon_PdbsThenRoot;

  # indicator of whether non-existent and closed PDBs should be ignored when 
  # constructing a list of Containers against which to run scripts
  my $catcon_IgnoreInaccessiblePDBs;

  my $catcon_EZConnect;

  # an indicator of whether we were told that the DB has been shut down
  my $catcon_DbClosed;

  # connect string used when running SQL for internal statements: this
  # should be done as sys
  # computed
  my $catcon_InternalConnectString;        

  # connect string used when running sqlplus script(s) or SQL statement(s) in
  # the context of the user passed in.
  # computed
  my $catcon_UserConnectString;        

  # password used when connecting to the database to run sqlplus script(s) or 
  # SQL statement(s)
  my $catcon_UserPass;

  # names of ALL containers of a CDB if connected to one; empty if connected 
  # to a non-CDB;
  # computed
  my @catcon_AllContainers;

  # indicators (Y or N) of whether a corresponding Container in 
  # @catcon_AllContainers is open
  my @catcon_IsConOpen;

  # empty if connected to a non-CDB; same as @catcon_AllContainers if the 
  # user did not specify -c or -C flag, otherwise, consists of 
  # names of Containers explicitly included (-c) or not explicitly 
  # excluded (-C);
  #
  # NOTE:
  #   by default, catconExec will run scripts/statements in all Containers 
  #   whose names are found in catcon_Containers; however, this can be 
  #   modified by passing to catconExec a list of Containers to include or 
  #   exclude during the current invocation 
  # computed
  my @catcon_Containers;

  # environment variable containing EZConnect Strings for instances to be 
  # used to run scripts
  my $EZCONNECT_ENV_TAG = "CATCONEZCONNECT";

  # name of the Root if operating on a Consolidated DB
  my $catcon_Root;

  # array of file handle references; 
  my @catcon_FileHandles;

  # array of process ids
  my @catcon_ProcIds;

  # are we running on Windows?
  my $catcon_Windows;
  my $catcon_DoneCmd;

  # string introducing an argument to SQL*PLus scripts which will be supplied 
  # using clear text
  my $catcon_RegularArgDelim;

  # string introducing an argument to SQL*PLus scripts which will have to be 
  # specified by the user at run-time
  my $catcon_SecretArgDelim;

  # if strings used to introduce "regular" as well as secret arguments are 
  # specified and one is a prefix of the other and we encounter a string 
  # that could be either a regular or a secret argument, we will resolve in 
  # favor of the longer string.  
  # $catcon_ArgToPick will be used to determine how to resolve such conflicts, 
  # should they occur; it will remain set to 0 if such conflicts cannot occur 
  # (i.e. if both strings are not specified or if neither is a prefix of the 
  # other)

  # pick regular argument in the event of conflict
  my $catcon_PickRegularArg;
  # pick secret argument in the event of conflict
  my $catcon_PickSecretArg;

  my $catcon_ArgToPick = 0;

  # reference to an array of statements which will be executed in every 
  # process before it is asked to run the first script
  my $catcon_PerProcInitStmts;

  # reference to an array of statements which will be executed in every 
  # process after it finishes runing the last script
  my $catcon_PerProcEndStmts;

  # if defined, will contain name of error logging table
  my $catcon_ErrLogging;

  # if set, SET ERRORLOGGING ON IDENTIFIER statement will NOT be issued
  my $catcon_NoErrLogIdent;

  # $catcon_RevertSeedPdbMode will be used to store the mode in which 
  # PDB$SEED was open before being reopened in catconExec in the mode 
  # specified by the caller.  It will act as a reminder of whether PDB$SEED 
  # needs to be reopened as a part of wrapup (or interrupt handler)
  #
  # NOTE: if PDB$SEED was not opened in desired mode (as indicated by 
  #       $catcon_SeedMode) when catconExec() discovers 
  #       for the first time that it needs to run some scripts or statements 
  #       against it, it will call reset_seed_pdb_mode() which will close it 
  #       and then reopen in desired mode.  From that point on, PDB$SEED 
  #       will remain in that mode until it gets reset to its original mode as 
  #       a part of catconWrapUp().  
  #
  #       It is IMPOTANT that restoring PDB$SEED's mode happens AFTER all 
  #       processes opened in catconInit() have been killed because otherwise 
  #       ALTER PDB CLOSE IMMEDIATE issued by reset_seed_pdb_mode() will 
  #       cause any of the proceses which happen to be connected to PDB$SEED
  #       to become unusable (they will be disconnected from the database 
  #       and any statements sent to them will fail.)  
  #       As a side note, before we fixed bug 13072385, reset_seed_pdb_mode() 
  #       used to issue ALTER PDB CLOSE (without IMMEDIATE), which hung if 
  #       any process was connected to PDB$SEED
  #
  my $catcon_RevertSeedPdbMode;

  # mode in which PDB$SEED should be open while running scripts:
  #   - 0 - leave it alone (caller responsible for opening it in the correct 
  #         mode before calling catconExec and reopening it in READ ONLY 
  #         mode before exiting)
  #   - 1 - PDB$SEED must be open READ WRITE; if it is not, catconExec will 
  #         reopen it READ WRITE and catconWrapup will restore its mode 
  #   - 2 - PDB$SEED must be open READ ONLY; if it is not, catconExec will 
  #         reopen it READ ONLY and catconWrapup will restore its mode 
  #   - 3 - PDB$SEED must be open UPGRADE; if it is not open MIGRATE 
  #         (currently we do not distinguish between UPGRADE and DOWNGRADE), 
  #         catconExec will reopen it UPGRADE and catconWrapup will restore 
  #         its mode
  #   - 4 - PDB$SEED must be open DOWNGRADE; if it is not open MIGRATE 
  #         (currently we do not distinguish between UPGRADE and DOWNGRADE), 
  #         catconExec will reopen it UPGRADE and catconWrapup will restore 
  #         its mode
  my $CATCON_SEED_UNCHANGED  = 0;
  my $CATCON_SEED_READ_WRITE = 1;
  my $CATCON_SEED_READ_ONLY  = 2;
  my $CATCON_SEED_UPGRADE    = 3;
  my $CATCON_SEED_DOWNGRADE  = 4;
  my $catcon_SeedMode = $CATCON_SEED_UNCHANGED;

  # environment variable containing user password
  my $USER_PASSWD_ENV_TAG = "CATCONUSERPASSWD";

  # environment variable containing internal password
  my $INTERNAL_PASSWD_ENV_TAG = "CATCONINTERNALPASSWD";

  # a globale variable indicates whether catcon is called by cdb_sqlexec
  # If true then the _oracle_script will not be set and it will not execute 
  # in Root or PDB$SEED
  my $catcon_UserScript = 0;

  # this hash will be used to save signal handlers in effect before catconInit
  # was invoked so that they can be restored at the end of catconWrapup
  my %catcon_SaveSig;

  #
  # catconInit - initialize and validate catcon static vars and start 
  #              SQL*Plus processes
  #
  # Parameters:
  #   - user name, optionally with password, supplied by the caller; may be 
  #     undefined (default / AS SYSDBA)
  #   - internal user name, optionally with password; may be 
  #     undefined (default / AS SYSDBA)
  #   - directory containing sqlplus script(s) to be run; may be undefined
  #   - directory to use for spool and log files; may be undefined
  #   - base for spool log file name; must be specified
  #
  #   - container(s) (names separated by one or more spaces) in which to run 
  #     sqlplus script(s) and SQL statement(s) (i.e. skip containers not 
  #     referenced in this list)
  #   - container(s) (names separated by one or more spaces) in which NOT to 
  #     run sqlplus script(s) and SQL statement(s) (i.e. skip containers
  #     referenced in this list)
  #     NOTE: the above 2 args are mutually exclusive; if neither is defined, 
  #       sqlplus script(s) and SQL statement(s) will be run in the 
  #       non-Consolidated Database or all Containers of a Consolidated 
  #       Database
  #
  #   - number of processes to be used to run sqlplus script(s) and SQL 
  #     statement(s);  may be undefined (default value will be computed based 
  #     on host's hardware characteristics, number of concurrent sessions, 
  #     and whether the subroutine is getting invoked interactively)
  #   - external degree of parallelism, i.e. if more than one script using 
  #     catcon will be invoked simultaneously on a given host, this parameter 
  #     should contain a number of such simultaneous invocations; 
  #     may be undefined;
  #     will be used to determine number of processes to start;
  #     this parameter MUST be undefined or set to 0 if the preceding 
  #     parameter (number of processes) is non-zero
  #   - indicator of whether echo should be set ON while running script(s) 
  #     and SQL statement(s); defaults to FALSE
  #   - indicator of whether output of running scripts should be spooled in 
  #     files stored in the same directory as that used for log files and 
  #     whose name will be constructed as follows:
  #       <log-file-name-base>_<script_name_without_extension>_[<container_name_if_any>].<default_extension>
  #   - reference to a string used to introduce an argument to SQL*Plus 
  #     scripts which will be supplied using clear text (i.e. not require 
  #     user to input them at run-time)
  #     NOTE: variable referenced by this parameter will default to "--p" 
  #           if not supplied by the caller
  #   - reference to a string used to introduce an argument (such as a 
  #     password) to SQL*Plus scripts which will require user to input them 
  #     at run-time
  #     NOTE: variable referenced by this parameter will default to "--P" 
  #           if not supplied by the caller
  #   - indicator of whether ERRORLOGGING should be set ON while running 
  #     script(s) and SQL statement(s); defaults to FALSE; if value is ON, 
  #     default error logging table (SPERRORLOG) will be used, otherwise 
  #     specified value will be treated as the name of the error logging 
  #     table which should have been pre-created in every Container
  #   - indicator of whether the caller has instructed us to NOT set 
  #     Errorlogging Identifier
  #   - reference to an array of statements which will be executed in every 
  #     process before it is asked to run the first script; if operating on a 
  #     CDB, statements will be executed against the Root; statements may 
  #     contain 0 or more instances of string %proc which will be replaced 
  #     with process number
  #   - reference to an array of statements which will be executed in every 
  #     process after it finishes runing the last script; if operating on a 
  #     CDB, statements will be executed against the Root; statements may 
  #     contain 0 or more instances of string %proc which will be replaced 
  #     with process number
  #   - indicator of the mode in which PDB$SEED needs to be open before 
  #     running scripts (see descripotion of catcon_SeedMode for details)
  #   - indicator of whether to produce debugging messages; defaults to FALSE
  #   - an indicator of whether we are being called from a GUI tool which on 
  #     Windows means that the passwords and hidden parameters need not be 
  #     hidden
  #   - an indicator of whether it is called from cdb_sqlexec.pl. Will use
  #     this parameter to set $catcon_UserScript
  #


  sub catconInit ($$$$$$$$$$$\$\$$$\@\@$$$$) {
    my ($User, $InternalUser, $SrcDir, $LogDir, $LogBase, 
        $ConNamesIncl, $ConNamesExcl, 
        $NumProcesses, $ExtParallelDegree,
        $EchoOn, $SpoolOn, $RegularArgDelim_ref, $SecretArgDelim_ref, 
        $ErrLogging, $NoErrLogIdent, $PerProcInitStmts, 
        $PerProcEndStmts, $SeedMode, $DebugOn, $GUI, $UserScript) = @_;

    if ($catcon_InitDone) {
      # if catconInit has already been called, CATCONOUT must be available
      # send it to STDERR as well to increase likelyhood of it being noticed
      log_msg <<msg;
catconInit: script execution state has already been initialized; call 
    catconWrapUp before invoking catconInit
msg
      return 1;
    }

    # make STDERR "hot" so diagnostic and error message output does not get 
    # buffered
    select((select(STDERR), $|=1)[0]);

    # NOTE:
    #   log directory and base for log file names is handled first since we 
    #    need them to open the catcon output file

    # if directory for log file(s) has been specified, verify that it exists 
    # and is writable
    if (!valid_log_dir($catcon_LogDir = $LogDir)) {
      # use STDERR because CATCONOUT is yet to be opened
      print STDERR "catconInit: Unexpected error returned by valid_log_dir\n";
      return 1;
    }

    # determine base for log file names
    # the same base will be used for spool file names if $SpoolOn is true
    $catcon_LogFilePathBase = 
      get_log_file_base_path($catcon_LogDir, $LogBase, $DebugOn);

    # open CATCONOUT.  If opened successfully, all output generated by catcon 
    # should be written to CATCONOUT to ensure that we can find it after 
    # running an lrg involving catcon on the farm or through some other Perl 
    # script
    if (!open(CATCONOUT, ">>", $catcon_LogFilePathBase."_catcon_".$$.".lst")) {
      print STDERR "catconInit: unable to open ".$catcon_LogFilePathBase."_catcon_".$$.".lst as CATCONOUT\n";
      return 1;
    }

    # last message which will be seen only on the console
    print STDERR "catcon: ALL catcon-related output will be written to ".$catcon_LogFilePathBase."_catcon_".$$.".lst\n";

    # make CATCONOUT "hot" so diagnostic and error message output does not get 
    # buffered
    select((select(CATCONOUT), $|=1)[0]);

    log_msg("catcon: See ${catcon_LogFilePathBase}*.log files for output generated by scripts\n");
    log_msg("catcon: See ${catcon_LogFilePathBase}_*.lst files for spool files, if any\n");

    my $ts = TimeStamp();

    # do not dump the banner to STDERR
    print CATCONOUT <<msg;
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

\tcatconInit: start logging catcon output at $ts

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

msg
    if ($DebugOn) {
      log_msg("catconInit: base for log and spool file names = $catcon_LogFilePathBase\n");
    }

    # save DebugOn indicator in a variable that will persist across calls
    if ($catcon_DebugOn = $DebugOn) {
      my $ts = TimeStamp();

      log_msg <<catconInit_DEBUG;
  running catconInit(User              = $User, 
                     InternalUser      = $InternalUser,
                     SrcDir            = $SrcDir, 
                     LogDir            = $LogDir, 
                     LogBase           = $LogBase,
                     ConNamesIncl      = $ConNamesIncl, 
                     ConNamesExcl      = $ConNamesExcl, 
                     NumProcesses      = $NumProcesses,
                     ExtParallelDegree = $ExtParallelDegree,
                     EchoOn            = $EchoOn, 
                     SpoolOn           = $SpoolOn,
                     RegularArgDelim   = $$RegularArgDelim_ref,
                     SecretArgDelim    = $$SecretArgDelim_ref,
                     ErrLogging        = $ErrLogging,
                     NoErrLogIdent     = $NoErrLogIdent,
                     SeedMode          = $SeedMode,
                     Debug             = $DebugOn,
                     GUI               = $GUI,
                     UserScript        = $UserScript)\t\t($ts)

catconInit_DEBUG
    }

    # remember whether catconInit is called by cdb_sqlexec.pl
    $catcon_UserScript = $UserScript;

    my $UnixDoneCmd = "\nhost sqlplus -v >";
    my $WindowsDoneCmd = "\nhost sqlplus/nolog -v >";

    # will contain status of the instance (v$instance.status)
    my $instanceStatus;

    # will contain an indicator of whether a DB is a CDB (v$database.cdb)
    my $IsCDB;

    # base for log file names must be supplied
    if (!$LogBase) {
      log_msg("catconInit: Base for log file names must be supplied");
      return 1;
    }

    # if caller indicated that we are to start a negative number of processes,
    # it is meaningless, so replace it with 0
    if ($NumProcesses < 0) {
      $NumProcesses = 0;
    }

    if ($NumProcesses && $ExtParallelDegree) {
      log_msg <<msg;
catconInit: you may not specify both the number of processes ($NumProcesses) 
    and the external degree of parallelism ($ExtParallelDegree)
msg
      return 1;
    }

    # save EchoOn indicator in a variable that will persist across calls
    $catcon_EchoOn = $EchoOn;

    # save SpoolOn indicator in a variable that will persist across calls
    $catcon_SpoolOn = $SpoolOn;

    # initialize indicators used to determine how to resolve conflicts 
    # between regular and secret argument delimiters
    $catcon_PickRegularArg = 1; 
    $catcon_PickSecretArg = 2;  

    # 
    # set up signal handler in case SQL process crashes
    # before it completes its work
    #
    # Bug 18488530: add a handler for SIGINT
    # Bug 18548396: add handlers for SIGTERM and SIGQUIT
    #
    # save original handlers for SIGCHLD, SIGINT, SIGTERM, and SIGQUIT before 
    # resetting them
    if (exists $SIG{CHLD}) {
      $catcon_SaveSig{CHLD} = $SIG{CHLD};
    }

    if (exists $SIG{INT}) {
      $catcon_SaveSig{INT}  = $SIG{INT};
    }

    if (exists $SIG{TERM}) {
      $catcon_SaveSig{TERM} = $SIG{TERM};
    }

    if (exists $SIG{QUIT}) {
      $catcon_SaveSig{QUIT} = $SIG{QUIT};
    }

    $SIG{CHLD} = \&catcon_HandleSigchld;
    $SIG{INT} = \&catcon_HandleSigINT;
    $SIG{TERM} = \&catcon_HandleSigTERM;
    $SIG{QUIT} = \&catcon_HandleSigQUIT;

    # figure out if we are running under Windows and set $catcon_DoneCmd
    # accordingly

    $catcon_DoneCmd = ($catcon_Windows = ($OSNAME =~ /^MSWin/)) ? $WindowsDoneCmd : $UnixDoneCmd;

    if ($catcon_DebugOn) {
       log_msg("catconInit: running on $OSNAME; DoneCmd = $catcon_DoneCmd\n");
    }

    #
    # unset TWO_TASK  or LOCAL if it happens to be set to ensure that CONNECT
    # which does not specify a service results in a connection to the Root
    #

    if($catcon_Windows) {
      if ($ENV{LOCAL}) {
         if ($catcon_DebugOn) {
            log_msg("catconInit: LOCAL was set to $ENV{LOCAL} - unsetting it\n");
         }

         delete $ENV{LOCAL};
      } else {
        if ($catcon_DebugOn) {
            log_msg("catconInit: LOCAL was not set, so there is not need to unset it\n");
        }
      }
    }

    if ($ENV{TWO_TASK}) {
      if ($catcon_DebugOn) {
        log_msg("catconInit: TWO_TASK was set to $ENV{TWO_TASK} - unsetting it\n");
      }

      delete $ENV{TWO_TASK};
    } else {
      if ($catcon_DebugOn) {
        log_msg("catconInit: TWO_TASK was not set, so there is no need to unset it\n");
      }
    }

    if (!$$RegularArgDelim_ref) {
      $$RegularArgDelim_ref = '--p';

      if ($catcon_DebugOn) {
        log_msg("catconInit: regular argument delimiter was not specified - defaulting to $$RegularArgDelim_ref\n");
      }
    }

    if (!$$SecretArgDelim_ref) {
      $$SecretArgDelim_ref = '--P';

      if ($catcon_DebugOn) {
        log_msg("catconInit: secret argument delimiter was not specified - defaulting to $$SecretArgDelim_ref\n");
      }
    }

    # save strings used to introduce arguments to SQL*Plus scripts
    if ($$RegularArgDelim_ref ne "--p" || $$SecretArgDelim_ref ne "--P") {

      if ($catcon_DebugOn) {
        log_msg("catconInit: either regular ($$RegularArgDelim_ref) or secret ($$SecretArgDelim_ref) argument delimters were explicitly specified\n");
      }

      # if both are specified, they must not be the same
      if ($$RegularArgDelim_ref eq $$SecretArgDelim_ref) {
        log_msg <<msg;
catconInit: string introducing regular script argument ($$RegularArgDelim_ref) 
    may not be \nthe same as a string introducing a secret script 
    argument ($$SecretArgDelim_ref)
msg
        return 1;
      }

      # if one of the strings is a prefix of the other, remember which one to 
      # pick if an argument supplied by the user may be either
      if ($$RegularArgDelim_ref =~ /^$$SecretArgDelim_ref/) {
        $catcon_ArgToPick = $catcon_PickRegularArg;

        if ($catcon_DebugOn) {
          log_msg <<msg;
catconInit: secret argument delimiter ($$SecretArgDelim_ref) is a prefix of 
    regular argument delimiter ($$RegularArgDelim_ref); if in doubt, 
    will pick regular
msg
        }
      } elsif ($$SecretArgDelim_ref =~ /^$$RegularArgDelim_ref/) {
        $catcon_ArgToPick = $catcon_PickSecretArg;

        if ($catcon_DebugOn) {
          log_msg <<msg;
catconInit: regular argument delimiter ($$RegularArgDelim_ref) is a prefix of 
    secret argument delimiter ($$SecretArgDelim_ref); if in doubt, will 
    pick secret
msg
        }
      }
    }

    # argument delimiters may not start with @
    if ($$RegularArgDelim_ref =~ /^@/) {
      log_msg("catconInit: regular argument delimiter ($$RegularArgDelim_ref) begins with @ which is not allowed\n");
      return 1;
    }

    if ($$SecretArgDelim_ref =~ /^@/) {
      log_msg("catconInit: secret argument delimiter ($$SecretArgDelim_ref) begins with @ which is not allowed\n");
      return 1;
    }

    $catcon_RegularArgDelim = $$RegularArgDelim_ref;
    $catcon_SecretArgDelim = $$SecretArgDelim_ref;

    # remember whether ERRORLOGGING should be set 
    $catcon_ErrLogging = $ErrLogging;

    # remember whether the caller has instructed us to NOT issue 
    # SET ERRORLOGGING ON IDENTIFIER ...
    $catcon_NoErrLogIdent = $NoErrLogIdent;

    # saves references to arrays of statements which should be executed 
    # before using sending a script to a process for the first time and 
    # after a process finishes executing the last script assigned to it
    # in the course of running catconExec()
    $catcon_PerProcInitStmts = $PerProcInitStmts;
    $catcon_PerProcEndStmts = $PerProcEndStmts;

    # process EZConnect strings, if any

    my @ezConnStrings;

    if ($catcon_EZConnect || $ENV{$EZCONNECT_ENV_TAG}) {
      # store a list of EZConnect strings in @ezConnStrings for use when 
      # determining which instance will be picked for running scriptrs
      if ($catcon_EZConnect) {
        # use a list of EZConnect strings supplied by the caller
        @ezConnStrings = split(/  */,$catcon_EZConnect);
      
        # $catcon_EZConnect should have contained at least 1 string
        if ($#ezConnStrings < 0) {
          log_msg("catconInit: EZConnect string list must contain at least 1 string\n");
          return 1;
        }

        if ($catcon_DebugOn) {
          log_msg("catconInit: EZConnect strings supplied by the user:\n\t");
          log_msg(join("\n\t", @ezConnStrings)."\n");
        }
      } else {
        @ezConnStrings = split(/  */, $ENV{$EZCONNECT_ENV_TAG});
          
        # $ENV{$EZCONNECT_ENV_TAG} should have contained at least 1 string
        if ($#ezConnStrings < 0) {
          log_msg("catconInit: $EZCONNECT_ENV_TAG environment variable must contain at least 1 string\n");
          return 1;
        }

        if ($catcon_DebugOn) {
          log_msg("catconInit: EZConnect strings found in $EZCONNECT_ENV_TAG env var");
          log_msg(join("\n\t", @ezConnStrings));
        }
      }
    } else {
      # having $ezConnStrings[0] eq "" serves as an indicator that we will
      # use the default instance
      push @ezConnStrings, "";

      if ($catcon_DebugOn) {
        log_msg("catconInit: no EZConnect strings supplied - using default instance\n");
      }
    }

    # construct a user connect string and store it as well as the password 
    # (so catconUserPass() can return it), if any, in variables which will 
    # persist across calls.  
    #
    # NOTE: If ezConnStrings does not represent the default instance, 
    #       $catcon_UserConnectString will contain a placeholder (@%s) for 
    #       the EZConnect string corresponding to the instance which we will 
    #       eventually pick.
    ($catcon_UserConnectString, $catcon_UserPass) = 
      get_connect_string($User, !($catcon_Windows && $GUI), 
                         $ENV{$USER_PASSWD_ENV_TAG}, 
                         $ezConnStrings[0] ne "");

    if (!$catcon_UserConnectString) {
      # NOTE: $catcon_UserConnectString may be set to undef
      #       if the caller has not supplied a value 
      #       for $USER (which would lead get_connect_string() to return 
      #       "/ AS SYSDBA" as the connect string while specifying instances 
      #       on which scripts are to be run (by means of passing one or more 
      #       EZConnect strings)
      log_msg("catconInit: Empty user connect string returned by get_connect_string\n");
      return 1;
    }

    if ($catcon_DebugOn) {
      log_msg("catconInit: User Connect String = $catcon_UserConnectString\n");

      # bug 18591655: if user password was not supplied, display 
      #   appropriate message
      log_msg("catconInit: User password ".($catcon_UserPass ? "= ".$catcon_UserPass : "not specified")."\n");
    }

    # Bug 18020158: generating internal connect string is complicated by the 
    # fact that catctl does not accept it as a parameter.  There are two 
    # distinct cases to consider:
    # - the caller supplied <internal user> and possibly <internal password> 
    #   inside $InternalUser:
    #   - if both internal user and password were supplied, use them
    #   - otherwise, if <internal password> was not supplied, we will try to 
    #     obtain it from $ENV{$INTERNAL_PASSWD_ENV_TAG}, and failing that, 
    #     prompt the user to enter it
    # - otherwise:
    #   - recycle user connect string as the internal connect string
    if ($InternalUser) {
      my $InternalPass; # used to accept a value returned by get_connect_string

      # NOTE: If ezConnStrings does not represent the default instance, 
      #       $catcon_InternalConnectString will contain a placeholder (@%s) 
      #       for the EZConnect string corresponding to the instance which 
      #       we will eventually pick.
      ($catcon_InternalConnectString, $InternalPass) = 
        get_connect_string($InternalUser, !($catcon_Windows && $GUI), 
                           $ENV{$INTERNAL_PASSWD_ENV_TAG}, 
                           $ezConnStrings[0] ne "");

      if (!$catcon_InternalConnectString) {
        log_msg("catconInit: Empty internal connect string returned by get_connect_string\n");
        return 1;
      }

      if ($catcon_DebugOn) {
        log_msg("catconInit: Internal Connect String = $catcon_InternalConnectString\n");

        # bug 18591655: if internal password was not supplied, display 
        #   appropriate message
        log_msg("catconInit: Internal password ".($InternalPass ? "= ".$InternalPass : "not specified")."\n");
      }
    } else {
      $catcon_InternalConnectString = $catcon_UserConnectString;

      if ($catcon_DebugOn) {
        log_msg("catconInit: setting Internal Connect String to User Connect String\n");
      }
    }

    if (!valid_src_dir($catcon_SrcDir = $SrcDir)) {
      log_msg("catconInit: Unexpected error returned by valid_src_dir\n");
      return 1;
    }

    if ($catcon_DebugOn) {
      if ($catcon_SrcDir) {
        log_msg("catconInit: source file directory = $catcon_SrcDir\n");
      } else {
        log_msg("catconInit: no source file directory was specified\n");
      }
    }

    # Bug 17810688: make sure sqlplus is in $PATH
    if (!find_in_path("sqlplus", $catcon_Windows)) {
      log_msg("catconInit: sqlplus not in PATH.\n");
      return 1;
    }

    # For each EZConnect String (or "" for default instance) stored in 
    # @ezConnStrings, connect to the instances represented by the string and 
    # - verify that the database is open on that instance, 
    # - if processing the first EZConnect string 
    #   - determine whether the database is a CDB 
    # - if @ezConnStrings contains more than one string, 
    #   - verify that the current EZConnect string takes us to the same DB 
    #     as the preceding one
    # - if the EZConnect string takes us to a CDB, 
    #   - verify that it takes us to the CDB's Root
    #   - if we are yet to determine which Instance to use
    #     - determine which Containers are open on this Instance
    #     - if there is only one EZConnect string (which may or may not  
    #       represent the default instance)
    #       - determine the set of Containers against which scripts will be 
    #         run, honoring the caller's directive regarding reporting of 
    #         errors due to some PDBs not being accessible
    #       - remember that this is the instance which we will be using
    #     - else
    #       - if processing the first EZConnect string,
    #         - determine the set of Containers against which scripts will be 
    #           run WITHOUT taking into consideration whether these Containers 
    #           are open on the instance corresponding to this EZConnect string
    #  
    #           the reason we are choosing to ignore open mode of Containers on
    #           this Instance is because we do not want to report an error if 
    #           some Container is not open on this instance - all desired 
    #           Containers may very well be open on some other instance - we 
    #           just need a list of Containers after taking into account the 
    #           inclusive or exclusive Container list (if any) + we DO want to 
    #           report an error if either of these lists included an unknown 
    #           Container and the caller has NOT instructed us to ignore such 
    #           Containers
    #       - determine if ALL Containers against which scripts need to be run 
    #         are open on this Instance
    #       - if all desired Containers are open on this Instance
    #         - remember that this is the instance which we will be using
    #     - if we finally determined the instance which will be using, 
    #       determine how many processes may be started on it
    # - else (i.e. not connecting to a CDB)
    #   - determine the number of processes that can be started on this 
    #     instance, and if it is greater than that for all preceding 
    #     instances (if any), remember that this is the instance we will 
    #     want to use (unless we find an instance on which an even greater 
    #     number of processes can be started)
    # - endif

    # set to 0 in case we were called to run scripts against a non-CDB and need
    # to look for an instance that can support the greatest number of processes
    $catcon_NumProcesses = 0;

    # If considering more than one instance, $dbid will be used to verify 
    # that all instances are connected to the same database
    my $dbid;

    # prefix of "done" file name
    #
    # Bug 18011217: append _catcon_$$ (process id) to $catcon_LogFilePathBase
    # to avoid conflicts with other catcon processes running on the same host
    my $doneFileNamePrefix = 
      done_file_name_prefix($catcon_LogFilePathBase, $$);

    # EZConnect string corresponding to the instance which we picked to run 
    # scripts. If still not set when we exit the loop, report an error
    my $ezConnToUse;

    for (my $currInst = 0; $currInst <= $#ezConnStrings; $currInst++) {
      my $EZConnect = $ezConnStrings[$currInst];

      if ($catcon_DebugOn) {
        log_msg("catconInit: considering EZConnect string ".$EZConnect."\n");
      }

      # construct a connect string which will be used to obtain information 
      # about the current instance, the database which is running on it, etc.
      my $connectString = 
        build_connect_string($catcon_InternalConnectString, $EZConnect, 
                             $catcon_DebugOn);

      # build_connect_string may return undef, in which case we will return 1 
      # (to indicate that an error was encountered)
      if (!$connectString) {
        log_msg("catconInit: unexpected error encountered in build_connect_string\n");
        return 1;
      }

      # (13704981) verify that the instance is open

      if ($catcon_DebugOn) {
        log_msg("catconInit: call get_instance_status\n");
      }

      # status and name of the instance (v$instance.status and 
      # v$instance.instance_name)
      my ($instanceStatus, $instanceName) = 
        get_instance_status_and_name($connectString, $catcon_DoneCmd, 
                            $doneFileNamePrefix, $catcon_DebugOn);

      if (!$instanceStatus) {
        log_msg("catconInit: database is not open");
        if ($EZConnect eq "") {
          # default instance
          log_msg(" on the default instance\n");
        } else {
          log_msg(" on the instance with EZConnect string = ".$EZConnect."\n");
        }
        return 1;
      } elsif ($instanceStatus !~ /^OPEN/) {
        log_msg("catconInit: database is not open");
        if ($EZConnect eq "") {
          # default instance
          log_msg(" on the default instance (".$instanceName.")\n");
        } else {
          log_msg(" on instance ".$instanceName." with EZConnect string = ".$EZConnect."\n");
        }
        return 1;
      }

      if ($catcon_DebugOn) {
        log_msg("catconInit: instance $instanceName (EZConnect = ".$EZConnect.") has status $instanceStatus\n");
      }

      # determine whether a DB is a CDB.  Do it only once (before obtaining 
      # database' DBID)
      if (!$dbid) {
        if ($catcon_DebugOn) {
          log_msg("catconInit: processing first instance - call get_CDB_indicator\n");
        }

        $IsCDB = 
          get_CDB_indicator($connectString, $catcon_DoneCmd, 
                            $doneFileNamePrefix, $catcon_DebugOn);

        if ($catcon_DebugOn) {
          log_msg("catconInit: database is ".(($IsCDB eq 'NO') ? "non-" : "")."Consolidated\n");
        }
      }

      if ($catcon_DebugOn) {
        log_msg("catconInit: call get_dbid\n");
      }

      # obtain DBID of the database to which the current instance is 
      # connected and compare id to DBID of preceding instances, if any
      my $currDBID = 
        get_dbid($connectString, $catcon_DoneCmd, 
                 $doneFileNamePrefix, $catcon_DebugOn);

      if (!$dbid) {
        # first EZ Connect string (or "", representing the default instance)
        $dbid = $currDBID;

        if ($catcon_DebugOn) {
          log_msg("catconInit: DBID = $dbid\n");
        }
      } elsif ($dbid ne $currDBID) {
        # at least 2 EZConnect strings were specified and, not all of them 
        # correspond to the same database
        log_msg <<msg;
catconInit: instance $instanceName (EZConnect string = $EZConnect)
    is connected to a database with DBID = $currDBID which is different
    from DBID ($dbid) of the database to which preceding instances are 
    connected
msg
        return 1;
      }

      # CDB-specific stuff (see above)
      if ($IsCDB eq "YES") {
        if ($catcon_DebugOn) {
          log_msg("catconInit: CDB-specific processing\n");
        }

        # make sure that the current EZConnect string will take us to the Root.
        if ($catcon_DebugOn) {
          log_msg("catconInit: call get_con_id to verify that the current EZConnect string will take us to the Root\n");
        }

        my $conId = get_con_id($connectString, $catcon_DoneCmd, 
                               $doneFileNamePrefix, $catcon_DebugOn);
        if ($conId != 1) {
          # EZConnect string is not taking us to a CDB's Root
          log_msg <<msg;
catconInit: Instance $instanceName (EZConnect string = $EZConnect)
    points to a Container with CON_ID of $conId instead of the Root
msg
          return 1;
        }

        # the rest of this block has to do with finding an Instance on which 
        # all desired Containers are open.  If such Instance has already been 
        # located, process the next EZConnect string (if any)
        if (defined $ezConnToUse) {
          if ($catcon_DebugOn) {
            log_msg <<msg;
catconInit: skip to the next EZConnect string since we have already determined 
    which EZConnect string to use
msg
          }

          next;
        }

        # indicators of which Containers are open on this instance
        my @isConOpen;

        if (!@catcon_AllContainers) {

          # we are processing the first EZConnect string, so obtain names of 
          # ALL Containers in the CDB along with indicators of which of these 
          # Containers are open on this instance
          if ($catcon_DebugOn) {
            log_msg("catconInit: call get_con_names_and_open_modes to obtain container names and open indicators\n");
          }

          get_con_names_and_open_modes($connectString, $catcon_DoneCmd, 
                                       $doneFileNamePrefix, 
                                       @catcon_AllContainers, 
                                       @isConOpen, $catcon_DebugOn);

          # save name of the Root (it will always be in the 0-th element of 
          # @catcon_AllContainers because its contents are sorted by 
          # v$containers.con_id)
          $catcon_Root = $catcon_AllContainers[0];

          if ($catcon_UserScript) {
            # if running user- (rather than Oracle-) supplied scripts, discard 
            # the first 2 elements of @catcon_AllContainers (CDB$ROOT and 
            # PDB$SEED) and corresponding elements of @isConOpen
            #
            # if the CDB does not contain any other Containers, report an error
            # because there are no PDBs against which to run user scripts
            if ($#catcon_AllContainers < 2) {
              log_msg("catconInit: cannot run user scripts against a CDB which contains no user PDBs\n");
              return 1;
            }

            shift @catcon_AllContainers;
            shift @catcon_AllContainers;

            shift @isConOpen;
            shift @isConOpen;

            if ($catcon_DebugOn) {
              log_msg <<msg;
catconInit: running customer scripts, so purged the first 2 entries from 
    catcon_AllContainers and isConOpen
msg
            }
          }

          # - if a list of names of Containers in which to run (or not to run) 
          #   scripts has been specified, 
          #   - make sure both of them have NOT been specified (since they are 
          #     mutually exclusive) and
          # - if there is only one EZConnect string to consider
          #   - if an inclusive or exclusive Container list was specified,
          #     - verify that the desired Containers actually exist and are 
          #       open on this instance (taking into consideration caller's 
          #       request (if any) to ignore non-existent Containers mentioned 
          #       in the inclusive/exclusive list and Containers which are not 
          #       open on this instance)
          #   - else
          #     - verify that all Containers are open on this instance (taking 
          #       into consideration caller's request (if any) to ignore 
          #       Containers which are not open on this instance)
          if ($ConNamesIncl && $ConNamesExcl) {
            log_msg <<msg;
atconInit: both a list of Containers in which to run scripts and a list of 
    Containers in which NOT to run scripts were specified, which is disallowed
msg
            return 1;
          }

          if ($#ezConnStrings == 0) {
            if ($catcon_DebugOn) {
              log_msg("catconInit: only one instance to choose from; checking if all desired \n\tContainers are open on it\n");
            }

            if ($ConNamesExcl) {
              if (!(@catcon_Containers = 
                    validate_con_names($ConNamesExcl, 1, 
                                       @catcon_AllContainers, @isConOpen, 
                                       $catcon_IgnoreInaccessiblePDBs, 
                                       $catcon_DebugOn))) {
                log_msg("catconInit: Unexpected error returned by validate_con_names for exclusive Container list\n");
                return 1;
              }
            } elsif ($ConNamesIncl) {
              if (!(@catcon_Containers = 
                    validate_con_names($ConNamesIncl, 0, 
                                       @catcon_AllContainers, @isConOpen, 
                                       $catcon_IgnoreInaccessiblePDBs, 
                                       $catcon_DebugOn))) {
                log_msg("catconInit: Unexpected error returned by validate_con_names for inclusive Container list\n");
                return 1;
              } 
            } else {
              # we know that all desired Containers (i.e. Containers in 
              # @catcon_AllContainers) exist, so we just need to check if 
              # they are open

              my $AllConStr = join(" ", @catcon_AllContainers);

              if (!(@catcon_Containers = 
                    validate_con_names($AllConStr, 0, @catcon_AllContainers, 
                                       @isConOpen, 
                                       $catcon_IgnoreInaccessiblePDBs, 
                                       $catcon_DebugOn))) {
                log_msg("catconInit: Unexpected error returned by validate_con_names\n");
                return 1;
              } 
            }

            # there are no apparent obstacles to using this Instance. 
            # Remember that we found a satisfactory instance and copy a 
            # list of open Container indicators for future use
            $ezConnToUse = $EZConnect;
            @catcon_IsConOpen = @isConOpen;
            
            if ($catcon_DebugOn) {
              log_msg <<msg;
catconInit: instance $instanceName represented by the only EZConnect
    string has all desired Containers open on it
msg
            }
          }
        } else {
          # at least one EZConnect string has been processed, so we no longer
          # need to fetch names of all Containers.  We do, however, need to 
          # determine which of the Containers are open on this instance and 
          # populate @isConOpen accordingly

          if ($catcon_DebugOn) {
            log_msg("catconInit: Obtain open container indicators\n");
          }

          get_con_open_modes($connectString, $catcon_DoneCmd, 
                             $doneFileNamePrefix, @isConOpen, 
                             $catcon_UserScript, $catcon_DebugOn);
        }
        
        if ($catcon_DebugOn) {
          log_msg("catconInit: on instance ".$instanceName.", Container names and open indicators are {\n");

          for (my $curCon = 0; $curCon <= $#catcon_AllContainers; $curCon++) {
            log_msg("\t\t$catcon_AllContainers[$curCon] -- $isConOpen[$curCon]\n");
          }
          log_msg("catconInit: }\n");
        }

        if (defined $ezConnToUse) {
          # there is nothing more to do for this EZConnect string, and no 
          # more string to process (I could have called last earlier, but I 
          # did not want to duplicate code dumping Container names and modes)
          if ($catcon_DebugOn) {
            if ($ezConnToUse eq "") {
              log_msg <<msg;
catconInit: all desired Containers are open on the default instance 
    ($instanceName) - skip the remainder of EZConnect string processing
msg
            } else {
              log_msg <<msg;
catconInit: all desired Containers are open on instance ($instanceName)
    corresponding to the only eZConnect string - skip the remainder of 
    EZConnect string processing
msg
            }
          }

          last;
        }

        # if this is the first (of many) EZConnect strings, determine the list 
        # of desired Containers
        if ($currInst == 0) {
          # see the comment above the FOR-loop explaning why we want to confuse
          # validate_con_names into thinking that all Containers are open
          my @pretendAllAreOpen = ("Y") x @isConOpen;

          if ($catcon_DebugOn) {
            log_msg <<msg;
catconInit: processing the first of many EZConnect strings - determine names 
    of desired Containers
msg
          }

          if ($ConNamesExcl) {
            if (!(@catcon_Containers = 
                  validate_con_names($ConNamesExcl, 1, 
                                     @catcon_AllContainers, @pretendAllAreOpen,
                                     $catcon_IgnoreInaccessiblePDBs, 
                                     $catcon_DebugOn))) {
              log_msg("catconInit: Unexpected error returned by validate_con_names for exclusive Container list\n");
              return 1;
            }
          } elsif ($ConNamesIncl) {
            if (!(@catcon_Containers = 
                  validate_con_names($ConNamesIncl, 0, 
                                     @catcon_AllContainers, @pretendAllAreOpen,
                                     $catcon_IgnoreInaccessiblePDBs, 
                                     $catcon_DebugOn))) {
              log_msg("catconInit: Unexpected error returned by validate_con_names for inclusive Container list\n");
              return 1;
            } 
          } else {
            # we know that all desired Containers (i.e. Containers in 
            # @catcon_AllContainers) exist, and we don't care whether they 
            # are open, so just copy @catcon__AllContainers into 
            # @catcon_Containers
            @catcon_Containers = @catcon_AllContainers;
          }

          if ($catcon_DebugOn) {
            log_msg("catconInit: scripts need to be run in the following Containers:\n\t");
            log_msg(join("\n\t", @catcon_Containers)."\n");
          }
        }

        if ($catcon_DebugOn) {
          log_msg("catconInit: check if desired Containers are open on this instance:\n");
        }

        # determine if all desired Containers (whose names are stored in 
        # @catcon_Containers) are open on this Instance
        if ($ConNamesExcl || $ConNamesIncl) {
          # Containers whose names are stored in @catcon_Containers need to be 
          # open

          my $curConToCheck = 0; #index into @catcon_Containers

          for (my $curCon = 0; 
               $curCon <= $#catcon_AllContainers; 
               $curCon++) {
            if ($catcon_AllContainers[$curCon] eq 
                $catcon_Containers[$curConToCheck]) {
              if (($isConOpen[$curCon] eq "N") ||
                  $curConToCheck++ == $#catcon_Containers) {
                # this Container is not open or it is open and there are no 
                # more Containers to check - no need look further
                if ($catcon_DebugOn) {
                  log_msg("\tContainer ".$catcon_AllContainers[$curCon]." is ".(($isConOpen[$curCon] eq "N") ? "not open - skip the rest\n" : "open\n"));
                }
                last;
              } elsif ($catcon_DebugOn) {
                log_msg("\tContainer ".$catcon_AllContainers[$curCon]." is open\n");
              }
            }
          }
          
          if ($curConToCheck > $#catcon_Containers) {
            # all desired Containers are open on this Instance, so use it
            $ezConnToUse = $EZConnect;
          }
        } else {
          # ALL Containers need to be open, so we simply need to run down 
          # @isConOpen and hope not to find a single indicator containing "N"
          my $curCon;

          for ($curCon = 0; 
               $curCon <= $#isConOpen && $isConOpen[$curCon] eq "Y"; 
               $curCon++) {
            if ($catcon_DebugOn) {
                log_msg("\tContainer ".$catcon_AllContainers[$curCon]." is open\n");
            }
          }

          if ($curCon > $#isConOpen) {
            # all desired Containers are open on this Instance, so use it
            $ezConnToUse = $EZConnect;
          } elsif ($catcon_DebugOn) {
            log_msg("\tContainer ".$catcon_AllContainers[$curCon]." is not open - skip the rest\n");
          }
        }
        
        if (defined $ezConnToUse) {
          # we found our instance - copy a list of open Container indicators 
          # for future use
          @catcon_IsConOpen = @isConOpen;

          if ($catcon_DebugOn) {
            log_msg <<msg;
catconInit: all desired Containers are open on instance ($instanceName) 
    which will be picked to run all scripts
msg
          }
        }
      } else {
        if ($catcon_DebugOn) {
          log_msg("catconInit: non-CDB-specific processing\n");
        }

        # will run scripts against a non-CDB

        # compute number of processes that can be started on this instance if 
        # this is the first instance or if the caller has not specified a 
        # number of processes to start (which may result in us discovering 
        # that this instance may support a larger number of processes than 
        # previously processed instances) 
        if ($currInst == 0 || $NumProcesses == 0) {
          if ($catcon_DebugOn) {
            log_msg("catconInit: call get_num_procs to determine number of processes that may be started on this Instance because\n");
            if ($currInst == 0) {
              log_msg("    this is the first instance being processed\n");
            } else {
              log_msg("    user did not specify a number of processes\n");
            }
          }

          my $numProcs = 
            get_num_procs($NumProcesses, $ExtParallelDegree, $connectString, 
                          $catcon_DoneCmd, $doneFileNamePrefix, 
                          $catcon_DebugOn);

          if ($numProcs < 1) {
            log_msg("catconInit: invalid number of processes ($numProcs) returned by get_num_procs\n");
            return 1;
          } elsif ($catcon_DebugOn) {
            log_msg("catconInit: get_num_procs determined that $numProcs processes can be started on this instance\n");
          }
            
          if ($numProcs > $catcon_NumProcesses) {
            # this instance will support a greater number of processes than
            # preceding instgance (if any) - remember the number of 
            # processesas well as the EZConnect string of the instance we 
            # will want to use
            $catcon_NumProcesses = $numProcs;
            $ezConnToUse = $EZConnect;
            
            if ($catcon_DebugOn) {
              log_msg("catconInit: remember this instance as supporting the greatest number of processes so far\n");
            }
          }
        }
      }
    }

    # make sure we found a suitable Instance
    if (!(defined $ezConnToUse)) {
      # none of the instances had all of the desired Containers open
      log_msg("catconInit: multiple instances were specified, but none of them had all of the desired Containers open\n");
      return 2;
    }

    # if EZConnect strings were specified, $catcon_InternalConnectString and 
    # $catcon_UserConnectString contain placeholders for the EZConnect string 
    # corresponding to the instance that we pick.  Now that we have 
    # settled on a specific instance, replace these placeholders with the 
    # actual EZConnect string
    if (@ezConnStrings) {
      $catcon_InternalConnectString = 
        build_connect_string($catcon_InternalConnectString, $ezConnToUse, 
                             $catcon_DebugOn);
      $catcon_UserConnectString = 
        build_connect_string($catcon_UserConnectString, $ezConnToUse, 
                             $catcon_DebugOn);
      
      if ($catcon_DebugOn) {
        log_msg <<msg;
catconInit: finalized connect strings:\n\tInternal Connect String = $catcon_InternalConnectString
User Connect String = $catcon_UserConnectString
msg
      }
    }

    # if we haven't determined the number of processes which may be started 
    # on the chosen Instance (which would imply that we will be running 
    # against a CDB since for non-CDBs we select the instance to use based on 
    # the number of processes that can be starfted on it), do it now
    if (!$catcon_NumProcesses) {
      if ($catcon_DebugOn) {
        log_msg <<msg;
catconInit: call get_num_procs to determine number of processes that will
    be started on a CDB instance
msg
      }

      $catcon_NumProcesses = 
        get_num_procs($NumProcesses, $ExtParallelDegree, 
                      $catcon_InternalConnectString, 
                      $catcon_DoneCmd, $doneFileNamePrefix, $catcon_DebugOn);
      
      if ($catcon_NumProcesses < 1) {
        log_msg("catconInit: invalid number of processes ($catcon_NumProcesses) returned by get_num_procs\n");
        return 1;
      } elsif ($catcon_DebugOn) {
        log_msg("catconInit: get_num_procs determined that $catcon_NumProcesses processes can be started on this instance\n");
      }
    }

    # it is possible that we may start more processes than there are PDBs (or 
    # more than 1 process when operating on a non-CDB.)  It's OK since a user 
    # can tell catconExec() that some scripts may be executed concurrently, 
    # so we may have more than one process working on the same Container (or 
    # non-CDB.)  If a user does not want us to start too many processes, he 
    # can tell us how many processes to start (using -n option to catcon.pl, 
    # for instance)

    # start processes
    if (start_processes($catcon_NumProcesses, $catcon_LogFilePathBase, 
                        @catcon_FileHandles, @catcon_ProcIds,
                        @catcon_Containers, $catcon_Root,
                        $catcon_UserConnectString, 
                        $catcon_EchoOn, $catcon_ErrLogging, $catcon_DebugOn, 1,
                        $catcon_UserScript, $catcon_DoneCmd)) {
      return 1;
    }

    # remember whether we are being invoked from a GUI tool which on Windows 
    # means that the passwords and hidden parameters need not be hidden
    $catcon_GUI = $GUI;

    # check for uncommitted transaction after running every script?
    # defaults to FALSE; caller can modify by calling catconXact
    $catcon_UncommittedXactCheck = 0;

    # run scripts against all PDBs and then against the Root
    # defaults to FALSE; caller can modify by calling catconReverse
    $catcon_PdbsThenRoot = 0;

    # should non-existent and closed PDBs be ignored when constructing a list 
    # of Containers against which to run scripts?
    # defaults to FALSE; caller can modify by calling catconForce
    $catcon_IgnoreInaccessiblePDBs = 0;

    # remember that the database is open
    $catcon_DbClosed = 0;

    # remember whether we need to ensure that PDB$SEED is open in a specified 
    # mode while running scripts

    # SeedMode must be an integer between 0 and 3
    if ($SeedMode !~ /\d+/ || $SeedMode < $CATCON_SEED_UNCHANGED || 
        $SeedMode > $CATCON_SEED_DOWNGRADE) {
      log_msg("catconInit: Unexpected value ($SeedMode) for SeedMode\n");
      return 1;
    }

    $catcon_SeedMode = $SeedMode;

    # remember that initialization has completed successfully
    $catcon_InitDone = 1;

    if ($catcon_DebugOn) {
      log_msg("catconInit: initialization completed successfully (".TimeStamp().")\n");
    }

    #
    # Workaround for bug 18969473
    #
    if ($catcon_Windows) {
      open(STDIN, "<", "NUL") || die "open NUL: $!";
    }



    # success
    return 0;
  }

  #
  # catconXact - set a flag indicating whether we should check for scripts 
  #     ending with uncommitted transaction
  #
  # Parameters:
  #   - value to assign to $catcon_UncommittedXactCheck
  #
  sub catconXact ($) {
    my ($UncommittedXactCheck) = @_;

    # remember whether the caller wants us to check for uncommitted 
    # transactions at the end of scripts
    $catcon_UncommittedXactCheck = $UncommittedXactCheck;
  }

  #
  # catconReverse - set a flag indicating whether we should run the script 
  # against all PDBs and then against the Root
  #
  # Parameters:
  #   - value to assign to $catcon_PdbsThenRoot
  #
  sub catconReverse ($) {
    my ($f) = @_;

    # remember whether the caller wants us to check for uncommitted 
    # transactions at the end of scripts
    $catcon_PdbsThenRoot = $f;
  }

  #
  # catconForce - set a flag indicating whether we should ignore closed or 
  # non-existent PDBs when constructing a list of Containers against which to 
  # run scripts
  #
  # Parameters:
  #   - value to assign to $catcon_IgnoreInaccessiblePDBs
  #
  sub catconForce ($) {
    my ($Ignore) = @_;

    # remember whether the caller wants us to ignore closed and 
    # non-existent PDBs 
    $catcon_IgnoreInaccessiblePDBs = $Ignore;
  }

  #
  # catconEZConnect - store a string consisting of EZConnect strings 
  # corresponding to RAC instances to be used to run scripts
  #
  # Parameters:
  #   - value to assign to $catcon_EZConnect
  #
  sub catconEZConnect ($) {
    my ($EZConnect) = @_;

    $catcon_EZConnect = $EZConnect;
  }

  # catconExec - run specified sqlplus script(s) or SQL statements
  #
  # If connected to a non-Consolidated DB, each script will be executed 
  # using one of the processes connected to the DB.
  #
  # If connected to a Consolidated DB and the caller requested that all 
  # scripts and SQL statements be run against the Root (possibly in addition 
  # to other Containers), each script and statement will be executed in the 
  # Root using one of the processes connected to the Root.
  #
  # If connected to a Consolidated DB and were asked to run scripts and SQL 
  # statements in one or more Containers besides the Root, all scripts and 
  # statements will be run against those PDBs in parallel.
  #
  # Bug 18085409: if connected to a CDB and $catcon_PdbsThenRoot is set, the 
  #   order will be reversed and we will run scripts against all PDBs and 
  #   then against the Root.  
  #   To accomplish this without substantially rewriting catconExec, I 
  #   - moved the whole catconExec into catconExec_int() and
  #   - changed catconExec to call catconExec_int as follows:
  #     - if not connected to a CDB or if $catcon_PdbsThenRoot is not set,
  #       - just call catconExec_int
  #     - else (i.e. connected to a CDB and $catcon_PdbsThenRoot is set)
  #       - call catconExec_int passing it name of the Root as a Container 
  #         in which not to run scripts
  #       - if the preceding call does not report an error, call 
  #         catconExec_int telling it to run scripts only in the Root
  #
  # Parameters:
  #   - a reference to an array of sqlplus script name(s) or SQL statement(s); 
  #     script names are expected to be prefixed with @
  #   - an indicator of whether scripts need to be run in order
  #       TRUE => run in order
  #   - an indicator of whether scripts or SQL statements need to be run only 
  #     in the Root if operating on a CDB (temporarily overriding whatever 
  #     was set by catconInit) 
  #       TRUE => if operating on a CDB, run in Root only
  #   - an indicator of whether per process initialization/completion 
  #     statements need to be issued
  #     TRUE => init/comletion statements, if specified, will be issued
  #   - a reference to a list of names of Containers in which to run scripts 
  #     and statements during this invocation of catconExec; does not 
  #     overwrite @catcon_Containers so if no value is supplied for this or 
  #     the next parameter during subsequent invocations of catconExec, 
  #     @catcon_Containers will be used
  #
  #     NOTE: This parameter should not be defined if
  #           - connected to a non-CDB
  #           - caller told us to run statements/scripts only in the Root
  #           - caller has supplied us with a list of names of Containers in 
  #             which NOT to run scripts
  #
  #   - a reference to a list of names of Containers in which NOT to run 
  #     scripts and statements during this invocation of catconExec; does not 
  #     overwrite @catcon_Containers so if no value is supplied for this or 
  #     the next parameter during subsequent invocations of catconExec, 
  #     @catcon_Containers will be used
  #
  #     NOTE: This parameter should not be defined if
  #           - connected to a non-CDB
  #           - caller told us to run statements/scripts only in the Root
  #           - caller has supplied us with a list of names of Containers in 
  #             which NOT to run scripts
  #
  #   - a reference to a custom Errorlogging Identifier; if specified, we will
  #     use the supplied Identifier, ignoring $catcon_NoErrLogIdent
  #
  sub catconExec(\@$$$\$\$\$) {

    my ($StuffToRun, $SingleThreaded, $RootOnly, $IssuePerProcStmts, 
        $ConNamesIncl, $ConNamesExcl, $CustomErrLoggingIdent) = @_;

    if ($catcon_DebugOn) {
      log_msg("catconExec\n\tScript names/SQL statements:\n");
      foreach (@$StuffToRun) {
        log_msg("\t\t$_\n");
      }

      log_msg("\tSingleThreaded        = $SingleThreaded\n");
      log_msg("\tRootOnly              = $RootOnly\n");
      log_msg("\tIssuePerProcStmts     = $IssuePerProcStmts\n");
      if ($$ConNamesIncl) {
        log_msg("\tConNamesIncl          = $$ConNamesIncl\n");
      } else {
        log_msg("\tConNamesIncl            undefined\n");
      }
      if ($$ConNamesExcl) {
        log_msg("\tConNamesExcl          = $$ConNamesExcl\n");
      } else {
        log_msg("\tConNamesExcl            undefined\n");
      }
      if ($$CustomErrLoggingIdent) {
        log_msg("\tCustomErrLoggingIdent = $$CustomErrLoggingIdent\n");
      }
      else {
        log_msg("\tCustomErrLoggingIdent   undefined\n");
      }

      log_msg("\t(".TimeStamp().")\n");
    }

    # there must be at least one script or statement to run
    if (!@$StuffToRun || $#$StuffToRun == -1) {
      log_msg("catconExec: At least one sqlplus script name or SQL statement must be supplied\n");
      return 1;
    }

    # catconInit had better been invoked
    if (!$catcon_InitDone) {
      log_msg("catconExec: catconInit has not been run\n");
      return 1;
    }

    # a number of checks if either a list of Containers in which to run 
    # scripts or a list of Containers in which NOT to tun scripts was specified
    if ($$ConNamesIncl || $$ConNamesExcl) {
      if (!@catcon_Containers) {
        # Container names specified even though we are running against a 
        # non-CDB
        log_msg("catconExec: Container names specified for a non-CDB\n");

        return 1;
      }

      if ($RootOnly) {
        # Container names specified even though we were told to run ONLY 
        # against the Root
        log_msg("catconExec: Container names specified while told to run only against the Root\n");

        return 1;
      }

      if ($catcon_PdbsThenRoot) {
        # Container names specified even though we were told to run in 
        # ALL PDBs and then in the Root
        log_msg("catconExec: Container names specified while told to run in ALL PDBs and then in Root\n");

        return 1;
      }

      # only one of the lists may be defined
      if ($$ConNamesIncl && $$ConNamesExcl) {
        log_msg <<msg;
catconExec: both inclusive
        $$ConNamesIncl
    and exclusive
        $$ConNamesExcl
    Container name lists are defined
msg
        return 1;
      }
    }

    if ($RootOnly && $catcon_PdbsThenRoot) {
      # RootOnly may not be specified if were told to run in ALL PDBs and 
      # then in the Root
        log_msg <<msg;
catconExec: Caller asked to run only in the Root while also indicating that 
    scripts must be run in ALL PDBs and then in Root
msg

        return 1;
    }

    if (!@catcon_Containers || !$catcon_PdbsThenRoot) {
      # non-CDB or not told to reverse the order of Containers - just pass 
      # parameters on to catconExec_int
      return catconExec_int($StuffToRun, $SingleThreaded, $RootOnly, 
                            $IssuePerProcStmts, $ConNamesIncl, $ConNamesExcl, 
                            $CustomErrLoggingIdent);
    } else {
      # connected to a CDB and need to run scripts in ALL PDBs and then in
      # the Root

      my $RetVal;

      # first call catconExec_int to run scripts in all Containers other than 
      # the Root
      $RetVal = catconExec_int($StuffToRun, $SingleThreaded, $RootOnly, 
                               $IssuePerProcStmts, $ConNamesIncl, 
                               \$catcon_Root, $CustomErrLoggingIdent);

      # if catconExec_int reported an error, pass it on
      if ($RetVal) {
        return $RetVal;
      }

      # finally, call catconExec_int to run scirpts only in the Root
      return catconExec_int($StuffToRun, $SingleThreaded, 1,
                            $IssuePerProcStmts, $ConNamesIncl, $ConNamesExcl, 
                            $CustomErrLoggingIdent);
    }
  }

  # NOTE: catconExec_int() should ONLY be called via catconExec which 
  #       performs error checking to ensure that catconExec_int is not 
  #       presented with a combination of arguments which it is not prepared 
  #       to handle
  sub catconExec_int(\@$$$\$\$\$) {

    my ($StuffToRun, $SingleThreaded, $RootOnly, $IssuePerProcStmts, 
        $ConNamesIncl, $ConNamesExcl, $CustomErrLoggingIdent) = @_;

     #Hack add con_id
    my $CurrentContainerQuery = qq#select '==== Current Container = ' || SYS_CONTEXT('USERENV','CON_NAME') || ' Id = ' || SYS_CONTEXT('USERENV','CON_ID') || ' ====' AS now_connected_to from sys.dual;\n/\n#;

    # this array will be used to keep track of processes to which statements 
    # contained in @$PerProcInitStmts need to be sent because they [processes]
    # have not been used in the course of this invocation of catconExec()
    my @NeedInitStmts = ();
    my $bInitStmts = 0;

    # script invocations (together with parameters) and/or SQL statements 
    # which will be executed
    my @ScriptPaths;

    # same as @ScriptPaths but secret parameters will be replaced with prompts
    # so as to avoid storing sensitive data in log files (begin_running and 
    # end_running queries) and error logging tables (in identifier column)
    my @ScriptPathsToDisplay;

    # if $catcon_SpoolOn is set, we will spool output produced by running all 
    # scripts into spool files whose names will be stored in this array
    my @SpoolFileNames;

    my $NextItem;

    # validate script paths and add them, along with parameters and 
    # SQL statements, if any, to @ScriptPaths

    if ($catcon_DebugOn) {
      log_msg("catconExec: validating scripts/statements supplied by the caller\n");
    }

    # if the user supplied regular and/or secret argument delimiters, this 
    # variable will be set to true after we encounter a script name to remind 
    # us to check for possible arguments
    my $LookForArgs = 0;
    
    # indicators of whether a string may be a regular or a secret script 
    # argument
    my $RegularScriptArg;
    my $SecretScriptArg;

    foreach $NextItem (@$StuffToRun) {

      if ($catcon_DebugOn) {
        log_msg("catconExec: going over StuffToRun: NextItem = $NextItem\n");
      }

      if ($NextItem =~ /^@/) {
        # leading @ implies that $NextItem contains a script name
        
        # name of SQL*Plus script
        my $FileName;

        if ($catcon_DebugOn) {
          log_msg("catconExec: next script name = $NextItem\n");
        }

        # strip off the leading @ before prepending source directory name to 
        # script name
        ($FileName = $NextItem) =~ s/^@//;

        # validate path of the sqlplus script and add it to @ScriptPaths
        my $Path = 
          validate_script_path($FileName, $catcon_SrcDir, $catcon_DebugOn);

        if (!$Path) {
          log_msg <<msg;
catconExec: empty Path returned by validate_script_path for 
    SrcDir = $catcon_SrcDir, FileName = $FileName
msg
          return 1;
        }

        push @ScriptPaths, "@".$Path;

        # before pushing a new element onto @ScriptPathsToDisplay, replace 
        # single and double quotes in the previous element (if any) with # 
        # to avoid errors in begin/end_running queries and in 
        # SET ERRORLOGGING ON IDENTIFIER ... statements
        if ($#ScriptPathsToDisplay >= 0) {
          $ScriptPathsToDisplay[$#ScriptPathsToDisplay] =~ s/['"]/#/g;
        }

        # assuming it's OK to show script paths
        push @ScriptPathsToDisplay, "@".$Path; 

        if ($catcon_DebugOn) {
          log_msg("catconExec: full path = $Path\n");
        }
        
        # if caller requested that output of running scripts be spooled, 
        # construct prefix of a spool file name and add it to @SpoolFileNames 
        if ($catcon_SpoolOn) {
          # spool files will get stored in the same directory as log files, 
          # and their names will start with "log file base" followed by '_'
          my $SpoolFileNamePrefix = $catcon_LogFilePathBase .'_';

          if ($catcon_DebugOn) {
            log_msg("catconExec: constructing spool file name prefix: log file path base +' _' = $SpoolFileNamePrefix\n");
          }
          
          # script file name specified by the caller may contain directories;
          # since we want to store spool files in the same directory as log
          # files, we will replace slashes with _
          my $Temp = $FileName;

          $Temp =~ s/[\/\\]/_/g;

          if ($catcon_DebugOn) {
            log_msg("catconExec: constructing spool file name prefix: script name without slashes = $Temp\n");
          }

          # we also want to get rid of script file name extension, so we look 
          # for the last occurrence of '.' and strip off '.' along with 
          # whatever follows it
          my $DotPos = rindex($Temp, '.');

          if ($DotPos > 0) {
            # script name should not start with . (if it does, I will let it 
            # be, I guess
            $Temp = substr($Temp, 0, $DotPos);

            if ($catcon_DebugOn) {
              log_msg <<msg
catconExec: constructing spool file name prefix: 
    after stripping off script file name extension, script name = $Temp
msg
            }
          } else {
            if ($catcon_DebugOn) {
              log_msg("catconExec: constructing spool file name prefix: script file name contained no extension\n");
            }
          }

          push @SpoolFileNames, $SpoolFileNamePrefix.$Temp.'_';

          if ($catcon_DebugOn) {
            log_msg <<msg;
catconExec: constructing spool file name prefix: 
    added $SpoolFileNames[$#SpoolFileNames] to the list
msg
          }
        }

        if ($catcon_RegularArgDelim || $catcon_SecretArgDelim) {
          # remember that script name may be followed by argument(s)
          $LookForArgs = 1;

          if ($catcon_DebugOn) {
            log_msg("catconExec: prepare to handle arguments\n");
          }
        }
      } elsif (   ($RegularScriptArg = 
                     (   $catcon_RegularArgDelim 
                      && $NextItem =~ /^$catcon_RegularArgDelim/))
               || ($SecretScriptArg = 
                     (   $catcon_SecretArgDelim 
                      && $NextItem =~ /^$catcon_SecretArgDelim/))) {
        # looks like an argument to a script; make sure we are actually 
        # looking for script arguments
        if (!$LookForArgs) {
          log_msg("catconExec: unexpected script argument ($NextItem) encountered\n");
          return 1;
        }

        if ($catcon_DebugOn) {
          log_msg("catconExec: processing script argument string ($NextItem)\n");
        }

        # because of short-circuiting of logical operators, if 
        # $RegularScriptArg got set to TRUE, we will never even try to 
        # determine if this string could also represent a secret argument, so 
        # if code in catconInit has determined that a regular argument 
        # delimiter is a prefix of secret argument delimiter, we need to 
        # determine whether this string may also represent a secret argument
        # (and if a regular argument delimiter is NOT a prefix of secret 
        # argument delimiter, reset $SecretScriptArg in case the preceding 
        # item represented a secret argument)
        if ($RegularScriptArg) {
          $SecretScriptArg = 
               ($catcon_ArgToPick == $catcon_PickSecretArg) 
            && ($NextItem =~ /^$catcon_SecretArgDelim/);
        }

        # If this argument could be either (i.e. one of the 
        # argument-introducing strings is a prefix of the other), use 
        # $catcon_ArgToPick to decide how to treat this argument
        # argument stripped off the string marking it as such
        if ($RegularScriptArg && $SecretScriptArg) {

          if ($catcon_ArgToPick == $catcon_PickRegularArg) {
            $SecretScriptArg = undef;  # treat this arg as a regular arg

            if ($catcon_DebugOn) {
              log_msg <<msg;
catconExec: (catcon_ArgToPick = $catcon_ArgToPick, catcon_PickRegularArg = $catcon_PickRegularArg) 
    argument string ($NextItem) could be represent either regular or secret 
    argument - treat as regular
msg
            }
          } else {
            $RegularScriptArg = undef; # treat this arg as a secret arg

            if ($catcon_DebugOn) {
              log_msg <<msg;
catconExec: argument string ($NextItem) could be represent either
    regular or secret argument - treat as secret
msg
            }
          }
        }

        # - if it is a secret argument, prompt the user to enter its value 
        #   and append the value entered by the user to the most recently 
        #   added element of @ScriptPaths
        # - if it is a "regular" argument append this argument to the most 
        #   recently added element of @ScriptPaths
        # In either case, we will strip off the string introducing the 
        # argument and quote the string before adding it to 
        # $ScriptPaths[$#@ScriptPaths] in case it contains embedded blanks.
        # 
        my $Arg;
    
        if ($SecretScriptArg) {
          ($Arg = $NextItem) =~ s/^$catcon_SecretArgDelim//;

          if ($catcon_DebugOn) {
            log_msg("catconExec: prepare to obtain value for secret argument after issuing ($Arg)\n");
          }

          # get the user to enter value for this argument
          log_msg("$Arg: ");

          # do not set ReadMode to noecho if invoked on Windows from a GUI 
          # tool which requires that we do not hide passwords and hidden 
          # parameters
          if (!($catcon_Windows && $catcon_GUI)) {
            ReadMode 'noecho';
          }

          my $ArgVal = ReadLine 0;
          chomp $ArgVal;

          # do not restore ReadMode if invoked on Windows from a GUI tool 
          # which requires that we do not hide passwords and hidden parameters
          if (!($catcon_Windows && $catcon_GUI)) {
            ReadMode 'normal';
          }

          print "\n";

          if ($catcon_DebugOn) {
            log_msg("catconExec: user entered ($ArgVal) in response to ($Arg)\n");
          }

          # quote value entered by the user  and append it to 
          # $ScriptPaths[$#ScriptPaths]
          $ScriptPaths[$#ScriptPaths] .= " '" .$ArgVal."'";

          # instead of showing secret parameter value supplied by the user, 
          # we will show the prompt in response to which the value was 
          # supplied
          $ScriptPathsToDisplay[$#ScriptPathsToDisplay] .= " '" .$Arg."'";
        } else {
          ($Arg = $NextItem) =~ s/^$catcon_RegularArgDelim//;

          # quote regular argument and append it to 
          # $ScriptPaths[$#ScriptPaths]
          $ScriptPaths[$#ScriptPaths] .= " '" .$Arg."'";

          $ScriptPathsToDisplay[$#ScriptPathsToDisplay] .= " '" .$Arg."'";

          if ($catcon_DebugOn) {
            log_msg("catconExec: added regular argument to script invocation string\n");
          }
        }

        if ($catcon_DebugOn) {
          log_msg("catconExec: script invocation string constructed so far:\n\t$ScriptPaths[$#ScriptPaths]\n");
        }
      } else {
        # $NextItem must contain a SQL statement which we will copy into 
        # @ScriptPaths (a bit of misnomer in this case, sorry)

        if ($catcon_DebugOn) {
          log_msg("catconExec: next SQL statement = $NextItem\n");
        }

        push @ScriptPaths, $NextItem;

        # before pushing a new element onto @ScriptPathsToDisplay, replace 
        # single and double quotes in the previous element (if any) with # 
        # to avoid errors in begin/end_running queries and in 
        # SET ERRORLOGGING ON IDENTIFIER ... statements
        if ($#ScriptPathsToDisplay >= 0) {
          $ScriptPathsToDisplay[$#ScriptPathsToDisplay] =~ s/['"]/#/g;
        }

        # assuming it's ok to display SQL statements; my excuse: SET 
        # ERRORLOGGING already does it for statements which result in errors
        push @ScriptPathsToDisplay, $NextItem;

        # we expect no arguments following a SQL statement
        $LookForArgs = 0;

        if ($catcon_DebugOn) {
          log_msg("catconExec: saw SQL statement - do not expect any arguments\n");
        }

        if ($catcon_SpoolOn) {
          push @SpoolFileNames, "";

          if ($catcon_DebugOn) {
            log_msg("catconExec: saw SQL statement - added empty spool file name prefix to the list\n");
          }
        }
      }
    }

    # replace single and double quotes in the last element of 
    # @ScriptPathsToDisplay with # to avoid errors in begin/end_running 
    # queries and in SET ERRORLOGGING ON IDENTIFIER ... statements
    $ScriptPathsToDisplay[$#ScriptPathsToDisplay] =~ s/['"]/#/g;

    # if running against a non-Consolidated Database
    #   - each script/statement will be run exactly once; 
    # else 
    #   - if the caller instructed us to run only in the Root, temporarily 
    #     overriding the list of Containers specified when calling catconInit, 
    #     or if the Root is among the list of Containers against which we are 
    #     to run
    #     - each script/statement will be run against the Root
    #   - then, if running against one or more PDBs
    #     - each script/statement will be run against all such PDBs in parallel

    # offset into the array of process file handles
    my $CurProc = 0;

    # compute number of processes which will be used to run script/statements 
    # specified by the caller; used to determine when all processes finished 
    # their work
    my $ProcsUsed;

    # if the caller requested that we generate spool files for output 
    # produced by running supplied scripts, an array of spool file name 
    # prefixes has already been constructed.  All that's left is to determine 
    # the suffix:
    #   - if running against a non-Consolidated DB, suffix will be an empty 
    #     string
    #   - otherwise, it needs to be set to the name of the Container against 
    #     which script(s) will be run
    my $SpoolFileNameSuffix;

    # initialize array used to keep track of whether we need to send 
    # initialization statements to a process used for the first time during 
    # this invocation of catcon
    if (   $IssuePerProcStmts 
        && $catcon_PerProcInitStmts && $#$catcon_PerProcInitStmts >= 0) {
      @NeedInitStmts = (1) x $catcon_NumProcesses;
    }
        
    # if ERORLOGGING is enabled, this will be used to store IDENTIFIER
    my $ErrLoggingIdent;

    # normally this will be set to @catcon_Containers, but if the caller
    # specified names of Containers in which to run or not to run scripts 
    # and/or statements during this invocation of catconExec, it will get 
    # modified to reflect this
    my @Containers;

    @Containers = @catcon_Containers;

    if ($$ConNamesIncl || $$ConNamesExcl) {
      if ($$ConNamesExcl) {
        if (!(@Containers = 
                validate_con_names($$ConNamesExcl, 1, @catcon_AllContainers, 
                                   @catcon_IsConOpen, 
                                   $catcon_IgnoreInaccessiblePDBs, 
                                   $catcon_DebugOn))) {
          log_msg("catconExec: Unexpected error returned by validate_con_names\n");
          return 1;
        }
      } else {
        if (!(@Containers = 
                validate_con_names($$ConNamesIncl, 0, @catcon_AllContainers, 
                                   @catcon_IsConOpen, 
                                   $catcon_IgnoreInaccessiblePDBs, 
                                   $catcon_DebugOn))) {
          log_msg("catconExec: Unexpected error returned by validate_con_names\n");
          return 1;
        } 
      }

      if ($catcon_DebugOn) {
        log_msg("catconExec: During this invocation ONLY, run only against the following Containers {\n");
        foreach (@Containers) {
          log_msg("\t\t$_\n");
        }
        log_msg("catconExec: }\n");
      }
    }

    # skip the portion of the code that deals with running all scripts in the 
    # Root or in a non-CDB if we need to run it in one or more PDBs but not 
    # in the Root
    if (   @Containers && !$RootOnly 
        && ($Containers[0] ne $catcon_Root)) {
      if ($catcon_DebugOn) {
        log_msg("catconExec: skipping single-Container portion of catconExec\n");
      }

      goto skipSingleContainerRun;
    }

    if ($SingleThreaded) {
      # use 1 process to run all script(s) against a non-Consolidated DB or in 
      # the Root or the specified Container of a Consolidated DB
      $ProcsUsed = 1;
    } else {
      # each script may be run against a non-Consolidated DB or in the Root or
      # the specified Container of a Consolidated DB using a separate process
      $ProcsUsed = (@ScriptPaths > $catcon_NumProcesses) 
        ? $catcon_NumProcesses : @ScriptPaths;
    }

    # - if running against a Consolidated DB, we need to connect to the Root 
    #   in every process
    if (@Containers) {
      for ($CurProc = 0; $CurProc < $ProcsUsed; $CurProc++) {

      # @@@@
      if ((index($ScriptPathsToDisplay[0], "catupgrd") == -1) &&
          (index($ScriptPathsToDisplay[0], "catshutdown") == -1))
      {
        printToSqlplus("catconExec", $catcon_FileHandles[$CurProc], 
                       qq#ALTER SESSION SET CONTAINER = "$catcon_Root"#, 
                       "\n/\n", $catcon_DebugOn);

        print {$catcon_FileHandles[$CurProc]} $CurrentContainerQuery;
        $catcon_FileHandles[$CurProc]->flush;
        $bInitStmts = 1;
      }


        if ($catcon_DebugOn) {
          log_msg("catconExec: process $CurProc (id = $catcon_ProcIds[$CurProc]) connected to Root Container $catcon_Root\n");
        }
      }
    }

    # run all scripts in 
    # - a non-Consolidated DB or
    # - the Root of a Consolidated DB, if caller specified that they be run 
    #   only in the Root OR if Root is among multiple Containers where scripts 
    #   need to be run

    if (!@Containers) {
      if ($catcon_DebugOn) {
        log_msg("catconExec: run all scripts/statements against a non-Consolidated Database\n");
      }

      if ($catcon_SpoolOn) {
        $SpoolFileNameSuffix = "";
        if ($catcon_DebugOn) {
          log_msg("catconExec: non-CDB - set SpoolFileNameSuffix to empty string\n");
        }
      }
    } else {
      # it must be the case that 
      #         $RootOnly 
      #      || ($Containers[0] eq $catcon_Root)
      # for otherwise we would have jumped to skipSingleContainerRun above

      if ($catcon_DebugOn) {
        log_msg("catconExec: run all scripts/statements against the Root (Container $catcon_Root) of a Consoldated Database\n");
      }

      if ($catcon_SpoolOn) {
        # set spool file name suffix to the name of the Root
        $SpoolFileNameSuffix = getSpoolFileNameSuffix($catcon_Root);

        if ($catcon_DebugOn) {
          log_msg("catconExec: CDB - set SpoolFileNameSuffix to $SpoolFileNameSuffix\n");
        }
      }
    }
    
    if ($catcon_ErrLogging) {
      # do not mess with $ErrLoggingIdent if $$CustomErrLoggingIdent is set 
      # since once the user provides a value for the Errorlogging Identifier, 
      # he is fully in charge of its value
      # 
      # Truth table describing how we determine whether to set the 
      # ERRORLOGGING Identifier, and if so, whether to use a default 
      # identifier or a custom identifier
      # N\C 0   1
      #   \--------
      #  0| d | c |
      #   ---------
      #  1| - | c |
      #   ---------
      #
      # N = is $catcon_NoErrLogIdent set?
      # C = is $$CustomErrLoggingIdent defined?
      # d = use default ERRORLOGGING Identifier
      # c = use custom ERRORLOGGING Identifier
      # - = do not set ERRORLOGGING Identifier
      #
      # NOTE: it's important that we we assign $$CustomErrLoggingIdent to 
      #       $ErrLoggingIdent and test the result BEFORE we test 
      #       $catcon_NoErrLogIdent because  if $$CustomErrLoggingIdent is 
      #       $defined, we will ignore catcon_NoErrLogIdent, so it's necessary 
      #       that $ErrLoggingIdent gets set to $$CustomErrLoggingIdent 
      #       regardless of whether $catcon_NoErrLogIdent is set
      if (!($ErrLoggingIdent = $$CustomErrLoggingIdent) && 
          !$catcon_NoErrLogIdent) {
        if (!@Containers) {
          $ErrLoggingIdent = "";
        } else {
          $ErrLoggingIdent = $catcon_Root."::";
        }
      }

      # replace single and double quotes in $ErrLoggingIdent with # to avoid 
      # confusion
      if ($ErrLoggingIdent && $ErrLoggingIdent ne "") {
        $ErrLoggingIdent =~ s/['"]/#/g;
      }

      if ($catcon_DebugOn) {
        log_msg("catconExec: ErrLoggingIdent prefix = $ErrLoggingIdent\n");
      }
    }

    # $CurProc == -1 (any number < 0 would do, really, since such numbers 
    # could not be used to refer to a process) will indicate that we are yet 
    # to obtain a number of a process to which to send the first script (so we 
    # need to call pickNextProc() even if running single-threaded; once 
    # $CurProc >= 0, if running single-threaded, we will not be trying to 
    # obtain a new process number)
    $CurProc = -1; 

    # index into @ScriptPathsToDisplay array which will be kept in sync with 
    # the current element of @ScriptPaths
    # this index will also be used to access elements of @SpoolFileNames in 
    # sync with elements of the list of scripts and SQL statements to be 
    # executed
    my $ScriptPathDispIdx = -1;

    foreach my $FilePath (@ScriptPaths) {
      if (!$SingleThreaded || $CurProc < 0) {
        # find next available process
        $CurProc = pickNextProc($ProcsUsed, $catcon_NumProcesses, $CurProc + 1,
                                $catcon_LogFilePathBase, \@catcon_ProcIds, 
                                $catcon_Windows, $catcon_LogFilePathBase, 
                                $catcon_DebugOn);

        if ($CurProc < 0) {
          # some unexpected error was encountered
          log_msg("catconExec: unexpected error in pickNextProc\n");

          return 1;
        }

        # if this is the first time we are using this process and 
        # the caller indicated that one or more statements need to be executed 
        # before using a process for the first time, issue these statements now
        if ($#NeedInitStmts >= 0 && $NeedInitStmts[$CurProc]) {
          firstProcUseStmts($ErrLoggingIdent, $$CustomErrLoggingIdent,
                            $catcon_ErrLogging, 
                            \@catcon_FileHandles, $CurProc, 
                            $catcon_PerProcInitStmts, \@NeedInitStmts, 
                            $catcon_DebugOn);
        }
      }

      # element of @ScriptPathsToDisplay which corresponds to $FilePath
      my $FilePathToDisplay = $ScriptPathsToDisplay[++$ScriptPathDispIdx];

      # @@@@
      if (index($FilePathToDisplay, "catupgrd") == -1)
      {

      # run additional init statements (set tab on, set _oracle_script, etc.)
      additionalInitStmts(\@catcon_FileHandles, $CurProc,
                          $catcon_UserConnectString, 
                          0, 0,
                          $catcon_ProcIds[$CurProc], $catcon_EchoOn,
                          $catcon_DebugOn, $catcon_UserScript);

      print {$catcon_FileHandles[$CurProc]} qq#select '==== CATCON EXEC ROOT ====' AS catconsection from dual\n/\n#;

      # bracket script or statement with strings intended to make it easier 
      # to determine origin of output in the log file

      # @@@@ Added more info
      print {$catcon_FileHandles[$CurProc]} qq#select '==== $FilePathToDisplay' || ' Container:' || SYS_CONTEXT('USERENV','CON_NAME') || ' Id:' || SYS_CONTEXT('USERENV','CON_ID') || ' ' || TO_CHAR(SYSTIMESTAMP,'YY-MM-DD HH:MI:SS') || ' Proc:$CurProc ====' AS begin_running from sys.dual;\n/\n#;

     }

      if ($catcon_ErrLogging) {
        # construct and issue SET ERRORLOGGING ON [TABLE...] statement

        # @@@@
        if ($bInitStmts)
        {
            err_logging_tbl_stmt($catcon_ErrLogging, \@catcon_FileHandles, 
                                 $CurProc, $catcon_DebugOn);
        }

        if ($ErrLoggingIdent) {
          # send SET ERRORLOGGING ON IDENTIFIER ... statement

          my $Stmt;

          if ($$CustomErrLoggingIdent) {
            # NOTE: if the caller of catconExec() has supplied a custom 
            #       Errorlogging Identifier, it has already been copied into 
            #       $ErrLoggingIdent which was then normalized, so our use of 
            #       $ErrLoggingIdent rather than $CustomErrLoggingIdent below 
            #       is intentional
            $Stmt = "SET ERRORLOGGING ON IDENTIFIER '".substr($ErrLoggingIdent, 0, 256)."'";
          } else { 
            $Stmt = "SET ERRORLOGGING ON IDENTIFIER '".substr($ErrLoggingIdent.$FilePathToDisplay, 0, 256)."'";
          }

          if ($catcon_DebugOn) {
            log_msg("catconExec: sending $Stmt to process $CurProc\n");
          }

          printToSqlplus("catconExec", $catcon_FileHandles[$CurProc], 
                 $Stmt, "\n", $catcon_DebugOn);
        }
      }

      # statement to start/end spooling output of a SQL*Plus script
      my $SpoolStmt;

      # if the caller requested that we generate a spool file and we are about 
      # to execute a script, issue SPOOL ... REPLACE
      if ($catcon_SpoolOn && $SpoolFileNames[$ScriptPathDispIdx] ne "") {
        $SpoolStmt = "SPOOL '" . $SpoolFileNames[$ScriptPathDispIdx] . $SpoolFileNameSuffix . "' REPLACE";

        if ($catcon_DebugOn) {
          log_msg("catconExec: sending $SpoolStmt to process $CurProc\n");
        }

        printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
                 $SpoolStmt, "\n", $catcon_DebugOn);

        # remember that after we execute the script, we need to turn off 
        # spooling
        $SpoolStmt = "SPOOL OFF \n";
      }

      # value which will be used with ALTER SESSION SET APPLICATION ACTION
      my $AppInfoAction;

      my $LastSlash; # position of last / or \ in the script name
      
      if ($FilePath !~ /^@/) {
        $AppInfoAction = $FilePath;
      } elsif (($LastSlash = rindex($FilePath, '/')) >= 0 ||
               ($LastSlash = rindex($FilePath, '\\')) >= 0) {
        $AppInfoAction = substr($FilePath, $LastSlash + 1);
      } else {
        # FilePath contains neither backward nor forward slashes, so use it 
        # as is
        $AppInfoAction = $FilePath;
      }

      # $AppInfoAction may include parameters passed to the script. 
      # These parameters will be surrounded with single quotes, which will 
      # cause a problem since $AppInfoAction is used to construct a 
      # string parameter used with ALTER SESSION SET APPLICATION ACTION.
      # To prevent this from happening, we will replace single quotes found
      #in $AppInfoAction with #
      $AppInfoAction =~ s/[']/#/g;

      if (!@Containers) {
        $AppInfoAction = "non-CDB::".$AppInfoAction;
      } else {
        $AppInfoAction = $catcon_Root."::".$AppInfoAction;
      }

      # use ALTER SESSION SET APPLICATION MODULE/ACTION to identify process, 
      # Container, if any, and script or statement being run

      # @@@@
      if ((index($FilePathToDisplay, "catupgrd") == -1) &&
          (index($FilePathToDisplay, "catshutdown") == -1))

      {
        printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
                       qq#ALTER SESSION SET APPLICATION MODULE = 'catcon(pid=$PID)'#,
                       "\n/\n", $catcon_DebugOn);
      }

      if ($catcon_DebugOn) {
        log_msg("catconExec: issued ALTER SESSION SET APPLICATION MODULE = 'catcon(pid=$PID)'\n");
      }

      # @@@@
      if ((index($FilePathToDisplay, "catupgrd") == -1) &&
          (index($FilePathToDisplay, "catshutdown") == -1))
      {
        printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
                       "ALTER SESSION SET APPLICATION ACTION = '$AppInfoAction'",
                       "\n/\n", $catcon_DebugOn);
      }

      if ($catcon_DebugOn) {
        log_msg("catconExec: issued ALTER SESSION SET APPLICATION ACTION = '$AppInfoAction'\n");
      }

      # execute next script or SQL statement
      if ($catcon_DebugOn) {
        log_script_execution($FilePath, @Containers ? $catcon_Root : undef, 
                             $CurProc);
      }

      printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
                     $FilePath, "\n", $catcon_DebugOn);

      # if executing a statement, follow the statement with "/"
      if ($FilePath !~ /^@/) {
        print {$catcon_FileHandles[$CurProc]} "/\n";
      }

      # if we started spooling before running the script, turn it off after 
      # it is done
      if ($SpoolStmt) {
        if ($catcon_DebugOn) {
          log_msg("catconExec: sending $SpoolStmt to process $CurProc\n");
        }

        printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
                       $SpoolStmt, "", $catcon_DebugOn);
      }

      # @@@@ Added more info
      if (index($FilePathToDisplay, "catshutdown") == -1)
      {
        # @@@@ Added more info
        print {$catcon_FileHandles[$CurProc]} qq#select '==== $FilePathToDisplay' || ' Container:' || SYS_CONTEXT('USERENV','CON_NAME') || ' Id:' || SYS_CONTEXT('USERENV','CON_ID') || ' ' || TO_CHAR(SYSTIMESTAMP,'YY-MM-DD HH:MI:SS') || ' Proc:$CurProc ====' AS end_running from sys.dual;\n/\n#;

      }

      if ($FilePath =~ /^@/ && $catcon_UncommittedXactCheck) {
        # if asked to check whether a script has ended with uncommitted 
        # transaction, do so now
        printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
               qq#SELECT decode(COUNT(*), 0, 'OK', 'Script ended with uncommitted transaction') AS uncommitted_transaction_check FROM v\$transaction t, v\$session s, v\$mystat m WHERE t.ses_addr = s.saddr AND s.sid = m.sid AND ROWNUM = 1#, 
               "\n/\n", $catcon_DebugOn);
      }

      # unless we are running single-threaded, we need a "done" file to be 
      # created after the current script or statement completes so that 
      # next_proc() would recognize that this process is available and 
      # consider it when picking the next process to run a script or SQL 
      # statement
      if (!$SingleThreaded) {
        # file which will indicate that process $CurProc finished its work and 
        # is ready for more
        #
        # Bug 18011217: append _catcon_$catcon_ProcIds[$CurProc] to 
        # $catcon_LogFilePathBase to avoid conflicts with other catcon 
        # processes running on the same host
        my $DoneFile = 
          done_file_name($catcon_LogFilePathBase, $catcon_ProcIds[$CurProc]);

        printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
                       qq/$catcon_DoneCmd $DoneFile/, "\n", $catcon_DebugOn);
      
        if ($catcon_DebugOn) {
          log_msg <<msg;
catconExec: sent "$catcon_DoneCmd $DoneFile" to process 
    $CurProc (id = $catcon_ProcIds[$CurProc]) to indicate its availability 
    after completing $FilePath
msg
        }
      }

      $catcon_FileHandles[$CurProc]->flush;
    }

    # if we are running single-threaded, we need a "done" file to be 
    # created after the last script or statement sent to the current Container 
    # completes so that next_proc() would recognize that this process is 
    # available and consider it when picking the next process to run a script 
    # or SQL statement
    if ($SingleThreaded) {
      # file which will indicate that process $CurProc finished its work and 
      # is ready for more
      #
      # Bug 18011217: append _catcon_$catcon_ProcIds[$CurProc] to 
      # $catcon_LogFilePathBase to avoid conflicts with other catcon 
      # processes running on the same host
      my $DoneFile = 
        done_file_name($catcon_LogFilePathBase, $catcon_ProcIds[$CurProc]);

      printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
                     qq/$catcon_DoneCmd $DoneFile/, "\n", $catcon_DebugOn);

      # flush the file so a subsequent test for file existence does 
      # not fail due to buffering
      $catcon_FileHandles[$CurProc]->flush;
      
      if ($catcon_DebugOn) {
        log_msg <<msg;
catconExec: sent "$catcon_DoneCmd $DoneFile" to process 
    $CurProc (id = $catcon_ProcIds[$CurProc]) to indicate its availability
msg
      }
    }
  
    # if 
    #   - there are no additional Containers in which we need to run scripts 
    #     and/or SQL statements and 
    #   - the user told us to issue per-process init and completion statements 
    #     and 
    #   - there are such statements to send, 
    # they need to be passed to wait_for_completion
    my $EndStmts;

    if (   ($RootOnly || !(@Containers && $#Containers > 0))
           && $IssuePerProcStmts) {
      $EndStmts = $catcon_PerProcEndStmts;
    } else {
      $EndStmts = undef;
    }

    if (wait_for_completion($ProcsUsed, $catcon_NumProcesses, 
                            $catcon_LogFilePathBase, 
                            @catcon_FileHandles, @catcon_ProcIds,
                            $catcon_DoneCmd, $catcon_Windows, 
                            @$EndStmts, 
                            @catcon_Containers ? $catcon_Root : undef,
                            $catcon_InternalConnectString,
                            $catcon_DebugOn) == 1) {
      # unexpected error was encountered, return
      log_msg("catconExec: unexpected error in wait_for_completions\n");

      return 1;
    }

    # will jump to this label if scripts/stataments need to be run against one
    # or more PDBs, but not against Root
skipSingleContainerRun:

    # if 
    # - running against a Consolidated DB and 
    # - caller has not instructed us to run ONLY in the Root, 
    # - the list of Containers against which we need to run includes at 
    #   least one PDB (which can be establsihed by verifying that either 
    #   @Containers contains more than one element or the first
    #   element is not CDB$ROOT)
    # run all scripts/statements against all remaining Containers (i.e. PDBs, 
    # since we already took care of the Root, unless the user instructed us 
    # to skip it)    
    if (   @Containers 
        && !$RootOnly 
        && (   $#Containers > 0 
            || ($Containers[0] ne $catcon_Root)))
    {
      # A user may have excluded the Root (and possibly some other PDBs, but 
      # the important part is the Root) from the list of Containers against 
      # which to run scripts, in which case $Containers[0] would 
      # contain name of a PDB, and we would have skipped the single-container 
      # part of this subroutine.  
      #
      # It is important that we keep it in mind when deciding across how many 
      # Containers we need to run and whether to skip the Container whose 
      # name is stored in $Containers[0].

      # offset into @Containers of the first PDB name
      my $firstPDB = ($Containers[0] eq $catcon_Root) ? 1 : 0;

      # number of PDB names in @Containers
      my $numPDBs = $#Containers + 1 - $firstPDB;
      
      if ($catcon_DebugOn) {
        log_msg("catconExec: run all scripts/statements against remaining $numPDBs PDBs\n");
      }

      # compute number of processes which will be used to run 
      # script/statements specified by the caller in all remaining Containers; 
      # used to determine when all processes finished their work
      if ($SingleThreaded) {
        $ProcsUsed = 
          ($numPDBs > $catcon_NumProcesses) ? $catcon_NumProcesses : $numPDBs;
      } else {
        $ProcsUsed = 
          (@ScriptPaths * $numPDBs > $catcon_NumProcesses) 
            ? $catcon_NumProcesses 
            : @ScriptPaths * $numPDBs;
      }

      # one of the PDBs against which we will run scripts/SQL statements may be
      # PDB$SEED; before we attempt to run any statements against it,
      # we need to make sure it is open in the mode specified by the caller via
      # catconInit.SeedMode.
      # mode.  
      #
      # Since PDB$SEED has con_id of 2, it will be the first PDB in the list.
      #
      # NOTE: as a part of fix for bug 13072385, I moved code to revert 
      #       PDB$SEED mode back to its original mode into catconWrapUp(), 
      #       but I am leaving code that changes its mode here in 
      #       catconExec() (rather than moving it into catconInit()) because 
      #       the caller may request that scripts/statements be run against 
      #       PDB$SEED even if it was not one of the Containers specified 
      #       when calling catconInit().  Because of that possibility, I have 
      #       to keep this code here, so I see no benefit from also adding it 
      #       to catconInit().
      if ($Containers[$firstPDB] eq q/PDB$SEED/ && 
          $catcon_SeedMode != $CATCON_SEED_UNCHANGED) {

        # string corresponding to the mode specified by the caller
        my $ModeString;
          
        if ($catcon_SeedMode == $CATCON_SEED_READ_WRITE) {
          $ModeString = "READ WRITE";
        } elsif ($catcon_SeedMode == $CATCON_SEED_READ_ONLY) {
          $ModeString = "READ ONLY";
        } else {
          # we are not distinguishing between UPGRADE and DOWNGRADE
          $ModeString = "UPGRADE";
        }
          
        if ($catcon_DebugOn) {
          log_msg("catconExec: check if PDB\$SEED needs to be reopened in $ModeString mode\n");
        }
            
        my $SeedMode;

        # Bug 18011217: append _catcon_$catcon_ProcIds[0] to 
        # $catcon_LogFilePathBase to avoid conflicts with other catcon 
        # processes running on the same host
        $SeedMode = 
          seed_pdb_mode_state($catcon_InternalConnectString, $catcon_DoneCmd, 
                              done_file_name_prefix($catcon_LogFilePathBase,
                                                    $catcon_ProcIds[0]), 
                              $catcon_DebugOn);

        # If PDB$SEED is open in a mode different from that requested by the 
        # caller, change the mode to the desired one and remember to which 
        # mode it needs to be restored when we are done
        #
        # NOTE: if a PDB$SEED is open in UPGRADE or DOWNGRADE mode, $SeedMode 
        # will be set to 3 since we don't currently distinguish between 
        # UPGRADE and DOWNGRADE
        #
        # Bug 18606911: if PDB$SEED is open in UPGRADE mode and the caller 
        # asked that it be open in READ WRITE mode, there is no need to 
        # change PDB$SEED's mode
        if (   $catcon_SeedMode != $SeedMode 
            && !(   ($catcon_SeedMode == $CATCON_SEED_DOWNGRADE ||
                     $catcon_SeedMode == $CATCON_SEED_READ_WRITE)
                 && $SeedMode == $CATCON_SEED_UPGRADE)) {
          
          # remember the mode in which PDB$SEED will need to be reopened
          if ($SeedMode == $CATCON_SEED_READ_WRITE) {
            $catcon_RevertSeedPdbMode = "READ WRITE";
          } elsif ($SeedMode == $CATCON_SEED_READ_ONLY) {
            $catcon_RevertSeedPdbMode = "READ ONLY";
          } else {
            # we are not distinguishing between UPGRADE and DOWNGRADE
            $catcon_RevertSeedPdbMode = "UPGRADE";
          }

          # Bug 18011217: append _catcon_$catcon_ProcIds[0] to 
          # $catcon_LogFilePathBase to avoid conflicts with other catcon 
          # processes running on the same host
          reset_seed_pdb_mode($catcon_InternalConnectString, 
                              "OPEN ".$ModeString, 
                              $catcon_DoneCmd, 
                              done_file_name_prefix($catcon_LogFilePathBase, 
                                                    $catcon_ProcIds[0]), 
                              $catcon_DebugOn);

          if ($catcon_DebugOn) {
            log_msg("catconExec: PDB\$SEED was opened in $catcon_RevertSeedPdbMode mode; now reopened in $ModeString mode\n");
          }
        }
      }

      # offset into the array of remaining Container names
      my $CurCon;

      # set it to -1 so the first time next_proc is invoked, it will start by 
      # examining status of process 0
      $CurProc = -1;

      # NOTE: $firstPDB contains offset of the first PDB in the list, but 
      #       $#Containers still represents the offset of the last PDB
      for ($CurCon = $firstPDB; $CurCon <= $#Containers; $CurCon++) {

        # if we were told to run single-threaded, switch into the right 
        # Container ; all scripts and SQL statement to be executed in this
        # Container will be sent to the same process
        if ($SingleThreaded) {
          # as we are starting working on a new Container, find next 
          # available process
          $CurProc = pickNextProc($ProcsUsed, $catcon_NumProcesses, 
                                  $CurProc + 1,
                                  $catcon_LogFilePathBase, \@catcon_ProcIds, 
                                  $catcon_Windows, $catcon_LogFilePathBase, 
                                  $catcon_DebugOn);
          
          if ($CurProc < 0) {
            # some unexpected error was encountered
            log_msg("catconExec: unexpected error in pickNextProc\n");

            return 1;
          }

          additionalInitStmts(\@catcon_FileHandles, $CurProc, 
                              $catcon_UserConnectString, 
                              $Containers[$CurCon], 
                              $CurrentContainerQuery, $catcon_ProcIds[$CurProc],
                              $catcon_EchoOn, $catcon_DebugOn, 
                              $catcon_UserScript);
        }

        # determine prefix of ERRORLOGGING identifier, if needed
        if ($catcon_ErrLogging) {
          # do not mess with $ErrLoggingIdent if $$CustomErrLoggingIdent is set
          # since once the user provides a value for the Errorlogging 
          # Identifier, he is fully in charge of its value
          # do not mess with $ErrLoggingIdent if $$CustomErrLoggingIdent is set
          # since once the user provides a value for the Errorlogging 
          # Identifier, he is fully in charge of its value
          # 
          # Truth table describing how we determine whether to set the 
          # ERRORLOGGING Identifier, and if so, whether to use a default 
          # identifier or a custom identifier
          # N\C 0   1
          #   \--------
          #  0| d | c |
          #   ---------
          #  1| - | c |
          #   ---------
          #
          # N = is $catcon_NoErrLogIdent set?
          # C = is $$CustomErrLoggingIdent defined?
          # d = use default ERRORLOGGING Identifier
          # c = use custom ERRORLOGGING Identifier
          # - = do not setuse ERRORLOGGING Identifier
          #
          # NOTE: it's important that we we assign $$CustomErrLoggingIdent to 
          #       $ErrLoggingIdent and test the result BEFORE we test 
          #       $catcon_NoErrLogIdent because  if $$CustomErrLoggingIdent is 
          #       $defined, we will ignore catcon_NoErrLogIdent, so it's 
          #       necessary that $ErrLoggingIdent gets set to 
          #       $$CustomErrLoggingIdent regardless of whether 
          #       $catcon_NoErrLogIdent is set
          if (!($ErrLoggingIdent = $$CustomErrLoggingIdent) && 
              !$catcon_NoErrLogIdent) {
            $ErrLoggingIdent = "{$Containers[$CurCon]}::";
          }

          # replace single and double quotes in $ErrLoggingIdent with # to 
          # avoid confusion
          if ($ErrLoggingIdent && $ErrLoggingIdent ne "") {
            $ErrLoggingIdent =~ s/['"]/#/g;
          }

          if ($catcon_DebugOn) {
            log_msg("catconExec: ErrLoggingIdent prefix = $ErrLoggingIdent\n");
          }
        }

        my $ScriptPathDispIdx = -1;

        foreach my $FilePath (@ScriptPaths) {
          # switch into the right Container if we were told to run 
          # multi-threaded; each script or SQL statement may be executed 
          # using a different process
          if (!$SingleThreaded) {
            # as we are starting working on a new script or SQL statement, 
            # find next available process
            $CurProc = pickNextProc($ProcsUsed, $catcon_NumProcesses, 
                                    $CurProc + 1,
                                    $catcon_LogFilePathBase, \@catcon_ProcIds, 
                                    $catcon_Windows, $catcon_LogFilePathBase, 
                                    $catcon_DebugOn);

            if ($CurProc < 0) {
              # some unexpected error was encountered
              log_msg("catconExec: unexpected error in pickNextProc\n");

              return 1;
            }

            additionalInitStmts(\@catcon_FileHandles, $CurProc, 
                                $catcon_UserConnectString, 
                                $Containers[$CurCon], 
                                $CurrentContainerQuery, 
                                $catcon_ProcIds[$CurProc],
                                $catcon_EchoOn, $catcon_DebugOn,
                                $catcon_UserScript);
          }

          # if this is the first time we are using this process and 
          # the caller indicated that one or more statements need to be 
          # executed before using a process for the first time, issue these 
          # statements now
          if ($#NeedInitStmts >= 0 && $NeedInitStmts[$CurProc]) {
            firstProcUseStmts($ErrLoggingIdent, $$CustomErrLoggingIdent,
                              $catcon_ErrLogging, 
                              \@catcon_FileHandles, $CurProc, 
                              $catcon_PerProcInitStmts, \@NeedInitStmts, 
                              $catcon_DebugOn);
          }

          print {$catcon_FileHandles[$CurProc]} qq#select '==== CATCON EXEC IN CONTAINERS ====' AS catconsection from dual\n/\n#;

          # element of @ScriptPathsToDisplay which corresponds to $FilePath
          my $FilePathToDisplay = $ScriptPathsToDisplay[++$ScriptPathDispIdx];

          # bracket script or statement with strings intended to make it 
          # easier to determine origin of output in the log file

          # @@@@ Added more info
          print {$catcon_FileHandles[$CurProc]} qq#select '==== $FilePathToDisplay' || ' Container:' || SYS_CONTEXT('USERENV','CON_NAME') || ' Id:' || SYS_CONTEXT('USERENV','CON_ID') || ' ' || TO_CHAR(SYSTIMESTAMP,'YY-MM-DD HH:MI:SS') || ' Proc:$CurProc ====' AS begin_running from sys.dual;\n/\n#;



          if ($catcon_ErrLogging) {
            # construct and issue SET ERRORLOGGING ON [TABLE...] statement
            # @@@@
            if ($bInitStmts)
            {
                err_logging_tbl_stmt($catcon_ErrLogging, \@catcon_FileHandles, 
                                     $CurProc, $catcon_DebugOn);
            }

            if ($ErrLoggingIdent) {
              # send SET ERRORLOGGING ON IDENTIFIER ... statement

              my $Stmt;

              if ($$CustomErrLoggingIdent) {
                # NOTE: if the caller of catconExec() has supplied a custom 
                #       Errorlogging Identifier, it has already been copied 
                #       into $ErrLoggingIdent which was then normalized, so 
                #       our use of $ErrLoggingIdent rather than 
                #       $CustomErrLoggingIdent below is intentional
                $Stmt = "SET ERRORLOGGING ON IDENTIFIER '".substr($ErrLoggingIdent, 0, 256)."'";
              } else {
                $Stmt = "SET ERRORLOGGING ON IDENTIFIER '".substr($ErrLoggingIdent.$FilePathToDisplay, 0, 256)."'";
              }

              if ($catcon_DebugOn) {
                log_msg("catconExec: sending $Stmt to process $CurProc\n");
              }

              printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
                             $Stmt, "\n", $catcon_DebugOn);
            }
          }

          # statement to start/end spooling output of a SQL*Plus script
          my $SpoolStmt;

          # if the caller requested that we generate a spool file and we are 
          # about to execute a script, issue SPOOL ... REPLACE
          if ($catcon_SpoolOn && $SpoolFileNames[$ScriptPathDispIdx] ne "") {
            my $SpoolFileNameSuffix = 
              getSpoolFileNameSuffix($Containers[$CurCon]);

            $SpoolStmt = "SPOOL '" . $SpoolFileNames[$ScriptPathDispIdx] . $SpoolFileNameSuffix . "' REPLACE\n";
            
            if ($catcon_DebugOn) {
              log_msg("catconExec: sending $SpoolStmt to process $CurProc\n");
            }

            printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
                           $SpoolStmt, "", $catcon_DebugOn);

            # remember that after we execute the script, we need to turn off 
            # spooling
            $SpoolStmt = "SPOOL OFF \n";
          }

          # if executing a query, will be set to the text of the query; 
          # otherwise, will be set to the name of the script with parameters, 
          # if any
          my $AppInfoAction;

          my $LastSlash; # position of last / or \ in the script name
      
          if ($FilePath !~ /^@/) {
            $AppInfoAction = $FilePath;
          } elsif (($LastSlash = rindex($FilePath, '/')) >= 0 ||
                   ($LastSlash = rindex($FilePath, '\\')) >= 0) {
            $AppInfoAction = substr($FilePath, $LastSlash + 1);
          } else {
            # FilePath contains neither backward nor forward slashes, so use 
            # it as is
            $AppInfoAction = $FilePath;
          }

          # $AppInfoAction may include parameters passed to the script. 
          # These parameters will be surrounded with single quotes, which will 
          # cause a problem since $AppInfoAction is used to construct a 
          # string parameter being used with 
          # ALTER SESSION SET APPLICATION ACTION.
          # To prevent this from happening, we will replace single quotes found
          #in $AppInfoAction with #
          $AppInfoAction =~ s/[']/#/g;

          # use ALTER SESSION SET APPLICATION MODULE/ACTION to identify 
          # process, Container and script or statement being run
          # @@@@
          if ((index($FilePathToDisplay, "catupgrd") == -1) &&
              (index($FilePathToDisplay, "catshutdown") == -1))
          {
            printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
                           "ALTER SESSION SET APPLICATION MODULE = 'catcon(pid=$PID)'",
                           "\n/\n", $catcon_DebugOn);
          }
          if ($catcon_DebugOn) {
            log_msg("catconExec: issued ALTER SESSION SET APPLICATION MODULE = 'catcon(pid=$PID)'\n");
          }

          # @@@@
          if ((index($FilePathToDisplay, "catupgrd") == -1) &&
              (index($FilePathToDisplay, "catshutdown") == -1))
          {
            printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
                           "ALTER SESSION SET APPLICATION ACTION = '$Containers[$CurCon]::$AppInfoAction'",
                           "\n/\n", $catcon_DebugOn);
          }

          if ($catcon_DebugOn) {
            log_msg("catconExec: issued ALTER SESSION SET APPLICATION ACTION = '$Containers[$CurCon]::$AppInfoAction'\n");
          }

          # execute next script or SQL statement

          if ($catcon_DebugOn) {
            log_script_execution($FilePath, $Containers[$CurCon], $CurProc);
          }

          printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
                         $FilePath, "\n", $catcon_DebugOn);

          # if executing a statement, follow the statement with "/"
          if ($FilePath !~ /^@/) {
            print {$catcon_FileHandles[$CurProc]} "/\n";
          }

          # if we started spooling before running the script, turn it off after
          # it is done
          if ($SpoolStmt) {
            if ($catcon_DebugOn) {
              log_msg("catconExec: sending $SpoolStmt to process $CurProc\n");
            }
            
            printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
                           $SpoolStmt, "", $catcon_DebugOn);
          }

          # @@@@
          if (index($FilePathToDisplay, "catshutdown") == -1)
          {
            # @@@@ Added more info
            print {$catcon_FileHandles[$CurProc]} qq#select '==== $FilePathToDisplay' || ' Container:' || SYS_CONTEXT('USERENV','CON_NAME') || ' Id:' || SYS_CONTEXT('USERENV','CON_ID') || ' ' || TO_CHAR(SYSTIMESTAMP,'YY-MM-DD HH:MI:SS') || ' Proc:$CurProc ====' AS end_running from sys.dual;\n/\n#;
          }

          if ($FilePath =~ /^@/ && $catcon_UncommittedXactCheck) {
            # if asked to check whether a script has ended with uncommitted 
            # transaction, do so now
            printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
               qq#SELECT decode(COUNT(*), 0, 'OK', 'Script ended with uncommitted transaction') AS uncommitted_transaction_check FROM v\$transaction t, v\$session s, v\$mystat m WHERE t.ses_addr = s.saddr AND s.sid = m.sid AND ROWNUM = 1#, 
               "\n/\n", $catcon_DebugOn);
          }

          # unless we are running single-threaded, we a need a "done" file to 
          # be created after the current script or statement completes so that 
          # next_proc() would recognize that this process is available and 
          # consider it when picking the next process to run a script or SQL 
          # statement
          if (!$SingleThreaded) {
            # file which will indicate that process $CurProc finished its 
            # work and is ready for more
            #
            # Bug 18011217: append _catcon_$catcon_ProcIds[$CurProc] to 
            # $catcon_LogFilePathBase to avoid conflicts with other catcon 
            # processes running on the same host
            my $DoneFile = 
              done_file_name($catcon_LogFilePathBase, 
                             $catcon_ProcIds[$CurProc]);

            printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
                           qq/$catcon_DoneCmd $DoneFile/,
                           "\n", $catcon_DebugOn);

            if ($catcon_DebugOn) {
              log_msg <<msg;
catconExec: sent "$catcon_DoneCmd $DoneFile" to process 
    $CurProc (id = $catcon_ProcIds[$CurProc]) to indicate its availability 
    after completing $FilePath
msg
            }
          }

          $catcon_FileHandles[$CurProc]->flush;
        }

        # if we are running single-threaded, we a need a "done" file to be 
        # created after the last script or statement sent to the current 
        # Container completes so that next_proc() would recognize that this 
        # process is available and consider it when picking the next process 
        # to run a script or SQL statement
        if ($SingleThreaded) {
          # file which will indicate that process $CurProc finished its work 
          # and is ready for more
          #
          # Bug 18011217: append _catcon_$catcon_ProcIds[$CurProc] to 
          # $catcon_LogFilePathBase to avoid conflicts with other catcon 
          # processes running on the same host
          my $DoneFile = 
            done_file_name($catcon_LogFilePathBase, $catcon_ProcIds[$CurProc]);

          printToSqlplus("catconExec", $catcon_FileHandles[$CurProc],
                         qq/$catcon_DoneCmd $DoneFile/,
                         "\n", $catcon_DebugOn);

          # flush the file so a subsequent test for file existence does 
          # not fail due to buffering
          $catcon_FileHandles[$CurProc]->flush;
      
          if ($catcon_DebugOn) {
            log_msg <<msg;
catconExec: sent "$catcon_DoneCmd $DoneFile" to process 
    $CurProc (id = $catcon_ProcIds[$CurProc]) to indicate its availability
msg
          }
        }
      }

      # if 
      #   - the user told us to issue per-process init and completion 
      #     statements and 
      #   - there any such statements to send, 
      # they need to be passed to wait_for_completion
      my $EndStmts = $IssuePerProcStmts ? $catcon_PerProcEndStmts : undef;

      if (wait_for_completion($ProcsUsed, $catcon_NumProcesses, 
                              $catcon_LogFilePathBase, 
                              @catcon_FileHandles, @catcon_ProcIds,
                              $catcon_DoneCmd, $catcon_Windows, 
                              @$EndStmts, 
                              @catcon_Containers ? $catcon_Root : undef,
                              $catcon_InternalConnectString,
                              $catcon_DebugOn) == 1) {
        # unexpected error was encountered, return
        log_msg("catconExec: unexpected error in wait_for_completions\n");

        return 1;
      }
    }

    # success
    return 0;
  }

  #
  # catconRunSqlInEveryProcess - run specified SQL statement(s) in every 
  #                              process
  #
  # Parameters:
  #   - reference to a list of SQL statement(s) which should be run in every 
  #     process
  # 
  # Returns
  #   1 if some unexpected error was encountered; 0 otherwise
  #
  sub catconRunSqlInEveryProcess (\@) {
    my ($Stmts) = @_;

    my $ps;

    # there must be at least one statement to execute
    if (!$Stmts || !@$Stmts || $#$Stmts == -1) {
      log_msg("catconRunSqlInEveryProcess: At least one SQL statement must be supplied");
      return 1;
    }

    if ($catcon_DebugOn) {
      log_msg("running catconRunSqlInEveryProcess\nSQL statements:\n");
      foreach (@$Stmts) {
        log_msg("\t$_\n");
      }
    }

    # catconInit had better been invoked
    if (!$catcon_InitDone) {
      log_msg("catconRunSqlInEveryProcess: catconInit has not been run");
      return 1;
    }

    # send each statement to each process
    foreach my $Stmt (@$Stmts) {
      for ($ps=0; $ps < $catcon_NumProcesses; $ps++) {
        printToSqlplus("catconRunSqlInEveryProcess", $catcon_FileHandles[$ps],
                       $Stmt, "\n", $catcon_DebugOn);
      }    
    }

    return 0;
  }

  #
  # catconShutdown - shutdown the database
  #
  # Parameters:
  #   - shutdown flavor (e.g. ABORT or IMMEDIATE)
  # 
  # Returns
  #   1 if some unexpected error was encountered; 0 otherwise
  #
  sub catconShutdown (;$) {

    my ($ShutdownFlavor) = @_;
      
    # catconInit had better been invoked
    if (!$catcon_InitDone) {
      log_msg("catconShutdown: catconInit has not been run");
      return 1;
    }

    # free up all resources
    catconWrapUp();

    # if someone wants to invoke any catcon subroutine, they will need 
    # to invoke catconInit first

    if ($catcon_DebugOn) {
      log_msg("catconShutdown: will shutdown database using SHUTDOWN $ShutdownFlavor\n");
    }

    # shutdown_db needs to be called after catconWrapUp() to make sure that 
    # all processes have exited.
    #
    # Bug 18011217: append _catcon_$catcon_ProcIds[0] to 
    # $catcon_LogFilePathBase to avoid conflicts with other catcon processes 
    # running on the same host
    shutdown_db($catcon_InternalConnectString, $ShutdownFlavor,
                $catcon_DoneCmd, 
                done_file_name_prefix($catcon_LogFilePathBase, 
                                      $catcon_ProcIds[0]), 
                $catcon_DebugOn);

    return 0;
  }

  #
  # catconUpgEndSessions - Ends all sessions except one.
  #
  # Parameters:
  #   - None
  #
  sub catconUpgEndSessions () {
 
    # @@@@     
    # catconInit had better been invoked
    if (!$catcon_InitDone) {
      log_msg("catconUpgEndSessions: catconInit has not been run\n");
      return 1;
    }

    if ($catcon_DebugOn) {
      log_msg("catconUpgEndSessions: Will end all sessions but one\n");
    }

    #
    # End Every Process but 1.
    #
    if ($catcon_NumProcesses > 1) {
 
        # @@@@
        my $ps;
        for ($ps = 1; $ps <= $catcon_NumProcesses - 1; $ps++) {
            if ($catcon_FileHandles[$ps]) {
                print {$catcon_FileHandles[$ps]} "PROMPT ========== PROCESS ENDED ==========\n";
            }
        }

        # End All Sql Processors but one
        end_processes(1, $catcon_NumProcesses - 1, @catcon_FileHandles, 
                  @catcon_ProcIds, $catcon_DebugOn, $catcon_LogFilePathBase);

        # Set Number of processors to 1
        $catcon_NumProcesses = 1;
    }
    return 0;

  }


  #
  # catconUpgStartSessions - Starts all Sessions.
  #
  # Parameters:
  #   - How many process to start
  #
  sub catconUpgStartSessions ($) {

    my ($NumProcesses) = @_;
      
    # catconInit had better been invoked
    if (!$catcon_InitDone) {
      log_msg("catconUpgStartSessions: catconInit has not been run\n");
      return 1;
    }

    #
    # End current session
    #
    end_processes(0, $catcon_NumProcesses - 1, @catcon_FileHandles, 
                  @catcon_ProcIds, $catcon_DebugOn, $catcon_LogFilePathBase);

    #
    # Set number of Processors
    #
    $catcon_NumProcesses = $NumProcesses;

    #
    # set up signal in case SQL process crashes
    # before it completes its work
    #
    $SIG{CHLD} = \&catcon_HandleSigchld;

    # start processes
    if (start_processes($catcon_NumProcesses, $catcon_LogFilePathBase, 
                        @catcon_FileHandles, @catcon_ProcIds, 
                        @catcon_Containers, $catcon_Root,
                        $catcon_UserConnectString, 
                        $catcon_EchoOn, $catcon_ErrLogging, $catcon_DebugOn, 0,
                        $catcon_UserScript, $catcon_DoneCmd)) {
      return 1;
    }

    if ($catcon_DebugOn) {
      log_msg("catconUpgStartSessions: finished starting $catcon_NumProcesses processes\n");
    }

    return 0;

  }


  #
  # catconBounceProcesses - bounce all processes
  # 
  # Returns
  #   1 if some unexpected error was encountered; 0 otherwise
  #
  sub catconBounceProcesses () {

    # catconInit had better been invoked
    if (!$catcon_InitDone) {
      log_msg("catconBounceProcesses: catconInit has not been run");
      return 1;
    }

    if ($catcon_DebugOn) {
      log_msg("catconBounceProcesses: will bounce $catcon_NumProcesses processes\n");
    }

    # end processes
    end_processes(0, $catcon_NumProcesses - 1, @catcon_FileHandles, 
                  @catcon_ProcIds, $catcon_DebugOn, $catcon_LogFilePathBase);

    # 
    # set up signal in case SQL process crashes
    # before it completes its work
    #
    $SIG{CHLD} = \&catcon_HandleSigchld;

    # start processes

    if (start_processes($catcon_NumProcesses, $catcon_LogFilePathBase, 
                        @catcon_FileHandles, @catcon_ProcIds, 
                        @catcon_Containers, $catcon_Root,
                        $catcon_UserConnectString, 
                        $catcon_EchoOn, $catcon_ErrLogging, $catcon_DebugOn, 0,
                        $catcon_UserScript, $catcon_DoneCmd)) {
      return 1;
    }

    if ($catcon_DebugOn) {
      log_msg("catconBounceProcesses: finished bouncing $catcon_NumProcesses processes\n");
    }

    return 0;
  }

  #
  # catconWrapUp - free any resources which may have been allocated by 
  #                various catcon.pl subroutines
  # 
  # Returns
  #   1 if some unexpected error was encountered; 0 otherwise
  #
  sub catconWrapUp () {

    # catconInit had better been invoked
    if (!$catcon_InitDone) {
      log_msg("catconWrapUp: catconInit has not been run");
      return 1;
    }

    if ($catcon_DebugOn) {
      log_msg("catconWrapUp: about to free up all resources\n");
    }


    # @@@@
    my $ps;
    for ($ps = 0; $ps <= $catcon_NumProcesses - 1; $ps++) {
        if ($catcon_FileHandles[$ps]) {
            print {$catcon_FileHandles[$ps]} "PROMPT ========== PROCESS ENDED ==========\n";
            }
    }


    # end processes
    end_processes(0, $catcon_NumProcesses - 1, @catcon_FileHandles, 
                  @catcon_ProcIds, $catcon_DebugOn, $catcon_LogFilePathBase);

    # if we reopened PDB$SEED in a mode specified by the caller in 
    # catconExec(), revert it to the original mode
    #
    # 14248297: reset_seed_pdb_mode() closes PDB$SEED on all instances, so 
    # we need to open in the original mode on all instances too.
    #
    # NOTE: we need to wait for all processes to be killed before calling 
    #       reset_seed_pdb_mode() because it closes PDB$SEED before reopening 
    #       it in desired mode, and if any process is connected to PDB$SEED 
    #       while we are closing it, ALTER PDB CLOSE will hang.
    if ($catcon_RevertSeedPdbMode) {
      # Bug 18011217: append _catcon_$$ (process id) to 
      # $catcon_LogFilePathBase to avoid conflicts with other catcon 
      # processes running on the same host
      reset_seed_pdb_mode($catcon_InternalConnectString,
                          "OPEN ".$catcon_RevertSeedPdbMode." instances=all", 
                          $catcon_DoneCmd, 
                          done_file_name_prefix($catcon_LogFilePathBase, $$),
                          $catcon_DebugOn);
    
      if ($catcon_DebugOn) {
        log_msg("catconWrapUp: reopened PDB\$SEED in READ ONLY mode\n");
      }

      undef $catcon_RevertSeedPdbMode;
    }

    # restore signal handlers which were reset in catconInit
    # NOTE: if, for example, $SIG{CHLD} existed but was not defined in 
    #       catconInit, I would have liked to undef $SIG{CHLD} here, but that 
    #       results in "Use of uninitialized value in scalar assignment" error,
    #       so I was forced to delete the $SIG{} element instead

    if ((exists $catcon_SaveSig{CHLD}) && (defined $catcon_SaveSig{CHLD})) {
      $SIG{CHLD}  = $catcon_SaveSig{CHLD};
    } else {
      delete $SIG{CHLD};
    }

    if ((exists $catcon_SaveSig{INT}) && (defined $catcon_SaveSig{INT})) {
      $SIG{INT}  = $catcon_SaveSig{INT};
    } else {
      delete $SIG{INT};
    }

    if ((exists $catcon_SaveSig{TERM}) && (defined $catcon_SaveSig{TERM})) {
      $SIG{TERM}  = $catcon_SaveSig{TERM};
    } else {
      delete $SIG{TERM};
    }

    if ((exists $catcon_SaveSig{QUIT}) && (defined $catcon_SaveSig{QUIT})) {
      $SIG{QUIT}  = $catcon_SaveSig{QUIT};
    } else {
      delete $SIG{QUIT};
    }

    # no catcon* subroutines should be invoked without first calling catconInit
    $catcon_InitDone = 0;

    if ($catcon_DebugOn) {
      log_msg("catconWrapUp: done\n");
    }

    return 0;
  }

  #
  # catconIsCDB - return an indicator of whether the database to which we are 
  # connected is a CDB
  #
  sub catconIsCDB () {

    # catconInit had better been invoked
    if (!$catcon_InitDone) {
      log_msg("catconIsCDB: catconInit has not been run");
    }

    if (@catcon_AllContainers) {
      return 1;
    } else {
      return 0;
    }
  }

  #
  # catconGetConNames - return an array of Container names if connected to a CDB
  #
  sub catconGetConNames () {

    # catconInit had better been invoked
    if (!$catcon_InitDone) {
      log_msg("catconGetConNames: catconInit has not been run");
    }

    return @catcon_AllContainers;
  }

  #
  # catconQuery - run a query supplied by the caller 
  #
  # Parameters:
  #   - query to run (IN)
  #     NOTE: query needs to start with "select" with nothing preceding it.  
  #           Failure to do so will cause the function to return no results
  #
  # Returns:
  #   Output of the query.
  #
  sub catconQuery($) {
    my ($query) = @_;

    # catconInit had better been invoked
    if (!$catcon_InitDone) {
      log_msg("catconQuery: catconInit has not been run");
    }

    # each row returned by the query needs to start with the "marker" (XXXXXX) 
    # which identifies rows returned by the query (as opposed to various rows 
    # produced by SQL*PLus), so we replace "select" which start the query with 
    # "select 'XXXXXX' ||"
    $query =~ s/^select/select 'XXXXXX' ||/i;

    my @statements = (
      "connect $catcon_InternalConnectString\n",
      "set echo off\n",
      "set heading off\n",
      "$query\n/\n",
    );

    # Bug 18011217: append _catcon_$catcon_ProcIds[0] to  
    # $catcon_LogFilePathBase to avoid conflicts with other catcon processes 
    # running on the same host
    my @Out = exec_DB_script(@statements, "XXXXXX", 
                             $catcon_DoneCmd, 
                             done_file_name_prefix($catcon_LogFilePathBase,
                                                   $catcon_ProcIds[0]), 
                             $catcon_DebugOn);
    if ($catcon_DebugOn) {
      log_msg("catconQuery: returning ".($#Out+1)." rows {\n");

      foreach (@Out) {
        log_msg("catconQuery:\t$_\n");
      }

      log_msg("catconQuery: }\n");
    }

    return @Out;
  }

  #
  # catconUserPass - return password used when running user scripts or 
  #                  statements
  #
  # Parameters:
  #   - None
  #
  sub catconUserPass() {
      
    # catconInit had better been invoked
    if (!$catcon_InitDone) {
      log_msg("catconUserPass: catconInit has not been run");
    }

    return $catcon_UserPass;
  }

  #
  # catconSetDbClosed - set a flag that tells catcon whether the DB is closed
  #
  # Parameters:
  #   - a flag indicating whether the DB is closed 
  #     (0 => OPEN; otherwise => CLOSED)
  #
  sub catconSetDbClosed($) {
    my ($isClosed) = @_;

    $catcon_DbClosed = $isClosed;
  }

  # return tag for the environment variable containing password for a user 
  # connect string
  sub catconGetUsrPasswdEnvTag () {
    return $USER_PASSWD_ENV_TAG;
  }

  # return tag for the environment variable containing password for the 
  # internal connect string
  sub catconGetIntPasswdEnvTag () {
    return $INTERNAL_PASSWD_ENV_TAG;
  }

  ######################################################################
  #  If one of the child process terminates, it is a fatal error
  ######################################################################

  sub catcon_HandleSigchld () {
    log_msg <<msg;
A process terminated prior to completion.
    Review the ${catcon_LogFilePathBase}*.log files to identify the failure
msg
    $SIG{CHLD} = 'IGNORE';  # now ignore any child processes
    die;  
  }

  sub catcon_HandleSigINT () {
    log_msg("Signal INT was received.\n");

    # Bug 18488530: END block (which gets called when we call die) will take 
    # care of resetting PDB$SEED's mode

    # reregister SIGINT handler in case we are running on a system where 
    # signal(3) acts in "the old unreliable System V way", i.e. clears the 
    # signal handler
    $SIG{INT} = \&catcon_HandleSigINT;
    die;  
  }

  sub catcon_HandleSigTERM () {
    log_msg("Signal TERM was received.\n");

    # Bug 18488530: END block (which gets called when we call die) will take 
    # care of resetting PDB$SEED's mode

    # reregister SIGTERM handler in case we are running on a system where 
    # signal(3) acts in "the old unreliable System V way", i.e. clears the 
    # signal handler
    $SIG{TERM} = \&catcon_HandleSigTERM;
    die;  
  }

  sub catcon_HandleSigQUIT () {
    log_msg("Signal QUIT was received.\n");

    # Bug 18488530: END block (which gets called when we call die) will take 
    # care of resetting PDB$SEED's mode

    # reregister SIGQUIT handler in case we are running on a system where 
    # signal(3) acts in "the old unreliable System V way", i.e. clears the 
    # signal handler
    $SIG{QUIT} = \&catcon_HandleSigQUIT;
    die;  
  }

  # this subroutine should be invoked as a part of handling SIGINT to ensure 
  # that PDB$SEED's mode gets reverted to the value it had before catcon 
  # started manipulating it.  Since under the normal circumstances catcon 
  # does it as a part of catconWrapUp, a call to this function should be 
  # added to the END block to ensure that PDB$SEED gets closed after die is 
  # invoked.
  sub catconRevertPdbSeedMode() {
    # if we reopened PDB$SEED in a mode specified by the caller in 
    # catconExec(), revert it to the original mode
    #
    # 14248297: reset_seed_pdb_mode() closes PDB$SEED on all instances, so 
    # we need to open in the original mode on all instances too.
    #
    # NOTE: normally, we need to wait for all processes to be killed before 
    #       calling reset_seed_pdb_mode(), but since catcon process itself is 
    #       getting killed, there is no room for such niceties.
    if ($catcon_RevertSeedPdbMode) {
      # Bug 18011217: append _catcon_$catcon_ProcIds[0] to 
      # $catcon_LogFilePathBase to avoid conflicts with other catcon processes 
      # running on the same host
      reset_seed_pdb_mode($catcon_InternalConnectString, 
                          "OPEN ".$catcon_RevertSeedPdbMode." instances=all", 
                          $catcon_DoneCmd, 
                          done_file_name_prefix($catcon_LogFilePathBase,
                                                $catcon_ProcIds[0]), 
                          $catcon_DebugOn);

      if ($catcon_DebugOn) {
        log_msg("catconRevertPdbSeedMode: reopened PDB\$SEED in $catcon_RevertSeedPdbMode mode\n");
      }

      # if the caller also tries to call catconRevertPdbSeedMode, make sure 
      # we do not end up calling reset_seed_pdb_mode() more than once
      undef $catcon_RevertSeedPdbMode;
    }
  }

  END {
    # Bug 18488530: make sure PDB$SEED's mode gets reverted before catcon 
    # process dies
    catconRevertPdbSeedMode();
  }
}

1;
