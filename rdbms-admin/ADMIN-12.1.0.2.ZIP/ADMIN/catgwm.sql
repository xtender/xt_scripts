Rem
Rem $Header: rdbms/admin/catgwm.sql /main/8 2014/02/20 12:45:48 surman Exp $
Rem
Rem catgwm.sql
Rem
Rem Copyright (c) 2011, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catgwm.sql - Catalog script for GSM
Rem
Rem    DESCRIPTION
Rem      Creates roles and users for GSM.
Rem
Rem    NOTES
Rem      
Rem
Rem BEGIN SQL_FILE_METADATA
Rem SQL_SOURCE_FILE: rdbms/admin/catgwm.sql
Rem SQL_SHIPPED_FILE: rdbms/admin/catgwm.sql
Rem SQL_PHASE: CATGWM
Rem SQL_STARTUP_MODE: NORMAL
Rem SQL_IGNORABLE_ERRORS: NONE
Rem SQL_CALLING_FILE: rdbms/admin/catproc.sql
Rem END SQL_FILE_METADATA
Rem
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    surman      01/23/14 - 13922626: Update SQL metadata
Rem    pyam        06/25/13 - change gsm_change_message to CREATE + ALTER
Rem    sdball      02/06/13 - New types for database parameters and instances
Rem    sdball      06/08/12 - gran cdb_services to gsmadmin_internal.
Rem    nbenadja    10/31/11 - Add privileges to gsmadmin
Rem    sdball      10/19/11 - use v_$ rather than gv_$ tables.
Rem    sdball      09/27/11 - Move privs to catgw.sql (needed for all
Rem                           databases).
Rem    mjstewar    04/12/11 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

-- SET ECHO ON
-- SPOOL catgwm.log

--*****************
-- Create GSM Roles
--*****************

---------------
-- gsmuser_role
---------------

-- Create role for GSM USER
CREATE ROLE gsmuser_role;
GRANT connect to gsmuser_role;

grant select on gv_$instance                to gsmuser_role;
grant select on gv_$osstat                  to gsmuser_role;
grant select on gv_$sysmetric_history       to gsmuser_role;
grant select on gv_$sysmetric               to gsmuser_role;
grant select on gv_$servicemetric_history   to gsmuser_role;
grant select on gv_$servicemetric           to gsmuser_role;
grant select on gv_$active_services         to gsmuser_role;
grant select on gv_$session                 to gsmuser_role;

grant select on v_$dg_broker_config         to gsmuser_role;
grant select on gv_$dg_broker_config        to gsmuser_role;


--*****************
-- Create GSM Users
--*****************

--------------------
-- gsmadmin_internal
--------------------

-- gsmadmin_internal owns the GSM administrative packages

CREATE USER gsmadmin_internal identified by gsm
  account lock password expire
  default tablespace sysaux
  quota 100M on sysaux;

-- So that packages can count number of list values for _gsm parameter
grant select on v_$parameter2 to gsmadmin_internal;

-- So that packages can do 'alter system set'
grant alter system to gsmadmin_internal;

-- So that we can select from dba_services
grant select on sys.dba_services to gsmadmin_internal;

grant select on sys.gv_$active_services to gsmadmin_internal;


----------
-- gsmuser
----------

-- GSM process connects to GSM databases as gsmuser.
 
CREATE USER gsmuser identified by gsm 
  account lock password expire;

GRANT gsmuser_role to gsmuser;

ALTER SESSION SET CURRENT_SCHEMA = gsmadmin_internal;

-- Create types to hold database specific service information

CREATE TYPE dbparams_t AS OBJECT (
    param_name     VARCHAR2(30),
    param_value    VARCHAR2(100))
/
show errors

CREATE TYPE dbparams_list IS VARRAY(10) OF dbparams_t
/
show errors

CREATE TYPE rac_instance_t AS OBJECT (
    instance_name  VARCHAR2(30),
    pref_or_avail  CHAR(1)          -- 'P' (preferred)
                                    -- 'A' (available)
)
/
show errors

CREATE TYPE instance_list IS TABLE OF rac_instance_t
/
show errors

-----------------------------------
-- Create Change Queue Message Type
-----------------------------------
CREATE TYPE gsm_change_message AS OBJECT (
   admin_id             NUMBER,
   change_id            NUMBER,
   seq#                 NUMBER,
   command              VARCHAR2(30),
   target               VARCHAR2(64),
   pool_name            VARCHAR2(30),     -- Only for pool admin actions
   additional_params    VARCHAR2(1024)    -- Additional parameters for the command
                                          -- Depends on the command and is not used
                                          -- for all commands.  Uses the same syntax
                                          -- as in the gsmctl command.  For example
                                          -- for START SERVICE may contain the 
                                          -- database name:
                                          --        "-database db_name"
)
/
show errors

-- to preserve type history between installed and upgraded databases,
-- we issue CREATE, then ALTER. The above creation matches that in 12.1.0.1
ALTER TYPE gsm_change_message
   MODIFY ATTRIBUTE additional_params VARCHAR(4000) CASCADE
/

ALTER SESSION SET CURRENT_SCHEMA = SYS;

@?/rdbms/admin/sqlsessend.sql
