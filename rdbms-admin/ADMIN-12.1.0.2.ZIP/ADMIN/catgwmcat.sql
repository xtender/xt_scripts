Rem
Rem $Header: rdbms/admin/catgwmcat.sql /st_rdbms_12.1/2 2014/06/05 02:05:12 pyam Exp $
Rem
Rem catgwmcat.sql
Rem
Rem Copyright (c) 2011, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catgwmcat.sql - Catalog script for GSM on the catalog database
Rem
Rem    DESCRIPTION
Rem      Installation/upgrade script for GSM components on the cloud
Rem      catalog database.
Rem
Rem      Run the script like this:
Rem
Rem         catgwmcat.sql
Rem
Rem    NOTES
Rem      
Rem
Rem
Rem BEGIN SQL_FILE_METADATA
Rem SQL_SOURCE_FILE: rdbms/admin/catgwmcat.sql
Rem SQL_SHIPPED_FILE: rdbms/admin/catgwmcat.sql
Rem SQL_PHASE: CATGWMCAT
Rem SQL_STARTUP_MODE: NORMAL
Rem SQL_IGNORABLE_ERRORS: NONE
Rem SQL_CALLING_FILE: rdbms/admin/catpend.sql
Rem END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    pyam        05/27/14 - fix table column ordering
Rem    apfwkr      04/30/14 - Backport devghosh_bug-17709018 from main
Rem    devghosh    04/08/14 - bug17709018: add grant
Rem    surman      01/23/14 - 13922626: Update SQL metadata
Rem    cechen      08/22/13 - add domains for PKI keys in database and cloud
Rem    sdball      08/15/13 - Add db_type field to database table
Rem    lenovak     07/11/13 - grant select from cloud to pooladmins
Rem    sdball      06/12/13 - Remove primary key requirement from gsm_requests
Rem    sdball      05/15/13 - Add data_vers to cloud
Rem    sdball      05/06/13 - Add weights to region
Rem    thbaby      05/06/13 - 16768773: remove creation of CDB_SERVICES
Rem    itaranov    04/24/13 - Grant killing sessions to gsmadmin_internal
Rem    nbenadja    04/22/13 - Add logoff trigger.
Rem    itaranov    03/25/13 - Grant privs to import
Rem    sdball      03/13/13 - Add instance fields and types for admin DBs
Rem    sdball      02/26/13 - Grant select on v_$version
Rem    nbenadja    02/21/13 - grant the use of dbms_server_alert package.
Rem    akruglik    02/05/13 - (bug 16194686) disambiguate reference to
Rem                           gv$active_services in ALTER USER SET
Rem                           CONTAINER_DATA statement
Rem    sdball      01/18/13 - Add versions and database parameters
Rem    sdball      01/11/13 - Grant select on sessions.
Rem    nbenadja    01/10/13 - Extend database table to store threshold values.
Rem    aikumar     11/27/12 - bug-15925294:Change dbms_lock_allocated_v2 back
Rem                           to dbms_lock_allocated
Rem    lenovak     11/07/12 - runtime status flags to the catalog
Rem    rpang       10/11/12 - Use new dbms_network_acl_admin API
Rem    nbenadja    10/11/12 - Add container_data for grants in CDB.
Rem    sdball      08/28/12 - Add ACLs for GSMADMIN_INTERNAL
Rem    sdball      08/03/12 - Add gds_catalog_select role
Rem    nbenadja    07/30/12 - Grant select on gv_$active_services.
Rem    nbenadja    06/23/12 - Fix multiple CDB returned from gv$_database.
Rem    sdball      06/13/12 - Support for number of instances
Rem    nbenadja    06/21/12 - Re-create cdb_services, in case it hasn't been
Rem                           created during an upgrade.
Rem    nbenadja    06/21/12 - Handle CDB databases.
Rem    nbenadja    06/15/12 - Grant select_catalog_role to gsmadmin_internal.
Rem    sdball      06/07/12 - grant gv$instance to gsmadmin_internal
Rem    sdball      06/04/12 - Support for non-unique service name
Rem    sdball      06/04/12 - Defer DBMS_RLS calls to catalog creation because
Rem                           they require EE (Bug 14143065)
Rem    nbenadja    05/09/12 - Hande services in PDBs.
Rem    sdball      05/08/12 - Create verify objects
Rem    sdball      04/16/12 - dbms_lock_allocated is now dbms_lock_allocated_v2
Rem    sdball      03/26/12 - move PLB and SQL to correct installers
Rem    sdball      03/12/12 - Remove packages to corret install location
Rem                           Remove gsm_admin user
Rem                           Grant privs on DBMS_LOCK
Rem    sdball      02/22/12 - grant gsm_change_message only to
Rem                           gsmadmin_internal
Rem    sdball      01/04/12 - Refferential integrity checks
Rem    sdball      12/13/11 - Checking parameters
Rem    sdball      12/05/11 - change pooladmin_role to gsm_pooladmin_role
Rem    sdball      11/29/11 - Autovncr functionality
Rem    sdball      11/09/11 - Add gv_$lock for RAC
Rem    sdball      10/28/11 - gsmadmin_internal needs select on dba_locks
Rem    sdball      10/28/11 - gsmadmin_internal needs CREATE JOB privilege
Rem    sdball      10/25/11 - Add date field to gsm_requests
Rem    sdball      10/19/11 - use v_$ rather than gv_$ tables.
Rem                           add mastergsm field to cloud table
Rem    lenovak     08/22/11 - grant ALTER SYSTEM to gsm_admin_role
Rem    lenovak     07/22/11 - vncr support
Rem    mjstewar    07/21/11 - Change region_sequence
Rem    mjstewar    04/25/11 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

-- SET ECHO ON
-- SPOOL catgwmcat.log

prompt
prompt
prompt Starting Oracle GSM Catalog DB Installation ...
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
prompt

--*****************
-- Create GSM Roles
--*****************

----------------
-- gsmadmin_role
----------------

-- Create role for GSM cloud administrator
CREATE ROLE gsmadmin_role;
GRANT connect to gsmadmin_role;

GRANT execute on gsmadmin_internal.dbms_gsm_common to gsmadmin_role;

-----------------
-- gsm_pooladmin_role
-----------------

-- Create role GSM pool administrator
CREATE ROLE gsm_pooladmin_role;
GRANT connect to gsm_pooladmin_role;

GRANT execute on gsmadmin_internal.dbms_gsm_common to gsm_pooladmin_role;
/

-- Create gds_catalog_select role
CREATE ROLE gds_catalog_select;

--*****************
-- Create GSM Users
--*****************

--------------------
-- gsmadmin_internal
--------------------

-- gsmadmin_internal user exists on all databases,
-- but we need to give it some more privileges on the cloud
-- catalog database.

-- So that dbms_gsm_cloudadmin can execute dbms_aqadm.add_subscriber()
grant execute on dbms_aqadm to gsmadmin_internal;

-- So that dbms_gsm_cloudamdin can execute dbms_aq.enqueue()
grant execute on dbms_aq to gsmadmin_internal;

-- So that we can grab locks
grant execute on dbms_lock to gsmadmin_internal;
 
-- So that we can use alerts 
grant execute on  sys.dbms_server_alert to gsmadmin_internal;

-- So that we can create VPD policies in dbms_gsm_cloudadmin
grant execute on sys.dbms_rls to gsmadmin_internal;

-- So that dbms_gsm_cloudadmin can execute dbms_aqadm.purge_table()
grant aq_administrator_role to gsmadmin_role;

-- So the VPD routine can select from dba_role_privs
grant select on dba_role_privs to gsmadmin_internal;

-- So that dbms_gsm_utility can get current RDBMS version
grant select on v_$version to gsmadmin_internal;

-- So that dbms_gsm_cloudadmin can check if spfile is set.
grant select on v_$parameter to gsmadmin_internal;

-- so that we can check for GSM master lock
grant select on sys.dbms_lock_allocated to gsmadmin_internal;

-- so that we can check for GSM master lock
grant select on sys.gv_$lock to gsmadmin_internal;

-- for parameter checking
grant select on sys.dba_tab_columns to gsmadmin_internal;

-- so that we can check for CDB database 
grant select on sys.gv_$database to gsmadmin_internal;
-- so we can check running instances
grant select on sys.gv_$instance to gsmadmin_internal;

-- so we can find and kill service sessions
grant select on sys.gv_$session to gsmadmin_internal;
grant select on sys.v_$session to gsmadmin_internal;

-- Because we create sequences within the schema
grant create sequence to gsmadmin_internal;

-- So that we can assign users to the gsm_pooladmin_role
grant grant any role to gsmadmin_internal;

-- So that we can lock/unlock the gsmcatuser account
grant alter user to gsmadmin_internal;

-- So that gsm will be able to exec alter system register on catalog
grant alter system to gsmadmin_role;

-- Grant killing sessions to gsmadmin_internal (for import)
grant alter system to gsmadmin_internal;

-- so that we can crerate jobs
grant create job to gsmadmin_internal;

-- For CDB databases
grant select on sys.dba_services to gsmadmin_internal;
grant select on sys.cdb_services to gsmadmin_internal;

grant select on sys.gv_$active_services to gsmadmin_internal;


/
alter session set "_oracle_script"=true;

/
DECLARE
 isCDB varchar2(3);
 stmt  varchar (1024);

BEGIN

  select distinct CDB into isCDB from gv_$database;
  IF (isCDB = 'YES')
  THEN
     stmt := 'grant set container to gsmadmin_internal container = all';
     execute immediate stmt;
     stmt :=  'grant alter session to gsmadmin_internal container = all';
     execute immediate stmt;
     stmt := 'alter user gsmadmin_internal set container_data = all' ||
              '  for cdb_services container =current';
     execute immediate stmt;
     stmt := 'alter user gsmadmin_internal set container_data = all' ||
              '  for "PUBLIC".gv$active_services container =current';
     execute immediate stmt;
 END IF;

END;
/

-------------
-- gsmcatuser
-------------

-- GSM process connects to GSM cloud catalog database as
-- gsmcatuser.  Password will be changed by GSM when first
-- GSM is added to the cloud.

CREATE USER gsmcatuser identified by gsm
  account lock password expire;

GRANT connect to gsmcatuser;

-- So that gsmcatuser can call dbms_aq.dequeue(), dbms_aq.listen()
grant execute on dbms_aq to gsmcatuser;

-- So that gsmcatuser can call dbms_aqadm.add_subscriber()
grant aq_administrator_role to gsmcatuser;


ALTER SESSION SET CURRENT_SCHEMA = gsmadmin_internal;


--****************************
-- Create Cloud Catalog Tables
--****************************


CREATE TABLE region (
   name            VARCHAR2(30)   NOT NULL,
   num             NUMBER         NOT NULL,
   buddy_region    NUMBER         DEFAULT NULL REFERENCES region(num),
   change_state    CHAR(1) DEFAULT NULL,
   weights         VARCHAR(500) DEFAULT NULL,
   PRIMARY KEY (name),
   CONSTRAINT num_unique UNIQUE (num)
 )
/
show errors



-- region_sequence is used for generating region.num.
-- GSM listener requires that region.num be in the range 0-9
CREATE SEQUENCE region_sequence minvalue 0 maxvalue 9 cache 9 cycle
/
show errors

CREATE TABLE gsm (
   name            VARCHAR2(30)     NOT NULL,
   num             NUMBER           NOT NULL,
   endpoint1       VARCHAR2(256)    NOT NULL,
   endpoint2       VARCHAR2(256)    NOT NULL,
   ons_port_local  NUMBER           NOT NULL,
   ons_port_remote NUMBER           NOT NULL,
   region_num      NUMBER           NOT NULL REFERENCES region(num),
   oracle_home     VARCHAR2(4000),
   hostname        VARCHAR2(256),
   version         VARCHAR2(30)     DEFAULT NULL, --GSM version
   change_state    CHAR(1) DEFAULT NULL, 
   PRIMARY KEY (name)
 )
/
show errors

CREATE TABLE cloud (
   name               VARCHAR2(30)    NOT NULL,
   encryption_key     VARCHAR2(30),
   change_seq#        NUMBER,
   next_db_num        NUMBER,
   mastergsm          VARCHAR2(30) DEFAULT NULL REFERENCES gsm(name) ON DELETE SET NULL,
   autovncr           NUMBER(1) DEFAULT 1,   -- boolean (1 TRUE, 0 FALSE)
   max_instances      NUMBER DEFAULT NULL,
   private_key        RAW(2000)    DEFAULT NULL, -- PKI private key
   public_key         RAW(2000)    DEFAULT NULL, -- PKI public key
   prvk_enc_str       RAW(1000)    DEFAULT NULL, -- private key sig string 
   data_vers          VARCHAR2(30) DEFAULT NULL, -- Last update version
                                                 -- of catalog data
   PRIMARY KEY (name)
 )
/
show errors

CREATE TABLE vncr (
   name            VARCHAR2(256)   NOT NULL,
   group_id        VARCHAR2(30),
   PRIMARY KEY (name)
 )
/
show errors

CREATE SEQUENCE gsm_sequence
/
show errors

CREATE TABLE database_pool (
   name           VARCHAR2(30)    NOT NULL,
   broker_config  NUMBER(1),   -- boolean (1: TRUE, 0: FALSE)
   PRIMARY KEY (name)
 )
/
show errors

CREATE TABLE database_pool_admin (
   pool_name       VARCHAR2(30)    REFERENCES database_pool(name),
   user_name       VARCHAR2(30)    NOT NULL,  -- references "user" table
   PRIMARY KEY (pool_name, user_name)
 )
/
show errors

CREATE TABLE database (
   name                   VARCHAR2(30)    NOT NULL,
   pool_name              VARCHAR2(30)    REFERENCES database_pool(name),
   region_num             NUMBER          DEFAULT NULL REFERENCES region(num),
   gsm_password           VARCHAR2(30)    NOT NULL,
   connect_string         VARCHAR2(256)   NOT NULL,
   database_num           NUMBER          NOT NULL,
   status                 CHAR(1)         NOT NULL,  -- 'D': default
                                                     -- 'I': incomplete add
                                                     -- 'S': needs reSync
                                                     -- 'R': logically removed
   scan_address           VARCHAR2(256)   DEFAULT NULL,
   ons_port               NUMBER          DEFAULT NULL,
   num_assigned_instances NUMBER          NOT NULL,
   srlat_thresh           NUMBER          DEFAULT 20,  -- disk threshold
                                          -- Should be the same value as
                                          -- dbms_gsm_common.default_srlat_thresh
   cpu_thresh             NUMBER          DEFAULT 75,  -- cpu threshold
                                          -- Should be the same value as
                                          -- dbms_gsm_common.default_cpu_thresh 
   version                VARCHAR2(30)    DEFAULT NULL, -- database version
   db_type                CHAR(1)         DEFAULT NULL, -- 'N': Non RAC
                                                        -- 'A': Admin RAC
                                                        -- 'P': Policy RAC
                                                        -- 'U': Unknown
   encrypted_gsm_password RAW(2000)       DEFAULT NULL, -- enc gsm password
   PRIMARY KEY (name)
 )
/
show errors


CREATE TABLE service (
   name                       VARCHAR2(64)    NOT NULL,
   network_name               VARCHAR2(250)   NOT NULL,
   pool_name                  VARCHAR2(30)    REFERENCES database_pool(name),
   status                     CHAR(1),
                                -- 'S' (Started)
                                -- 'P' (Stopped)
   preferred_all              NUMBER(1),      
                                -- boolean (1 TRUE, 0 FALSE)
   locality                   NUMBER(1),      
                                -- anywhere (0), local_only (1)
   region_failover            NUMBER(1),      
                                -- boolean (1 TRUE, 0 FALSE)
   role                       NUMBER(1),      
                                -- primary (1), physical_standby (2), logical_standby (3)
   failover_primary           NUMBER(1),      
                                -- boolean (1 TRUE, 0 FALSE)
   any_lag                    NUMBER(1),      
                                -- boolean (1 TRUE, 0 FALSE)
   lag                        NUMBER,         
                                -- lag value if 'any_lag' is FALSE
   runtime_balance            NUMBER(1),      
                                -- none (0), service_time (1), throughput (2)
   load_balance               NUMBER(1),      
                                -- none (0), short (1), long (2)
   notification               NUMBER(1), 
                                -- boolean (1 TRUE, 0 FALSE)
   tafpolicy                  NUMBER(1),      
                                -- none (0), basic (1), preconnect (2)
   policy                     NUMBER(1),      
                                -- manual (1), automatic (2)
   dtp                        NUMBER(1),      
                                -- boolean (1 TRUE, O FALSE)
   failover_method            VARCHAR2(6),    
                                -- 'NONE' or 'BASIC'
   failover_type              VARCHAR2(12),    
                                -- 'NONE', 'SESSION', 'SELECT', or 'TRANSACTION'
   failover_retries           NUMBER,
   failover_delay             NUMBER,
   edition                    VARCHAR2(30),
   pdb                        VARCHAR2(30),
   commit_outcome             NUMBER,
                                -- boolean (1 TRUE, 0 FALSE)
   retention_timeout          NUMBER,
   replay_initiation_timeout  NUMBER,
   session_state_consistency  VARCHAR2(7),
                                -- 'STATIC' or 'DYNAMIC'
   sql_translation_profile    VARCHAR2(30),
   change_state               CHAR(1) DEFAULT NULL,
   PRIMARY KEY (name, pool_name)
 )
/
show errors

CREATE TABLE service_preferred_available (
   service_name    VARCHAR2(64),
   pool_name       VARCHAR2(30)  REFERENCES database_pool(name),
   database        VARCHAR2(30)  REFERENCES database(name),
   preferred       NUMBER(1),  -- (1 preferred, 0 available)
   status          CHAR(1) default NULL,
                               -- 'E' (Enabled)
                               -- 'D' (Disabled)
   state           CHAR(1) default 'S',
                               -- 'S' (Stopped)
                               -- 'D' (Down - stopped by user)
                               -- 'U' (Up and rUnning)
   dbparams        dbparams_list DEFAULT NULL, -- database specific parameters
   instances       instance_list DEFAULT NULL, -- list of preferred or
                                               -- available instances for
                                               -- admin managed clusters
                                               -- (not currently used)
   change_state    CHAR(1) DEFAULT NULL, 
   FOREIGN KEY (service_name, pool_name) REFERENCES service(name, pool_name),
   PRIMARY KEY (service_name, pool_name, database)
 )
  NESTED TABLE instances STORE AS instances_nt
/
show errors


CREATE TABLE gsm_requests (
   change_seq#    NUMBER,                            -- copied from request
   request        gsm_change_message NOT NULL,
   failure_count  NUMBER default 0,
   error_message  VARCHAR2(1024) default NULL,
   status         CHAR(1) default 'N',               -- values 'N', 'D', 'F','A'
   change_date    DATE default SYSDATE,
   old_instances  instance_list default NULL -- old instances for recovery
)
  NESTED TABLE old_instances STORE AS old_instances_nt
/
show errors

-- support for catalog rollbacks in the event of an aborted update
-- on a target database
CREATE OR REPLACE TRIGGER cat_rollback_trigger AFTER UPDATE OF status
    ON gsm_requests FOR EACH ROW WHEN (new.status = 'A') 
    CALL dbms_gsm_pooladmin.catRollback(:new.request, :new.old_instances)
/
show errors

-- support for catalog completion actions
CREATE OR REPLACE TRIGGER request_delete_trigger BEFORE DELETE ON gsm_requests
    FOR EACH ROW CALL dbms_gsm_pooladmin.requestDone(:old.request)
/
show errors

CREATE OR REPLACE TRIGGER done_trigger AFTER UPDATE OF status
    ON gsm_requests FOR EACH ROW WHEN (new.status = 'D')
    CALL dbms_gsm_pooladmin.requestDone(:old.request)
/
show errors

-- This a log off trigger that checks if a GSM is logging off from the catalog.
CREATE OR REPLACE TRIGGER GSMlogoff
                   BEFORE LOGOFF  ON gsmcatuser.schema
                   CALL dbms_gsm_cloudadmin.checkGSMDown
/
show errors


CREATE TABLE verify_history
              (run_number      NUMBER NOT NULL,
	          message_number  NUMBER NOT NULL,
              message_string  VARCHAR(1000),
              message_date    DATE NOT NULL)
/
show errors

GRANT SELECT on verify_history TO gsmadmin_role;
/
show errors

CREATE SEQUENCE verify_run_number
/
show errors

-------------------------
-- Create AQ Change Queue
-------------------------
DECLARE
  stmt  VARCHAR2(500);
BEGIN
    stmt := 'GRANT SELECT ON aq$_unflushed_dequeues to ' || 'gsmadmin_internal';
    EXECUTE IMMEDIATE stmt;

    dbms_aqadm.create_queue_table(
        queue_table => 'gsmadmin_internal.change_log_queue_table',
        multiple_consumers => TRUE,
        queue_payload_type => 'gsmadmin_internal.gsm_change_message',
        storage_clause => 'TABLESPACE "SYSAUX"',
        comment => 'Creating GSM change log queue table');

    dbms_aqadm.create_queue(
        queue_name => 'gsmadmin_internal.change_log_queue',
        queue_table => 'gsmadmin_internal.change_log_queue_table',
        comment => 'GSM Change Log Queue');
EXCEPTION
WHEN others THEN
  IF sqlcode = -24001 THEN NULL;
       -- suppress error for pre-existent queue table
  ELSE raise;
  END IF;
END;
/
show errors

-- This can only be done by the queue owner (gsmadmin_internal) or
-- SYS.  
BEGIN
  dbms_aqadm.grant_queue_privilege(
     privilege => 'dequeue',
     queue_name => 'gsmadmin_internal.change_log_queue',
     grantee => 'GSMCATUSER');
END;
/
show errors

BEGIN
  dbms_aqadm.grant_queue_privilege(
     privilege => 'enqueue',
     queue_name => 'gsmadmin_internal.change_log_queue',
     grantee => 'GSMADMIN_INTERNAL');
END;
/
show errors

BEGIN
   dbms_aqadm.start_queue('gsmadmin_internal.change_log_queue', 
                          TRUE, 
                          TRUE);
END;
/
show errors

----------------------------------
-- Grant resolve network privilege
----------------------------------

BEGIN
  dbms_network_acl_admin.append_host_ace(
    host => '*',
    ace => xs$ace_type(privilege_list => xs$name_list('RESOLVE'),  
                       principal_name => 'GSMADMIN_INTERNAL',  
                       principal_type => xs_acl.ptype_db));
END;
/
show errors

-----------------------
-- Set Table Privileges
-----------------------

GRANT select on cloud to gsmadmin_role, gds_catalog_select;
GRANT select on region to gsmadmin_role, gds_catalog_select;
GRANT select on gsm to gsmadmin_role, gds_catalog_select;
GRANT select on vncr to gsmadmin_role, gds_catalog_select;
GRANT select on database_pool to gsmadmin_role, gds_catalog_select;
GRANT select on database_pool_admin to gsmadmin_role, gds_catalog_select;
GRANT select on gsm_requests to gsmadmin_role, gds_catalog_select;

GRANT select on database to gsmadmin_role, gds_catalog_select;
GRANT select on service to gsmadmin_role, gds_catalog_select;
GRANT select on service_preferred_available to gsmadmin_role, gds_catalog_select;

-- Import catalog permissions.
GRANT insert on vncr to gsmadmin_role;
GRANT update on cloud to gsmadmin_role;
GRANT insert,update on region to gsmadmin_role;
GRANT insert on gsm to gsmadmin_role;

GRANT insert on database to gsmadmin_role;
GRANT insert on database_pool to gsmadmin_role;
GRANT insert on database_pool_admin to gsmadmin_role;
GRANT insert on service to gsmadmin_role;
GRANT insert on service_preferred_available to gsmadmin_role;
-- End import catalog permissions

GRANT select on database_pool to gsm_pooladmin_role;
GRANT select on database to gsm_pooladmin_role;
GRANT select on cloud to gsm_pooladmin_role;
GRANT select on service to gsm_pooladmin_role;
GRANT select on service_preferred_available to gsm_pooladmin_role;
GRANT select on gsm_requests to gsm_pooladmin_role;

-- Pool admin has to see regions in order to know which regions
-- to which to add databases.
GRANT select on region to gsm_pooladmin_role;

-- set type privs (so that GDSCTL can select types from tables)
GRANT execute on gsmadmin_internal.gsm_change_message to gsmadmin_role;
GRANT execute on gsmadmin_internal.dbparams_t to gsmadmin_role,
                                                 gsm_pooladmin_role;
GRANT execute on gsmadmin_internal.dbparams_list to gsmadmin_role,
                                                    gsm_pooladmin_role;
GRANT execute on gsmadmin_internal.rac_instance_t to gsmadmin_role,
                                                     gsm_pooladmin_role;
GRANT execute on gsmadmin_internal.instance_list to gsmadmin_role,
                                                    gsm_pooladmin_role;



GRANT update,delete on gsm_requests to gsm_pooladmin_role, gsmadmin_role;
GRANT update on service_preferred_available to gsmcatuser;
GRANT update on database to gsmcatuser;

GRANT gsmadmin_role, gsm_pooladmin_role to gsmcatuser;



ALTER SESSION SET CURRENT_SCHEMA = SYS;


@?/rdbms/admin/sqlsessend.sql
