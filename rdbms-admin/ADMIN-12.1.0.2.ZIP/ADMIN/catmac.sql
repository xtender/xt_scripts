Rem
Rem Copyright (c) 2004, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catmac.sql - Install mandatory access control configuration schema and packages.
Rem
Rem    DESCRIPTION
Rem      This is the main install script for installing the database objects
Rem      required for Oracle Database vault.
Rem
Rem    NOTES
Rem      Must be run as SYSDBA and requires that passwords be specified for
Rem      SYSDBA, DV_OWNER and DV_ACCOUNT_MANAGER
Rem
Rem        Parameter 1 = account default tablespace
Rem        Parameter 2 = account temp tablespace
Rem        Parameter 3 = SYS password
Rem
Rem
Rem BEGIN SQL_FILE_METADATA
Rem SQL_SOURCE_FILE: rdbms/admin/catmac.sql
Rem SQL_SHIPPED_FILE: rdbms/admin/catmac.sql
Rem SQL_PHASE: CATMAC
Rem SQL_STARTUP_MODE: NORMAL
Rem SQL_IGNORABLE_ERRORS: NONE
Rem SQL_CALLING_FILE: NONE 
Rem END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    apfwkr      05/20/14 - Backport aketkar_bug-18331292 from main
Rem    aketkar     04/29/14 - sql patch metadata seed
Rem    sanbhara    07/09/13 - Bug 16704912 - adding calls to sqlsessstart.sql
Rem                           and sqlsessend.sql instead of directly modifying
Rem                           _oracle_script parameter.
Rem    sankejai    10/12/11 - set _oracle_script=TRUE
Rem    jaeblee     08/26/11 - 12914214: remove connects
Rem    sanbhara    07/28/11 - Project 24121 - move DV_ADMIN_DIR creation to
Rem                           dbms_macadm.add_nls_data.
Rem    sanbhara    05/24/11 - Project 24121 - remove parameters 4-7 for
Rem                           dv_owner and dv_acctmgr.
Rem    sankejai    04/11/11 - set _oracle_script in session after connect
Rem    sanbhara   01/31/11 - Bug Fix 10225918.
Rem    srtata     03/17/09 - removed OLS logon trigger
Rem    jsamuel    01/12/09 - call catmaca audit statements for DV
Rem    jsamuel    09/30/08 - passwordless patching and simplify catmac
Rem    youyang    09/18/08 - Bug 6739582: DBCA failes when use dot for
Rem                          dvowner's password
Rem    pknaggs    04/20/08 - bug 6938028: Database Vault Protected Schema.
Rem    pknaggs    06/20/07 - 6141884: backout fix for bug 5716741.
Rem    pknaggs    05/29/07 - 5716741: sysdba can't do account management.
Rem    ruparame   02/22/07 - Adding Network IP privileges to DVSYS
Rem    ruparame   02/20/07 - 
Rem    ruparame   01/20/07 - DV/ DBCA Integration
Rem    ruparame   01/13/07 - DV/DBCA Integration
Rem    ruparame   01/10/07 - DV/DBCA Integration
Rem    mxu        01/26/07 - Fix error
Rem    rvissapr   12/01/06 - add validate_dv
Rem    jciminsk   05/02/06 - catmacp.plb to prvtmacp.plb, to cleanup naming 
Rem    jciminsk   05/02/06 - created admin/catmac.sql 
Rem    jciminsk   05/02/06 - created admin/catmac.sql 
Rem    tchorma    02/04/06 - Disable LBACSYS triggers before performing 
Rem                          installation 
Rem    sgaetjen   11/10/05 - add exit to end of script for options install 
Rem    sgaetjen   08/19/05 - Comment out OLS recompile 
Rem    sgaetjen   08/18/05 - Refactor for OUI 
Rem    sgaetjen   08/11/05 - sgaetjen_dvschema
Rem    sgaetjen   08/10/05 - OLS init check 
Rem    sgaetjen   08/03/05 - correct comments 
Rem    sgaetjen   08/03/05 - corrected parameter for sys password 
Rem    sgaetjen   08/03/05 - need to supply password for SYS now 
Rem    sgaetjen   08/02/05 - add DVF package body compile 
Rem    sgaetjen   07/30/05 - separate DVSYS and SYS commands 
Rem    sgaetjen   07/28/05 - dos2unix
Rem    sgaetjen   07/25/05 - Created.

WHENEVER SQLERROR CONTINUE;

@@?/rdbms/admin/sqlsessstart.sql

-- Disable the rest of the OLS triggers before DV install
ALTER TRIGGER LBACSYS.lbac$before_alter DISABLE;
ALTER TRIGGER LBACSYS.lbac$after_create DISABLE;
ALTER TRIGGER LBACSYS.lbac$after_drop   DISABLE;

-- bug 6938028: Database Vault Protected Schema.
-- Insert the rows into metaview$ for the real Data Pump types.
@@catmacdd.sql

-- Create the DV accounts
@@catmacs.sql &1 &2 

-- Load MACSEC Factor Convenience Functions
@@dvmacfnc.plb

-- Load underlying DVSYS objects
@@catmacc.sql

-- Load MAC packages.
@@catmacp.sql
@@prvtmacp.plb

-- tracing view
-- grants on DV objects to DV roles
-- create public synonyms for DV objects
@@catmacg.sql

-- Load MAC roles.
@@catmacr.sql

-- Load MAC seed data. Load NLS seed data from catmacd.sql - Bug Fix 10225918.
@@catmacd.sql

-- create the DV login 
@@catmact.sql

-- establish DV audit policy
@@catmaca.sql

--Removes privleges from the DVSYS and DVF accounts
--used during the install
@@catmach.sql

-- Other installation steps
-- Create DV owner and DV account manager accounts 
@@catmacpre.sql "&3"

commit;

@?/rdbms/admin/sqlsessend.sql

