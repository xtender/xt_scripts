Rem
Rem $Header: rdbms/admin/catmacpre.sql /st_rdbms_12.1/1 2014/06/03 11:24:49 aketkar Exp $
Rem
Rem catmacpre.sql
Rem
Rem Copyright (c) 2007, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catmacpre.sql - Creates DV Account Manager Account
Rem
Rem    DESCRIPTION
Rem      This script is called at the end of catmac script and creates the
Rem       DV account manager.
Rem
Rem    NOTES
Rem      Must be run as SYSDBA 
Rem
Rem        Parameter 1 = SYS password
Rem
Rem BEGIN SQL_FILE_METADATA
Rem SQL_SOURCE_FILE: rdbms/admin/catmacpre.sql
Rem SQL_SHIPPED_FILE: rdbms/admin/catmacpre.sql
Rem SQL_PHASE: CATMACPRE
Rem SQL_STARTUP_MODE: NORMAL
Rem SQL_IGNORABLE_ERRORS: NONE
Rem SQL_CALLING_FILE: rdbms/admin/catmac.sql
Rem END SQL_FILE_METADATA
Rem
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    apfwkr      05/20/14 - Backport aketkar_bug-18331292 from main
Rem    aketkar     04/29/14 - sql patch metadata seed
Rem    sanbhara    02/27/12 - Bug 13699578 fix.
Rem    jaeblee     08/26/11 - 12914214: remove connects
Rem    sanbhara    08/11/11 - Project 24121 - removing call to
Rem                           update_command_rule since these are already
Rem                           enabled when rows are created in catmacd.sql.
Rem    sanbhara    05/02/11 - Project 24121 - move DV configuration out of
Rem                           catmac.
Rem    sankejai    04/11/11 - set _oracle_script in session after connect
Rem    jsamuel     09/24/08 - passwordless patching
Rem    pknaggs     06/20/07 - 6141884: backout fix for bug 5716741.
Rem    pknaggs     05/31/07 - 5716741: sysdba can't do account management.
Rem    ruparame    05/18/07 - Make DV account manager optional
Rem    ruparame    01/13/07 - DV/DBCA Integration
Rem    ruparame    01/10/07 - DV/DBCA Integration
Rem    ruparame    01/10/07 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

SET ECHO ON
SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 80
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

--from catmacpost.sql
GRANT DV_MONITOR to DBSNMP;

GRANT DV_ADMIN to SYS;

begin
  dbms_macadm.authorize_scheduler_user('SYS', 'EXFSYS');
exception when others then
  -- Ignore the error if EXFSYS is not created.
  if SQLCODE in (-47324, -47951, -29504) then 
    null;
  else 
    raise;
  end if;
end;
/

REVOKE DV_ADMIN from SYS;

ALTER USER dvsys ACCOUNT LOCK PASSWORD EXPIRE
/


DECLARE
    num number;
BEGIN
    dbms_registry.loaded('DV');
    SYS.validate_dv;
END;
/
commit;


@?/rdbms/admin/sqlsessend.sql

