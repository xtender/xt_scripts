Rem
Rem $Header: rdbms/admin/catnowrrwitb.sql /main/1 2011/08/01 12:54:31 kmorfoni Exp $
Rem
Rem catnowrrwitb.sql
Rem
Rem Copyright (c) 2011, Oracle and/or its affiliates. All rights reserved. 
Rem
Rem    NAME
Rem      catnowrrwitb.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    kmorfoni    06/24/11 - Created
Rem

Rem =========================================================
Rem Dropping the Workload Intelligence Tables
Rem =========================================================
Rem

drop table WI$_FREQUENT_PATTERN_METADATA
/

drop table WI$_FREQUENT_PATTERN_ITEM
/

drop table WI$_FREQUENT_PATTERN
/

drop table WI$_EXECUTION_ORDER
/

drop table WI$_CAPTURE_FILE
/

drop table WI$_STATEMENT
/

drop table WI$_OBJECT
/

drop table WI$_TEMPLATE
/

drop table WI$_JOB
/

drop sequence WI$_JOB_ID
/
