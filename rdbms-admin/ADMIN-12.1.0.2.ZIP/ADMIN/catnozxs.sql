Rem
Rem $Header: rdbms/admin/catnozxs.sql /main/6 2012/10/30 10:50:12 minx Exp $
Rem
Rem catnozxs.sql
Rem
Rem Copyright (c) 2009, 2012, Oracle and/or its affiliates. 
Rem All rights reserved. 
Rem
Rem    NAME
Rem      catnozxs.sql - for removing (NO) XS
Rem
Rem    DESCRIPTION
Rem      This script is invoked at the beginning of catnoqm.sql
Rem
Rem    NOTES
Rem      Schema tables are deleted in catnoqm.sql. All objects are under 'SYS'
Rem      unless qualified with a different schema.
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    minx        10/25/12 - deprecated
Rem    minx        03/25/12 - XS Cleanup
Rem    rpang       02/02/12 - Network ACL triton migration
Rem    yiru        05/09/10 - Full Drop6R cleanup before merge-down
Rem    snadhika    04/14/10 - Remove PREDICATE xmlindex
Rem    yiru        03/25/09 - Created
Rem
