Rem
Rem $Header: rdbms/admin/catolsrecomp.sql /main/1 2012/12/11 23:22:49 risgupta Exp $
Rem
Rem catolsrecomp.sql
Rem
Rem Copyright (c) 2012, Oracle and/or its affiliates. All rights reserved. 
Rem
Rem    NAME
Rem      catolsrecomp.sql - Recompiles conflicting OLS objects.
Rem
Rem    DESCRIPTION
Rem      This script recompiles conflicting OLS views, functions and 
Rem      synonyms after a PDB with incompatible OLS configuration is plugged.
Rem
Rem    NOTES
Rem      This script is used to resolve conflicts when a PDB with incompatible 
Rem      Label Security configuration is plugged in a consolidated DB. This
Rem      recompiles all the conflicting objects i.e views, synonyms and functions
Rem      to match that of the consolidated DB.
Rem
Rem      Must be run using catcon.pl as SYSDBA.
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    risgupta    10/18/12 - Created
Rem

SET ECHO ON
SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 80
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

COLUMN :file_name NEW_VALUE comp_file NOPRINT
VARIABLE file_name VARCHAR2(20)

DECLARE
oid BOOLEAN := FALSE;
BEGIN
  -- Get OID configuration status in Root.
  oid := lbacsys.lbac_cache.is_oid_configured;

  IF (oid = FALSE) THEN
    :file_name := 'prvtolsstnd.plb';
  ELSE
    :file_name := 'prvtolsldap.plb';
  END IF;
END;
/

SELECT :file_name FROM DUAL;
@@&comp_file
