Rem
Rem $Header: rdbms/admin/catprofp.sql /main/7 2014/02/20 12:45:44 surman Exp $
Rem
Rem catprofp.sql
Rem
Rem Copyright (c) 2010, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catprofp.sql - privilege capture package header
Rem
Rem    DESCRIPTION
Rem      Package sys.dbms_privilege_capture header
Rem      Package sys.dbms_priv_capture header
Rem
Rem    NOTES
Rem      Run in catpdbms.sql; 
Rem      package bodies are defined in prvtpprof.sql(run in catpprvt.sql).
Rem
Rem
Rem BEGIN SQL_FILE_METADATA
Rem SQL_SOURCE_FILE: rdbms/admin/catprofp.sql
Rem SQL_SHIPPED_FILE: rdbms/admin/catprofp.sql
Rem SQL_PHASE: CATPROFP
Rem SQL_STARTUP_MODE: NORMAL
Rem SQL_IGNORABLE_ERRORS: NONE
Rem SQL_CALLING_FILE: rdbms/admin/catpdbms.sql
Rem END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    surman      12/29/13 - 13922626: Update SQL metadata
Rem    jheng       07/31/13 - Bug 17251375: add extra privilege check funcs
Rem    surman      03/27/12 - 13615447: Add SQL patching tags
Rem    jheng       12/01/11 - Change API names
Rem    jheng       10/11/11 - lrg 5949112
Rem    jheng       06/17/11 - Add privilege capture functions for PL/SQL
Rem                           packages
Rem    jheng       04/09/10 - API to administrate privilege capture
Rem    jheng       04/09/10 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

CREATE OR REPLACE PACKAGE sys.dbms_privilege_capture AS
 -- Capture Types
  g_database            CONSTANT NUMBER := 1;
  g_role                CONSTANT NUMBER := 2;
  g_context             CONSTANT NUMBER := 3;
  g_role_and_context    CONSTANT NUMBER := 4;

  
  PROCEDURE create_capture(
    name            IN  VARCHAR2,
    description     IN  VARCHAR2 DEFAULT NULL, 
    type            IN  NUMBER DEFAULT G_DATABASE,
    roles           IN  role_name_list DEFAULT role_name_list(),
    condition       IN  VARCHAR2   DEFAULT NULL);

  PROCEDURE drop_capture(name  IN VARCHAR2);

  PROCEDURE enable_capture(name  IN VARCHAR2);

  PROCEDURE disable_capture(name IN VARCHAR2);
  
  PROCEDURE generate_result(name IN VARCHAR2);

END;
/

show errors;

CREATE OR REPLACE PUBLIC SYNONYM dbms_privilege_capture FOR sys.dbms_privilege_capture;
CREATE OR REPLACE PUBLIC SYNONYM g_database for dbms_privilege_capture.g_database;
CREATE OR REPLACE PUBLIC SYNONYM g_role for dbms_privilege_capture.g_role;
CREATE OR REPLACE PUBLIC SYNONYM g_context for dbms_privilege_capture.g_context;
CREATE OR REPLACE PUBLIC SYNONYM g_role_and_context for dbms_privilege_capture.g_role_and_context;

GRANT execute on dbms_privilege_capture to capture_admin;

/**
* Package dbms_priv_capture is defined as invoker right's  API.
* Procedures and functions with package dbms_priv_capture are intended to 
* capture a privilege use in Oracle defined PL/SQL packages..
*
* The purpose of this project #32973 is to capture privileges used for an 
* operation. Privileges checked in the kernel(e.g, through KZP layer) have 
* been collected.
*
* However, many Oracle defined PL/SQL packages query privilege related 
* dictionary tables/views(for example, session_privs, 
* session_roles, sysauth$, objauth$, etc.) to check whether a user has a given
* privilege. For such cases, APIs in this package have been used to replace 
* orginal check. For queries that cannot be replaced, privileges are collected
* directly by calling dbms_priv_capture.capture_privilege_use.
*
* In the future, if you need to do privilege checks in PL/SQL. Please
* use the functions defined in this package. Please choose the right functions
* from the following based on your needs:
* ses_has_sys_priv: whether the current user has a given system privilege
* ses_has_role_priv: whether the current user has a given role
* has_sys_priv: whether the given input user as a given system privilege
* has_obj_priv: whether the given input user has a given object privilege
* has_sys_priv_direct: whether the given input user as a direct granted
*                      system privilege
*
* If none of the above privilege check functions satisfy your needs, please 
* contact the file owner and file backup.
*
* Note: when you use dbms_priv_capture APIs in your pacakge, procedure or 
*       function, you need to "grant execute on dbms_priv_capture" to package,
*       procedure, or function owner, unless the owner is SYS.
**/
CREATE OR REPLACE PACKAGE sys.dbms_priv_capture AUTHID CURRENT_USER
AS

/**
* Procedure to capture a privilege usage, if a privilege capture conditions
* are met. This procedure is called when a privilege is used in PL/SQL and JAVA.
*
* @param userid  ID of the user having the privilege
* @param syspriv ID of the system privilege used
* @param role    Name of the role used
* @param objpriv ID of the object privilege used
* @param obj     ID of the object accessed
* @param domain   List of role IDs used to check privilege use (i.e. domain)
* @param domain_str List of role names used to check privilege use
*/
  PROCEDURE capture_privilege_use(
    userid    IN  NUMBER,
    syspriv   IN  NUMBER DEFAULT NULL,
    role      IN  VARCHAR2 DEFAULT NULL,
    objpriv   IN  NUMBER DEFAULT NULL,
    obj       IN  NUMBER DEFAULT NULL,
    domain    IN  role_array DEFAULT NULL,
    domain_str IN  rolename_array DEFAULT NULL);

/**
* Procedure to capture a privilege usage, if a privilege capture conditions
* are met. This procedure is called when a privilege is used in PL/SQL and JAVA.
*
* Note: it does the same thing with the above procedure,except the input 
* parameters are strings for user's convenience.
*
* @param username Name of the user having the privilege
* @param syspriv  Name of the system privilege used
* @param role     Name of the role used
* @param objpriv  Name of the object privilege used
* @param owner    Name of the object owner
* @param object   Name of the object accessed
* @param domain   Security domain (id) used to check privilege use
* @param domain_str Security domain with names
*/
  PROCEDURE capture_privilege_use(
    username  IN  VARCHAR2,
    syspriv   IN  VARCHAR2 DEFAULT NULL,
    role      IN  VARCHAR2 DEFAULT NULL,
    objpriv   IN  VARCHAR2 DEFAULT NULL,
    owner     IN  VARCHAR2 DEFAULT NULL,
    object    IN  VARCHAR2 DEFAULT NULL,
    domain     IN  role_array DEFAULT NULL,
    domain_str IN  rolename_array DEFAULT NULL);

/**
* Function to check whether the given user has a directly granted system
* privilege. If a capture is turned on, capture the privilege usage.
*
* @param userid     ID of the user checked against
* @param syspriv    ID of the system privilege to check (should be a negative
*                   number from system_privilege_map)
*
* Return 1 if privielge exists, 0 otherwise.
* Note: this function only checks for a direct granted system privilege.
*/
  FUNCTION HAS_SYS_PRIV_DIRECT_ID(
    userid     IN NUMBER,
    syspriv    IN NUMBER) RETURN NUMBER;

/**
* Function to check whether the given user has a directly granted system
* privilege. If a capture is turned on, capture the privilege usage.
*
* This function does the same with the above function, except that it accpets
* inputs as strings for caller's convenience.
*
* @param username   Name of the user checked against
* @param syspriv    Name of the system privilege to check
*
* Return 1 if privielge exists, 0 otherwise.
* Note: this function only checks for a direct granted system privilege.
*/
  FUNCTION HAS_SYS_PRIV_DIRECT(
    username     IN VARCHAR2,
    syspriv      IN VARCHAR2) RETURN NUMBER;

/**
* Function to check whether the given user has a given system
* privilege. If a capture is turned on, capture the privilege usage.
*
* @param userid   ID of the user checked against
* @param syspriv  ID of the system privilege to check (should be a valid
*                 negative number exisiting in system_privilege_map)
* @param usepublic whether privileges granted to public are included
*
* Return 1 if privielge exists, 0 otherwise.
*
* Note: this function checks both privileges directly granted to "userid"
* and privileges indirectly granted to one of the roles "userid" has.
* If usepublic=TRUE, privileges directly and indirectly granted to PUBLIC
* will also be checked.
*/
  FUNCTION HAS_SYS_PRIV_ID(
    userid     IN NUMBER,
    syspriv    IN NUMBER,
    usepublic  IN BOOLEAN DEFAULT TRUE) RETURN NUMBER;

/**
* Function to check whether the given user has a given system
* privilege. If a capture is turned on, capture the privilege usage.
*
* This function does the same with the above function, except that it accpets
* inputs as strings for caller's convenience.
*
* @param username   Name of the user checked against
* @param syspriv    Name of the system privilege to check
* @param usepublic  whether privileges granted to public are included
*
* Return 1 if privielge exists, 0 otherwise.
* Note: this function checks both privileges directly granted to "username"
* and privileges indirectly granted to one of the roles "username" has.
* If usepublic=TRUE, privileges directly and indirectly granted to PUBLIC
* will also be checked.
*/
  FUNCTION HAS_SYS_PRIV(
    username     IN VARCHAR2,
    syspriv      IN VARCHAR2,
    usepublic    IN BOOLEAN DEFAULT TRUE) RETURN NUMBER;

/**
* Function to check whether the given user has a given object privilege
* If a capture is turned on, capture the privilege usage.
*
* @param l_user  ID of the user checked against
* @param l_priv  ID of the object privilege to check
* @param l_obj   ID of the object
* @param usepublic whether privileges granted to public are included
*
* Return 1 if privielge exists, 0 otherwise.
* Note: this function checks both privileges directly granted to "l_user"
* and privileges indirectly granted to one of the roles "l_user" has.
* If usepublic=TRUE, privileges directly and indirectly granted to PUBLIC
* will also be checked.
*/
  FUNCTION HAS_OBJ_PRIV_ID(
    l_user         IN NUMBER,
    l_priv         IN NUMBER,
    l_obj          IN NUMBER,
    usepublic      IN BOOLEAN DEFAULT TRUE) RETURN NUMBER;

/**
* Function to check whether the given user has a given object privilege
* If a capture is turned on, capture the privilege usage.
*
* This function does the same with the above function, except that it accpets
* inputs as strings for caller's convenience.
*
* @param username   Name of the user checked against
* @param objpriv    Name of the object privilege to check
* @param objowner   Name of the object owner
* @param objname    Name of the object
* @param usepublic  whether privileges granted to public are included
* @param nmspace    Namespace of the object (default is 1 TABLE namespace)
*
* Note: caller of this function must have SELECT access on sys.obj$, sys.user$
*      
* Return 1 if privielge exists,  0 otherwise.
* Note: this function checks both privileges directly granted to "username"
* and privileges indirectly granted to one of the roles "username" has.
* If usepublic=TRUE, privileges directly and indirectly granted to PUBLIC
* will also be checked.
*/
  FUNCTION HAS_OBJ_PRIV(
    username     IN VARCHAR2,
    objpriv      IN VARCHAR2,
    objowner     IN VARCHAR2,
    objname      IN VARCHAR2,
    usepublic    IN BOOLEAN DEFAULT TRUE,
    nmspace      IN NUMBER DEFAULT 1) RETURN NUMBER;

/**
* Function to check whether the given user has a directly granted object 
* privilege. If a capture is turned on, capture the privilege usage.
*
* @param l_user  ID of the user checked against
* @param l_priv  ID of the object privilege to check
* @param l_obj   ID of the object
*
* Return 1 if privielge exists, 0 otherwise.
* Note: this function only checks privileges directly granted to "l_user"
*/
  FUNCTION HAS_OBJ_PRIV_DIRECT_ID(
    l_user         IN NUMBER,
    l_priv         IN NUMBER,
    l_obj          IN NUMBER) RETURN NUMBER;


/**
* Function to check whether the given user has a directly granted object
* privilege. If a capture is turned on, capture the privilege usage.
*
* This function does the same with the above function, except that it accpets
* inputs as strings for caller's convenience.
*
* @param username   Name of the user checked against
* @param objpriv    Name of the object privilege to check
* @param objowner   Name of the object owner
* @param objname    Name of the object
* @param nmspace    Namespace of the object (default is 1 TABLE namespace)
*
* Note: caller of this function must have SELECT access on sys.obj$, sys.user$
*      
* Return 1 if privielge exists,  0 otherwise.
* Note: this function check only privileges directly granted to "username".
*/
  FUNCTION HAS_OBJ_PRIV_DIRECT(
    username     IN VARCHAR2,
    objpriv      IN VARCHAR2,
    objowner     IN VARCHAR2,
    objname      IN VARCHAR2,
    nmspace      IN NUMBER DEFAULT 1) RETURN NUMBER;

/**
* Function to check whether the given user has a given role.
* If a capture is turned on, capture the role usage.
*
* @param userid   ID of the user checked against
* @param roleid   ID of the role to check
* @param usepublic whether roles granted to public are included
*
* Return 1 if role exists, 0 otherwise.
*
* Note: this function checks both roles directly granted to "userid"
* and roles indirectly granted to one of the roles "userid" has.
* If usepublic=TRUE, roles directly and indirectly granted to PUBLIC
* will also be checked.
*/
  FUNCTION HAS_ROLE_PRIV_ID(
    userid     IN NUMBER,
    roleid     IN NUMBER,
    usepublic  IN BOOLEAN DEFAULT TRUE) RETURN NUMBER;

/**
* Function to check whether the specified role is granted to the
* given user either directly or recursively. 
* If a capture is turned on, capture the role usage.
*
* @param username   Name of the user checked against
* @param rolename   Name of the role to check
* @param usepublic whether roles granted to public are included
*
* Return 1 if role exists, 0 otherwise.
*
* Note: this function performs the same check with HAS_ROLE_PRIV_ID, except
* it accepts username and rolename as strings.
*/
  FUNCTION HAS_ROLE_PRIV(
    username   IN VARCHAR2,
    rolename   IN VARCHAR2,
    usepublic  IN BOOLEAN DEFAULT TRUE) RETURN NUMBER;

/**
* Function to check whether the given user has a directly granted role. 
* If a capture is turned on, capture the privilege usage.
*
* @param userid   ID of the user checked against
* @param roleid   ID of the role to check
*
* Return 1 if role is granted to user, 0 otherwise.
* Note: this function only checks for a direct granted role to user.
*/
  FUNCTION HAS_ROLE_PRIV_DIRECT_ID(
    userid    IN NUMBER,
    roleid    IN NUMBER) RETURN NUMBER;

/**
* Function to check whether the given user has a directly granted role. 
* If a capture is turned on, capture the privilege usage.
* This funcation does the same with HAS_ROLE_PRIV_DIRECT_ID, except it 
* accepts username and rolename as strings.
*
* @param username   Name of the user checked against
* @param rolename   Name of the role to check
*
* Return 1 if role is granted to user, 0 otherwise.
* Note: this function only checks for a direct granted role to user.
*/
  FUNCTION HAS_ROLE_PRIV_DIRECT(
    username     IN VARCHAR2,
    rolename     IN VARCHAR2) RETURN NUMBER;

/**
* Function to check whether the session user has s given system privilege.
* If a capture is turned on, capture the privilege usage.
*
* @param syspriv  Name of the system privilege to check
*
* Return 1 if privielge exists, 0 otherwise.
* Note: this function is a wrapper for "SELECT from session_privs". 
*/
  FUNCTION SES_HAS_SYS_PRIV(systempriv IN VARCHAR2) RETURN NUMBER;

/**
* Function to check whether the session user has s given role.
* If a capture is turned on, capture the privilege usage.
*
* @param role  Name of the role to check
*
* Return 1 if privielge exists, 0 otherwise.
* Note: this function is a wrapper for "SELECT from session_roles". 
*/
  FUNCTION SES_HAS_ROLE_PRIV(rolename IN VARCHAR2) RETURN NUMBER;
END;
/


show errors;

CREATE OR REPLACE PUBLIC SYNONYM dbms_priv_capture FOR sys.dbms_priv_capture;

@?/rdbms/admin/sqlsessend.sql
