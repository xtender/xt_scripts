Rem
Rem $Header: rdbms/admin/catpvf.sql /main/3 2014/02/20 21:08:33 himagarw Exp $
Rem
Rem catpvf.sql
Rem
Rem Copyright (c) 2013, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catpvf.sql - Create Password Verify Function, STIG profile 
Rem
Rem    DESCRIPTION
Rem      Creates the password verify functions and their dependent functions.
Rem      This script also creates the STIG compliant user profile
Rem
Rem    NOTES
Rem       STIG profile is created with container = current which means it is 
Rem       a local object. But exception is made in PDB code similar to the 
Rem       DEFAULT profile to make sure the STIG profile is created in every 
Rem       container during DB creation time. 
Rem       
Rem       The password verify functions and their dependent functions are moved 
Rem       from utlpwdmg.sql script
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    himagarw    02/13/14 - Bug #18237713: Raise exception if source or
Rem                           target string is longer than 128 bytes
Rem    surman      12/29/13 - 13922626: Update SQL metadata
Rem    jkati       10/24/13 - bug#17543726 : Create password verify functions
Rem                           and STIG profile
Rem    jkati       10/24/13 - Created
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/admin/catpvf.sql 
Rem    SQL_SHIPPED_FILE: rdbms/admin/catpvf.sql 
Rem    SQL_PHASE: CATPVF
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: rdbms/admin/catptabs.sql
Rem    END SQL_FILE_METADATA

@@?/rdbms/admin/sqlsessstart.sql

Rem  Function: "ora_complexity_check" - Verifies the complexity
Rem            of a password string.
Rem
Rem  If not null, each of the following parameters specifies the minimum
Rem  number of characters of the corresponding type.
Rem  chars   -  All characters (i.e. string length)
Rem  letter  -  Alphabetic characters A-Z and a-z
Rem  upper   -  Uppercase letters A-Z
Rem  lower   -  Lowercase letters a-z
Rem  digit   -  Numeric characters 0-9
Rem  special -  All characters not in A-Z, a-z, 0-9 except double quote
Rem             which is a password delimiter

create or replace function ora_complexity_check
(password varchar2,
 chars integer := null,
 letter integer := null,
 upper integer := null,
 lower integer := null,
 digit integer := null,
 special integer := null)
return boolean is
   digit_array varchar2(10) := '0123456789';
   alpha_array varchar2(26) := 'abcdefghijklmnopqrstuvwxyz';
   cnt_letter integer := 0;
   cnt_upper integer := 0;
   cnt_lower integer := 0;
   cnt_digit integer := 0;
   cnt_special integer := 0;
   delimiter boolean := false;
   len integer := nvl (length(password), 0);
   i integer ;
   ch char(1);
begin
   -- Check that the password length does not exceed 2 * (max DB pwd len)
   -- The maximum length of any DB User password is 128 bytes.
   -- This limit improves the performance of the Edit Distance calculation
   -- between old and new passwords.
   if len > 256 then
      raise_application_error(-20020, 'Password length more than 256 characters');
   end if;

   -- Classify each character in the password.
   for i in 1..len loop
      ch := substr(password, i, 1);
      if ch = '"' then
         delimiter := true;
      elsif instr(digit_array, ch) > 0 then
         cnt_digit := cnt_digit + 1;
      elsif instr(alpha_array, nls_lower(ch)) > 0 then
         cnt_letter := cnt_letter + 1;
         if ch = nls_lower(ch) then
            cnt_lower := cnt_lower + 1;
         else
            cnt_upper := cnt_upper + 1;
         end if;
      else
         cnt_special := cnt_special + 1;
      end if;
   end loop;

   if delimiter = true then
      raise_application_error(-20012, 'password must NOT contain a '
                               || 'double-quotation mark which is '
                               || 'reserved as a password delimiter');
   end if;
   if chars is not null and len < chars then
      raise_application_error(-20001, 'Password length less than ' ||
                              chars);
   end if;

   if letter is not null and cnt_letter < letter then
      raise_application_error(-20022, 'Password must contain at least ' ||
                                      letter || ' letter(s)');
   end if;
   if upper is not null and cnt_upper < upper then
      raise_application_error(-20023, 'Password must contain at least ' ||
                                      upper || ' uppercase character(s)');
   end if;
   if lower is not null and cnt_lower < lower then
      raise_application_error(-20024, 'Password must contain at least ' ||
                                      lower || ' lowercase character(s)');
   end if;
   if digit is not null and cnt_digit < digit then
      raise_application_error(-20025, 'Password must contain at least ' ||
                                      digit || ' digit(s)');
   end if;
   if special is not null and cnt_special < special then
      raise_application_error(-20026, 'Password must contain at least ' ||
                                      special || ' special character(s)');
   end if;

   return(true);
end;
/


Rem  Function: "ora_string_distance" - Calculates the Levenshtein distance
Rem            between two strings 's' and 't'.
Rem            The Levenshtein distance between two words is the minimum number 
Rem            of single-character edits (insertion, deletion, substitution) 
Rem            required to change one word into the other

create or replace function ora_string_distance
(s varchar2,
 t varchar2)
return integer is 
   s_len    integer := nvl (length(s), 0);
   t_len    integer := nvl (length(t), 0);
   type arr_type is table of number index by binary_integer;
   d_col    arr_type ;
   dist     integer := 0;
begin
   if s_len = 0 then
      dist := t_len;
   elsif t_len = 0 then
      dist := s_len;
   -- Bug 18237713 : If source or target length exceeds max DB password length
   -- that is 128 bytes, then raise exception.
   elsif t_len > 128 or s_len > 128 then  
     raise_application_error(-20027,'Password length more than 128 bytes');
   elsif s = t then 
     return(0);
   else
      for j in 1 .. (t_len+1) * (s_len+1) - 1 loop
          d_col(j) := 0 ;
      end loop;
      for i in 0 .. s_len loop
          d_col(i) := i;
      end loop;
      for j IN 1 .. t_len loop
          d_col(j * (s_len + 1)) := j;
      end loop;

      for i in 1.. s_len loop
        for j IN 1 .. t_len loop
          if substr(s, i, 1) = substr(t, j, 1)
          then
             d_col(j * (s_len + 1) + i) := d_col((j-1) * (s_len+1) + i-1) ;
          else
             d_col(j * (s_len + 1) + i) := LEAST (
                       d_col( j * (s_len+1) + (i-1)) + 1,      -- Deletion
                       d_col((j-1) * (s_len+1) + i) + 1,       -- Insertion
                       d_col((j-1) * (s_len+1) + i-1) + 1 ) ;  -- Substitution
          end if ;
        end loop;
      end loop;
      dist :=  d_col(t_len * (s_len+1) + s_len);
   end if;

   return (dist);
end;
/
              
Rem
Rem Function: "ora12c_strong_verify_function" - provided from12c onwards for
Rem           stringent password check requirements.
Rem 
Rem This function is provided to give stronger password complexity function
Rem that would take into consideration recommendations from Department of
Rem Defense Database Security Technical Implementation Guide (STIG).

create or replace function ora12c_strong_verify_function
(username varchar2,
 password varchar2,
 old_password varchar2)
return boolean IS
   differ integer;
begin
   if not ora_complexity_check(password, chars => 9, upper => 2, lower => 2,
                           digit => 2, special => 2) then 
      return(false);
   end if;

   -- Check if the password differs from the previous password by at least
   -- 4 characters
   if old_password is not null then 
      differ := ora_string_distance(old_password, password);
      if differ < 4 then
         raise_application_error(-20032, 'Password should differ from previous '
                                 || 'password by at least 4 characters');
      end if;
   end if;

   return(true);
end;
/

Rem
Rem STIG Compliant User Profile
Rem

declare
profile_exists exception;
pragma exception_init(profile_exists, -02379);
begin
 execute immediate 'create profile ora_stig_profile limit
                    password_life_time 60
                    password_grace_time 5
                    password_reuse_time 365
                    password_reuse_max 10
                    failed_login_attempts 3
                    password_lock_time unlimited
                    idle_time 15
                    password_verify_function ora12c_strong_verify_function
                    container=current';
exception when profile_exists then 
 null;
end;
/

@?/rdbms/admin/sqlsessend.sql
