Rem
Rem $Header: rdbms/admin/catremxutil.sql /main/2 2014/02/20 12:45:52 surman Exp $
Rem
Rem catremxutil.sql
Rem
Rem Copyright (c) 2011, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catremxutil.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem     remove xutil packages and views
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem
Rem BEGIN SQL_FILE_METADATA
Rem SQL_SOURCE_FILE: rdbms/admin/catremxutil.sql
Rem SQL_SHIPPED_FILE: rdbms/admin/catremxutil.sql
Rem SQL_PHASE: CATREMXUTIL
Rem SQL_STARTUP_MODE: NORMAL
Rem SQL_IGNORABLE_ERRORS: NONE
Rem SQL_CALLING_FILE: rdbms/admin/catqm_int.sql
Rem END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    surman      01/22/14 - 13922626: Update SQL metadata
Rem    bhammers    07/22/11 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

SET ECHO ON
SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 80
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

begin
  execute immediate 'drop PACKAGE XDB.DBMS_XDB_CONSTANTS';
exception
  when others then
    commit;
end;
/

begin
  execute immediate 'drop PACKAGE XDB.DBMS_XMLSCHEMA_ANNOTATE';
exception
  when others then
    commit;
end;
/

begin
  execute immediate 'drop PACKAGE XDB.DBMS_XMLSTORAGE_MANAGE';
exception
  when others then
    commit;
end;
/


@?/rdbms/admin/sqlsessend.sql
