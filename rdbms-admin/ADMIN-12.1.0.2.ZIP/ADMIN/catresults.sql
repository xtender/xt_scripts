Rem
Rem $Header: rdbms/admin/catresults.sql /main/5 2014/02/20 19:49:18 jerrede Exp $
Rem
Rem catresults.sql
Rem
Rem Copyright (c) 2012, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catresults.sql - Display Upgrade Status 
Rem
Rem    DESCRIPTION
Rem      Display the upgrade results.
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    jerrede     01/30/14 - Fix Report Name
Rem    jerrede     01/08/14 - Fix bug 18044666 Summary Report not displayed
Rem    jerrede     11/23/13 - Add Summary Report
Rem    jerrede     08/28/12 - Created
Rem

Rem =====================================================================
Rem  Reset package just in case comming from migrate
Rem =====================================================================
EXECUTE dbms_session.reset_package;

Rem =====================================================================
Rem REPORT TIMINGS AND SHUTDOWN THE DATABASE..!!!!! 
Rem =====================================================================

Rem =====================================================================
Rem Note:  NO DDL STATEMENTS. DO NOT RECOMMEND ANY SQL BEYOND THIS POINT.
Rem =====================================================================

Rem =====================================================================
Rem Run component status as the last output
Rem Note:  NO DDL STATEMENTS. DO NOT RECOMMEND ANY SQL BEYOND THIS POINT.
Rem Note:  ACTIONS_END must stay here to get the correct upgrade time.
Rem =====================================================================

Rem
Rem Turn option on for report
Rem
set linesize 5000;
set serveroutput on;

Rem
Rem Variables
Rem
VARIABLE ReportName  VARCHAR2(2000);
VARIABLE DirName     VARCHAR2(1500);
VARIABLE CmdName     VARCHAR2(15);


---
--- See if we need to run the create directory script
---
begin

    :CmdName := '@nothing.sql';
    :DirName := dbms_registry_sys.get_pfile_path ('upgrade');

    --
    -- If Directory does not exits then we create it
    --
    IF NOT sys.dbms_registry_sys.dir_exists_and_is_writable(:DirName) THEN
        :CmdName := '@utlucdir.sql';
    END IF;

end;
/

---
--- Create Directory if need be
---
COLUMN Cmd_Name NEW_VALUE cn NOPRINT;
SELECT :CmdName as Cmd_Name FROM sys.dual;
@&cn


declare

    cnt        NUMBER :=0;
    platform   v$database.platform_name%TYPE;
    RptName    CONSTANT VARCHAR2(15) := 'upg_summary.log';
    WinSlash   CONSTANT VARCHAR2(1)  := '\';        -- 'WinDows
    UnixSlash  CONSTANT VARCHAR2(1)  := '/';        --  Unix
    Slash      VARCHAR2(1)  := UnixSlash;  --  Default to Unix

begin

    --      
    -- Check Directory If we still can't write to it then
    -- default to $ORACLE_HOME/rdbms/log
    --
    IF NOT sys.dbms_registry_sys.dir_exists_and_is_writable(:DirName) THEN

        --
        -- Find out the platform
        --
        EXECUTE IMMEDIATE 'SELECT NLS_UPPER(platform_name) FROM v$database'
                        INTO platform;

        --
        -- Adjust the slash for Windows
        --
        IF INSTR(platform, 'WINDOWS') != 0 THEN
                slash := WinSlash;
        END IF;

        --
        -- Construct report Name
        --
        DBMS_SYSTEM.GET_ENV('ORACLE_HOME', :DirName);
        IF :DirName IS NOT NULL THEN
                :DirName := :DirName || slash || 'rdbms' || slash 
                                || 'log' || slash;
        END IF;

    END IF;


    --
    -- Set and display report name
    --
    :ReportName := :DirName || RptName;
    sys.dbms_output.put_line('CATCTL REPORT = ' || :ReportName);


end;
/

--
-- Set echo off so report is clean and
-- reset line size for report.
--
set linesize 80;
set echo off;

--
-- Generate Spool Report Name
--
COLUMN generate_logfile NEW_VALUE generate_logfile NOPRINT
SELECT :ReportName AS generate_logfile FROM SYS.DUAL;

--
-- Spool out the file in append mode
--
SPOOL &generate_logfile append

--
-- Display Upgrade Status and Times
--
@@utlusts TEXT

--
-- Reset
--
set serveroutput off;
spool off;
set echo on;

--
-- Update Summary Table with con_name and endtime.
--
UPDATE sys.registry$upg_summary SET reportname = :ReportName,
                                con_name = SYS_CONTEXT('USERENV','CON_NAME'),
                                endtime  = SYSDATE
       WHERE con_id = -1;
commit;
