Rem
Rem $Header: rdbms/admin/catupshd.sql /main/3 2013/06/09 14:57:51 jerrede Exp $
Rem
Rem catupshd.sql
Rem
Rem Copyright (c) 2007, 2013, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catupshd.sql - CATalog UPgrade SHutDown
Rem
Rem    DESCRIPTION
Rem      This script is the final step in upgrades that that do not 
Rem      run utlmmig.sql.  It updates logminer metadata in the redo
Rem      stream (when needed) and shuts down the database.
Rem
Rem    NOTES
Rem      Invoked from catupend.sql
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    jerrede     04/22/13 - Support for CDB
Rem    dvoss       02/16/12 - bug 13719292 - logminer build is needed
Rem                           when there is no migration
Rem    rburns      07/12/07 - final upgrade shutdown
Rem    rburns      07/12/07 - Created
Rem


Rem =====================================================================
Rem Update Logminer Metadata in Redo Stream
Rem =====================================================================

@@utllmup



