Rem
Rem $Header: rdbms/admin/catwrr.sql /main/3 2012/01/12 12:02:53 kmorfoni Exp $
Rem
Rem catwrr.sql
Rem
Rem Copyright (c) 2006, 2011, Oracle and/or its affiliates. 
Rem All rights reserved. 
Rem
Rem    NAME
Rem      catwrr.sql - Catalog script for Workload Capture
Rem                   and Replay
Rem
Rem    DESCRIPTION
Rem      Creates tables, views, package for Workload Capture
Rem      and Replay
Rem
Rem    NOTES
Rem      Must be run when connected as SYSDBA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    kmorfoni    11/02/11 - Move creation of tables for workload intelligence
Rem                           from catwrr.sql to catwrrtb.sql
Rem    kmorfoni    06/15/11 - Create tables required for workload intelligence
Rem    kdias       05/25/06 - rename record to capture 
Rem    veeve       02/01/06 - Created
Rem

Rem 
Rem Create all the dictionary tables
@@catwrrtb.sql

Rem
Rem Create all the dictionary views
@@catwrrvw.sql

Rem
Rem Create the DBA_WORKLOAD_ package definitions
@@dbmswrr.sql

Rem
Rem Create the DBA_WORKLOAD_ package bodys
@@prvtwrr.plb

