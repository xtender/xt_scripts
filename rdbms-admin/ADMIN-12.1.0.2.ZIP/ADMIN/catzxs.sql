Rem

Rem $Header: rdbms/admin/catzxs.sql /main/42 2014/02/20 12:45:54 surman Exp $
Rem
Rem catzxs.sql
Rem
Rem Copyright (c) 2006, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catzxs.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem
Rem BEGIN SQL_FILE_METADATA
Rem SQL_SOURCE_FILE: rdbms/admin/catzxs.sql
Rem SQL_SHIPPED_FILE: rdbms/admin/catzxs.sql
Rem SQL_PHASE: CATZXS
Rem SQL_STARTUP_MODE: NORMAL
Rem SQL_IGNORABLE_ERRORS: NONE
Rem SQL_CALLING_FILE: rdbms/admin/catqm_int.sql
Rem END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    surman      01/22/14 - 13922626: Update SQL metadata
Rem    minx        03/01/12 - cleanup XS objects, depreciated

@@?/rdbms/admin/sqlsessstart.sql

@?/rdbms/admin/sqlsessend.sql
