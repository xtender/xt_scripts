Rem
Rem $Header: rdbms/admin/cmpupgrd.sql /main/13 2013/09/21 20:05:43 akruglik Exp $
Rem
Rem $Header: rdbms/admin/cmpupgrd.sql /main/13 2013/09/21 20:05:43 akruglik Exp $
Rem
Rem cmpupgrd.sql
Rem
Rem Copyright (c) 2006, 2013, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      cmpupgrd.sql - CoMPonent UPGRaDe script
Rem
Rem    DESCRIPTION
Rem      This script upgrades the components in the database
Rem
Rem    NOTES
Rem      
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    jerrede     07/25/13 - Serialize for CDB
Rem    jerrede     04/03/13 - Support for CDB
Rem    jerrede     02/11/13 - Fix Syntax Error
Rem    jerrede     01/08/13 - Lrg 8580699 DeadLock Issue Registering 
Rem                           ordexif.xsd with XDB under
Rem                           http://xmlns.oracle.com/ord/meta/exif
Rem    jerrede     01/07/13 - Lrg 8652277 Make JAVM Serial deadlock issue
Rem                           when running jvmrm.sql during the FULL_REMOVAL
Rem                           or GRADE_REMOVAL.
Rem    jerrede     05/08/12 - Fix lrg 6730954 Definition problem in Windows
Rem                           with moving from phase to phase need to restart
Rem                           between all phases
Rem    jerrede     04/25/12 - Bug 13995725 Serial OWM because of Deadlocks
Rem                           Moved from cmpupord.sql to cmpupnxb.sql
Rem    jerrede     02/03/12 - Fix lock issue loading rdbms/jlib/CDC.jar lrg
Rem                           6728210
Rem    jerrede     12/12/11 - Add Comments for Parallel Upgrade
Rem    jerrede     10/18/11 - Parallel Upgrade ntt Changes
Rem    badeoti     09/30/10 - diagnostic errorstack for intermittent ORA-31061
Rem    badeoti     05/07/10 - disable xdk schema caching for inserts into csx
Rem                           tables during migrations
Rem    rburns      05/22/06 - parallel upgrade 
Rem    rburns      05/22/06 - Created
Rem


Rem **********************************************************************
Rem 
Rem  NOTE: SQL CODE NOT PERMITTED IN THIS FILE ONLY THE EXECUTION OF A
Rem       .SQL or .PLB file.
Rem
Rem **********************************************************************

--CATCTL -S
@@cmpupstr.sql

--CATCTL -R
--CATCTL -S
Rem
Rem Java upgrade only
Rem
@@cmpupjav.sql

--CATCTL -R
--CATCTL -S
Rem
Rem Java upgrade xdk
Rem 
@@cmpupxdk.sql

--CATCTL -R
--CATCTL -S
Rem
Rem non-Java/nonXDB dependent upgrades
Rem 
@@cmpupnjv.sql

--CATCTL -R
--CATCTL -S
Rem
Rem XDB upgrade
Rem
@@cmpupxdb.sql

Rem
Rem Java-only dependents
Rem
--CATCTL -R
--CATCTL -S
@@cmpupnxb.sql

--CATCTL -R
--CATCTL -S
Rem
Rem Intermedia
Rem
@@cmpupord.sql

--CATCTL -R
--CATCTL -S
Rem
Rem Spatial
Rem
@@cmpupsdo.sql

--CATCTL -R
--CATCTL -S
Rem
Rem Miscellaneous Components
Rem
@@cmpupmsc.sql

--CATCTL -R
--CATCTL -S
Rem
Rem Final component actions
Rem
@@cmpupend.sql


Rem *********************************************************************
Rem END cmpupgrd.sql
Rem *********************************************************************
