Rem
Rem $Header: rdbms/admin/cmpupstr.sql /main/2 2013/06/09 14:57:51 jerrede Exp $
Rem
Rem cmpupstr.sql
Rem
Rem Copyright (c) 2006, 2013, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      cmpupstr.sql - CoMPonent UPgrade STaRt script
Rem
Rem    DESCRIPTION
Rem      Initial component upgrade actions
Rem
Rem    NOTES
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    jerrede     05/10/13 - Support for CDB, Move calling of timestamp
Rem                           to cmpupstr.sql. Ending of rdbms is to
Rem                           soon as catctl.pl may also invalidate RDBMS after
Rem                           the running of catupprc.sql.
Rem    rburns      05/23/06 - parallel upgrade 
Rem    rburns      05/23/06 - Created
Rem

Rem =========================================================================
Rem Exit immediately if there are errors in the initial checks
Rem =========================================================================

WHENEVER SQLERROR EXIT;

Rem check instance version and status; set session attributes
EXECUTE dbms_registry.check_server_instance;

Rem =========================================================================
Rem Continue even if there are SQL errors in remainder of script 
Rem =========================================================================

WHENEVER SQLERROR CONTINUE;

Rem =====================================================================
Rem RDBMS UPgrade Complete
Rem =====================================================================

SELECT dbms_registry_sys.time_stamp('rdbms_end') as timestamp from dual;

