Rem
Rem $Header: rdbms/admin/dbmschnf.sql /main/7 2014/02/20 12:45:40 surman Exp $
Rem
Rem dbmschnf.sql
Rem
Rem Copyright (c) 2003, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      dbmschnf.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem
Rem BEGIN SQL_FILE_METADATA
Rem SQL_SOURCE_FILE: rdbms/admin/dbmschnf.sql
Rem SQL_SHIPPED_FILE: rdbms/admin/dbmschnf.sql
Rem SQL_PHASE: DBMSCHNF
Rem SQL_STARTUP_MODE: NORMAL
Rem SQL_IGNORABLE_ERRORS: NONE
Rem SQL_CALLING_FILE: rdbms/admin/catpdbms.sql
Rem END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    surman      12/29/13 - 13922626: Update SQL metadata
Rem    surman      03/27/12 - 13615447: Add SQL patching tags
Rem    schitti     08/04/05 - string search support for chnf 
Rem    ssvemuri    07/09/04 - ssvemuri_change_notification
Rem    bsinha      10/22/03 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

CREATE or REPLACE PACKAGE dbms_change_notification AUTHID CURRENT_USER as
QOS_RELIABLE CONSTANT BINARY_INTEGER := 1;
QOS_DEREG_NFY CONSTANT BINARY_INTEGER := 2;
QOS_ROWIDS CONSTANT BINARY_INTEGER :=4;
QOS_QUERY  CONSTANT BINARY_INTEGER := 8;
QOS_BEST_EFFORT CONSTANT BINARY_INTEGER := 16;

EVENT_NONE CONSTANT BINARY_INTEGER :=0;
EVENT_STARTUP CONSTANT BINARY_INTEGER := 1;
EVENT_SHUTDOWN CONSTANT BINARY_INTEGER := 2;
EVENT_SHUTDOWN_ANY CONSTANT BINARY_INTEGER := 3;
EVENT_DROP_DB CONSTANT BINARY_INTEGER := 4;
EVENT_DEREG CONSTANT BINARY_INTEGER := 5;
EVENT_OBJCHANGE CONSTANT BINARY_INTEGER := 6;
EVENT_QUERYCHANGE CONSTANT BINARY_INTEGER := 7;

ALL_OPERATIONS CONSTANT BINARY_INTEGER := 0;
ALL_ROWS CONSTANT BINARY_INTEGER := 1;
INSERTOP CONSTANT BINARY_INTEGER := 2;
UPDATEOP CONSTANT BINARY_INTEGER := 4;
DELETEOP CONSTANT BINARY_INTEGER := 8;
ALTEROP  CONSTANT BINARY_INTEGER := 16;
DROPOP   CONSTANT BINARY_INTEGER := 32;
UNKNOWNOP CONSTANT BINARY_INTEGER := 64;

STRING_DOMAIN_SCHEMA CONSTANT BINARY_INTEGER :=0;
STRING_DOMAIN_DATABASE CONSTANT BINARY_INTEGER :=1;
STRING_DOMAIN_TABLE CONSTANT BINARY_INTEGER :=2;

STRING_TRANSITIONAL_SEARCH CONSTANT BINARY_INTEGER :=0;
STRING_COMPLETE_SEARCH CONSTANT BINARY_INTEGER :=1;

 -- Notification Grouping Class
  NTFN_GROUPING_CLASS_TIME CONSTANT BINARY_INTEGER := 1;

 -- Notification Grouping Type
  NTFN_GROUPING_TYPE_SUMMARY CONSTANT BINARY_INTEGER := 1;
  NTFN_GROUPING_TYPE_LAST    CONSTANT BINARY_INTEGER := 2;

 -- Notification Grouping Repeat Count
  NTFN_GROUPING_FOREVER CONSTANT BINARY_INTEGER := -1;

FUNCTION NEW_REG_START_OC4J(regds IN sys.chnf$_reg_info_oc4j)
  RETURN NUMBER;

FUNCTION NEW_REG_START(regds IN sys.chnf$_reg_info)
  RETURN NUMBER;

PROCEDURE ENABLE_REG(regid IN NUMBER);

PROCEDURE REG_END;

PROCEDURE DEREGISTER(regid IN NUMBER);

PROCEDURE SET_ROWID_THRESHOLD(tbname IN varchar2, threshold IN NUMBER);
 FUNCTION CQ_NOTIFICATION_QUERYID return number;

END;
/

CREATE or REPLACE PUBLIC SYNONYM dbms_change_notification FOR sys.dbms_change_notification
/

CREATE or REPLACE PUBLIC SYNONYM dbms_cq_notification FOR sys.dbms_change_notification
/

CREATE OR REPLACE LIBRARY dbms_chnf_lib TRUSTED AS STATIC
/




@?/rdbms/admin/sqlsessend.sql
